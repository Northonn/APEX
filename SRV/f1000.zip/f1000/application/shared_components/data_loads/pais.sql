prompt --application/shared_components/data_loads/pais
begin
--   Manifest
--     DATA LOAD: PAIS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(192869297457413675)
,p_name=>'PAIS'
,p_format=>'CSV'
,p_encoding=>'utf-8'
,p_csv_enclosed=>'"'
,p_has_header_row=>true
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(192869652444413676)
,p_data_profile_id=>wwv_flow_imp.id(192869297457413675)
,p_name=>'NOME'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>240
,p_selector_type=>'NAME'
,p_selector=>'NOME'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(195117391132358993)
,p_data_profile_id=>wwv_flow_imp.id(192869297457413675)
,p_name=>'CODIGO'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_selector_type=>'NAME'
,p_selector=>'CODIGO'
);
wwv_flow_imp_shared.create_load_table(
 p_id=>wwv_flow_imp.id(192869800151413676)
,p_name=>'PAIS'
,p_static_id=>'pais'
,p_target_type=>'TABLE'
,p_table_name=>'PAIS'
,p_data_profile_id=>wwv_flow_imp.id(192869297457413675)
,p_loading_method=>'APPEND'
,p_commit_interval=>200
,p_error_handling=>'ERROR_LOG'
,p_error_collection_name=>'ERR$_PAIS'
,p_skip_validation=>'N'
);
wwv_flow_imp.component_end;
end;
/
