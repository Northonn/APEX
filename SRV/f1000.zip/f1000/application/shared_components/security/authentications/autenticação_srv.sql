prompt --application/shared_components/security/authentications/autenticação_srv
begin
--   Manifest
--     AUTHENTICATION: Autenticação SRV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(245525749455598491)
,p_name=>unistr('Autentica\00E7\00E3o SRV')
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'PKG_SEGURANCA.AUTH'
,p_attribute_05=>'N'
,p_invalid_session_type=>'LOGIN'
,p_cookie_name=>'&WORKSPACE_COOKIE.'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
