prompt --application/shared_components/security/authorizations/custom
begin
--   Manifest
--     SECURITY SCHEME: Custom
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(190869548105579193)
,p_name=>'Custom'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'declare',
'    l_habilitado varchar2(1);',
'begin  ',
'       ',
'        --check if the user exist in the user''s table ',
'        SELECT d.habilitado into l_habilitado',
'        FROM   usuario_perfil a',
'               JOIN adm_usuario b',
'                 ON b.id = a.usuario_id',
'               JOIN perfil_grupo_funcionalidade c',
'                 ON c.perfil_id = a.perfil_id',
'               JOIN perfil_grupo_funcionalidade_pasta d',
'                 ON d.perfil_grupo_funcionalidade_id = c.id',
'        WHERE  Upper(b.username) = Upper(:APP_USER)',
'               AND grupo_funcionalidade_pasta_id =',
'                   (SELECT b.id',
'                    FROM   adm_artefato a',
'                           JOIN grupo_funcionalidade_pasta b',
'                             ON b.artefato_id = a.id',
'                    WHERE  a.codigo = :APP_PAGE_ID);   ',
'',
'        if l_habilitado = ''S'' then',
'            return true;  ',
'        else    ',
'            return false;  ',
'        end if;',
'        ',
'    exception ',
'        when others then ',
'       ',
'            return false; ',
'end;',
''))
,p_error_message=>unistr('Controle de acesso: Voc\00EA n\00E3o possuiu permiss\00E3o para acessar essa funcionalidade. Entre em contato como administrador do sistema para conceder acesso.')
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
