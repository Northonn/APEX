prompt --application/shared_components/security/authorizations/custom_component
begin
--   Manifest
--     SECURITY SCHEME: Custom component
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(190945784854963053)
,p_name=>'Custom component'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return true;',
''))
,p_error_message=>unistr('Voc\00EA n\00E3o tem permiss\00E3o para alterar a foto')
,p_caching=>'BY_COMPONENT'
);
wwv_flow_imp.component_end;
end;
/
