prompt --application/shared_components/web_sources/list_language
begin
--   Manifest
--     WEB SOURCE: list-language
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(202275286307837977)
,p_name=>'list-language'
,p_static_id=>'list_language'
,p_web_source_type=>'NATIVE_ORDS'
,p_data_profile_id=>wwv_flow_imp.id(202274418136837970)
,p_remote_server_id=>wwv_flow_imp.id(124693655834914802)
,p_url_path_prefix=>'/languages/create-language'
,p_attribute_01=>'N'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(202275426327837978)
,p_web_src_module_id=>wwv_flow_imp.id(202275286307837977)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(202275851060837980)
,p_web_src_module_id=>wwv_flow_imp.id(202275286307837977)
,p_operation=>'POST'
,p_database_operation=>'INSERT'
,p_url_pattern=>'.'
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
