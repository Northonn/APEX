prompt --application/shared_components/logic/application_processes/cria_coluna_banco
begin
--   Manifest
--     APPLICATION PROCESS: CRIA_COLUNA_BANCO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(74341924355813358)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CRIA_COLUNA_BANCO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    bo_srv_entidade_coluna.cria_coluna_banco(:P136_ID);',
'    htp.p('''');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>41157721259919
);
wwv_flow_imp.component_end;
end;
/
