prompt --application/shared_components/plugins/template_component/botoes_listagem_avancado_projeto
begin
--   Manifest
--     PLUGIN: BOTOES_LISTAGEM_AVANCADO_PROJETO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(203483720174174201)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '')
,p_name=>'BOTOES_LISTAGEM_AVANCADO_PROJETO'
,p_display_name=>unistr('Bot\00F5es Listagem avancado projeto')
,p_supported_component_types=>'PARTIAL'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','BOTOES_LISTAGEM_AVANCADO_PROJETO'),'')
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if APEX$IS_LAZY_LOADING/}',
'  <div></div>',
'{else/}',
'  {if APEX$HAS_ACTION_BUTTONS/}',
'    <ul class="ul-btn-avancado" style="padding: 0px; margin:0px;">',
'        <li class="li-btn-avancado" style="padding: 0px">',
'            <div class="span-btn-avancado ico-circled-left-sm" style="margin-right: 8px;">',
'            </div>     ',
'            #USUARIO#',
'            #DOCUMENTO#',
'            #EDITAR#',
'            #DUPLICAR#',
'            #EXCLUIR#',
'        </li>',
'    </ul>   ',
'  {endif/}',
'{endif/}'))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>2
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_files_version=>9
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(203484043924174207)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>10
,p_static_id=>'ACTIONS'
,p_prompt=>'Actions'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_act_template(
 p_id=>wwv_flow_imp.id(235471668115537997)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_name=>'Editar'
,p_type=>'BUTTON'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a class="padding-sm-lateral rw-Button{if IS_HOT/} is-hot{endif/} {if ICON_CLASSES/}rw-Button--iconText{else/}rw-Button--text{endif/} #CSS_CLASSES#" href="#LINK_URL#" title="#LABEL!ATTR#" #LINK_ATTR# {if IS_DISABLED/}disabled{endif/}>',
'  <span class="rw-Button-label">',
'    <span class="rw-Button-icon ico-edit-sm" style="display:block;" aria-hidden="true">  ',
'         ',
'    </span>',
'    <span class="rw-Button-text"></span>',
'  </span>',
'</a>'))
);
wwv_flow_imp_shared.create_plugin_act_template(
 p_id=>wwv_flow_imp.id(235471959965538814)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_name=>'Excluir'
,p_type=>'BUTTON'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a class="padding-sm-lateral rw-Button{if IS_HOT/} is-hot{endif/} {if ICON_CLASSES/}rw-Button--iconText{else/}rw-Button--text{endif/} #CSS_CLASSES#" href="#LINK_URL#" title="#LABEL!ATTR#" #LINK_ATTR# {if IS_DISABLED/}disabled{endif/}>',
'  <span class="rw-Button-label">',
'    <span class="rw-Button-icon ico-trash-sm" style="display:block;" aria-hidden="true">',
'    </span>',
'    <span class="rw-Button-text"></span>',
'  </span>',
'</a>'))
);
wwv_flow_imp_shared.create_plugin_act_template(
 p_id=>wwv_flow_imp.id(235561273687812658)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_name=>unistr('Mais informa\00E7\00F5es')
,p_type=>'BUTTON'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a class="padding-sm-lateral rw-Button{if IS_HOT/} is-hot{endif/} {if ICON_CLASSES/}rw-Button--iconText{else/}rw-Button--text{endif/} #CSS_CLASSES#" href="#LINK_URL#" title="#LABEL!ATTR#" #LINK_ATTR# {if IS_DISABLED/}disabled{endif/}>',
'  <span class="rw-Button-label">',
'    <span class="rw-Button-icon ico-info-sm" style="display:block;" aria-hidden="true">',
'        ',
'    </span>',
'    <span class="rw-Button-text"></span>',
'  </span>',
'</a>'))
);
wwv_flow_imp_shared.create_plugin_act_template(
 p_id=>wwv_flow_imp.id(239924815914466489)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_name=>'Duplicar'
,p_type=>'BUTTON'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a class="padding-sm-lateral rw-Button{if IS_HOT/} is-hot{endif/} {if ICON_CLASSES/}rw-Button--iconText{else/}rw-Button--text{endif/} #CSS_CLASSES#" href="#LINK_URL#" title="#LABEL!ATTR#" #LINK_ATTR# {if IS_DISABLED/}disabled{endif/}>',
'  <span class="rw-Button-label">',
'    <span class="rw-Button-icon ico-copy-sm" style="display: block;" aria-hidden="true">',
'    </span>',
'    <span class="rw-Button-text"></span>',
'  </span>',
'</a>'))
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(15822842819512091)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_name=>'Documentos'
,p_static_id=>'DOCUMENTO'
,p_display_sequence=>20
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(235561273687812658)
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(235472328784539959)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_name=>'Editar'
,p_static_id=>'EDITAR'
,p_display_sequence=>30
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(235471668115537997)
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(235472553157540717)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_name=>'Excluir'
,p_static_id=>'EXCLUIR'
,p_display_sequence=>50
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(235471959965538814)
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(235561626318814643)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_name=>unistr('Usu\00E1rio')
,p_static_id=>'USUARIO'
,p_display_sequence=>10
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(235561273687812658)
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(239925280416470124)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_name=>'Duplicar'
,p_static_id=>'DUPLICAR'
,p_display_sequence=>40
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(239924815914466489)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2F2A20596F75276C6C2077616E74206A61766173637269707420666F72206465736B746F70206F72206368616E676520746865207569206F6E206C61726765722076696577706F727473202A2F0D0A646F63756D656E742E717565727953656C6563746F';
wwv_flow_imp.g_varchar2_table(2) := '722822756C22292E6164644576656E744C697374656E65722822636C69636B222C20286529203D3E207B0D0A2020636F6E7374206C69203D20652E7461726765742E636C6F7365737428226C6922293B0D0A2020636F6E73742062746E203D20652E7461';
wwv_flow_imp.g_varchar2_table(3) := '726765742E636C6F7365737428226122293B0D0A2020696620286C69202626206C692E7363726F6C6C4C656674203D3D3D203029207B0D0A202020206C692E7363726F6C6C4279287B0D0A2020202020206C6566743A20312C0D0A202020202020626568';
wwv_flow_imp.g_varchar2_table(4) := '6176696F723A2022736D6F6F7468220D0A202020207D293B0D0A20207D20656C736520696620282162746E202626206C6929207B0D0A202020206C692E7363726F6C6C4279287B0D0A2020202020206C6566743A202D312C0D0A20202020202062656861';
wwv_flow_imp.g_varchar2_table(5) := '76696F723A2022736D6F6F7468220D0A202020207D293B0D0A20207D20656C7365206966202862746E202626206C6929207B0D0A202020206C692E72656D6F766528293B0D0A20207D0D0A7D293B0D0A';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(203487196641183367)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_file_name=>'Botoes_Listagem_Avancado.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2A207B0D0A2020666F6E742D66616D696C793A2073616E732D73657269663B0D0A7D0D0A0D0A756C207B0D0A202077696474683A2033373570783B0D0A20206F766572666C6F773A2068696464656E3B0D0A20206C6973742D7374796C653A206E6F6E65';
wwv_flow_imp.g_varchar2_table(2) := '3B0D0A202070616464696E673A20303B0D0A7D0D0A0D0A6C69207B0D0A20207363726F6C6C2D736E61702D747970653A2078206D616E6461746F72793B0D0A20206F766572666C6F772D783A206175746F3B0D0A2020646973706C61793A20666C65783B';
wwv_flow_imp.g_varchar2_table(3) := '0D0A20206865696768743A2031303070783B0D0A2020626F726465723A2031707820736F6C69642077686974653B0D0A20207363726F6C6C6261722D77696474683A206E6F6E653B0D0A2020637572736F723A20677261623B0D0A7D0D0A0D0A6C693A3A';
wwv_flow_imp.g_varchar2_table(4) := '2D7765626B69742D7363726F6C6C626172207B0D0A2020646973706C61793A206E6F6E653B0D0A7D0D0A0D0A6C69203E202A207B0D0A20207363726F6C6C2D736E61702D616C69676E3A2073746172743B0D0A2020666F6E742D73697A653A203272656D';
wwv_flow_imp.g_varchar2_table(5) := '3B0D0A7D0D0A0D0A6C692061207B0D0A2020626F726465723A206E6F6E653B0D0A2020636F6C6F723A2077686974653B0D0A2020637572736F723A20706F696E7465723B0D0A7D0D0A0D0A6C6920613A66697273742D6F662D74797065207B0D0A202066';
wwv_flow_imp.g_varchar2_table(6) := '6C65783A20312030203330253B0D0A20206261636B67726F756E642D636F6C6F723A206F72616E67653B0D0A7D0D0A0D0A6C69207370616E207B0D0A2020666C65783A2032203020313030253B0D0A2020636F6C6F723A2077686974653B0D0A20206261';
wwv_flow_imp.g_varchar2_table(7) := '636B67726F756E642D636F6C6F723A20736C617465677265793B0D0A202070616464696E673A20302E3572656D3B0D0A2020757365722D73656C6563743A206E6F6E653B0D0A7D0D0A0D0A6C6920613A6C6173742D6F662D74797065207B0D0A2020666C';
wwv_flow_imp.g_varchar2_table(8) := '65783A20312030203330253B0D0A20206261636B67726F756E642D636F6C6F723A206461726B7265643B0D0A7D0D0A';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(203487487804183368)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_file_name=>'Botoes_Listagem_Avancado.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2A7B666F6E742D66616D696C793A73616E732D73657269667D756C7B77696474683A33373570783B6F766572666C6F773A68696464656E3B6C6973742D7374796C653A6E6F6E653B70616464696E673A307D6C697B7363726F6C6C2D736E61702D747970';
wwv_flow_imp.g_varchar2_table(2) := '653A78206D616E6461746F72793B6F766572666C6F772D783A6175746F3B646973706C61793A666C65783B6865696768743A31303070783B626F726465723A31707820736F6C696420236666663B7363726F6C6C6261722D77696474683A6E6F6E653B63';
wwv_flow_imp.g_varchar2_table(3) := '7572736F723A677261627D6C693A3A2D7765626B69742D7363726F6C6C6261727B646973706C61793A6E6F6E657D6C693E2A7B7363726F6C6C2D736E61702D616C69676E3A73746172743B666F6E742D73697A653A3272656D7D6C6920617B626F726465';
wwv_flow_imp.g_varchar2_table(4) := '723A303B636F6C6F723A236666663B637572736F723A706F696E7465727D6C6920613A66697273742D6F662D747970657B666C65783A312030203330253B6261636B67726F756E642D636F6C6F723A6F72616E67657D6C69207370616E7B666C65783A32';
wwv_flow_imp.g_varchar2_table(5) := '203020313030253B636F6C6F723A236666663B6261636B67726F756E642D636F6C6F723A233730383039303B70616464696E673A2E3572656D3B757365722D73656C6563743A6E6F6E657D6C6920613A6C6173742D6F662D747970657B666C65783A3120';
wwv_flow_imp.g_varchar2_table(6) := '30203330253B6261636B67726F756E642D636F6C6F723A233862303030307D';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(203488376413186668)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_file_name=>'Botoes_Listagem_Avancado.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '646F63756D656E742E717565727953656C6563746F722822756C22292E6164644576656E744C697374656E65722822636C69636B222C28653D3E7B636F6E737420743D652E7461726765742E636C6F7365737428226C6922292C6F3D652E746172676574';
wwv_flow_imp.g_varchar2_table(2) := '2E636C6F7365737428226122293B742626303D3D3D742E7363726F6C6C4C6566743F742E7363726F6C6C4279287B6C6566743A312C6265686176696F723A22736D6F6F7468227D293A216F2626743F742E7363726F6C6C4279287B6C6566743A2D312C62';
wwv_flow_imp.g_varchar2_table(3) := '65686176696F723A22736D6F6F7468227D293A6F2626742626742E72656D6F766528297D29293B';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(203490469699188966)
,p_plugin_id=>wwv_flow_imp.id(203483720174174201)
,p_file_name=>'Botoes_Listagem_Avancado.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
