prompt --application/shared_components/plugins/template_component/theme_42_botoes_listagem_simples
begin
--   Manifest
--     PLUGIN: THEME_42$BOTOES_LISTAGEM_SIMPLES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(219604216869600088)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '42')
,p_name=>'THEME_42$BOTOES_LISTAGEM_SIMPLES'
,p_display_name=>unistr('Bot\00F5es Listagem simples')
,p_supported_component_types=>'PARTIAL'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','THEME_42$BOTOES_LISTAGEM_SIMPLES'),'')
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if APEX$IS_LAZY_LOADING/}',
'  <div></div>',
'{else/}',
'  {if APEX$HAS_ACTION_BUTTONS/}',
'    #MAIS_INFORMACOES#',
'    #EDITAR#',
'    #DUPLICAR#',
'    #EXCLUIR#',
'  {endif/}',
'{endif/}'))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>2
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(219607221260610706)
,p_plugin_id=>wwv_flow_imp.id(219604216869600088)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>10
,p_static_id=>'ACTIONS'
,p_prompt=>'Actions'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_act_template(
 p_id=>wwv_flow_imp.id(219605763134601282)
,p_plugin_id=>wwv_flow_imp.id(219604216869600088)
,p_name=>'Editar'
,p_type=>'BUTTON'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a class="padding-sm rw-Button{if IS_HOT/} is-hot{endif/} {if ICON_CLASSES/}rw-Button--iconText{else/}rw-Button--text{endif/} #CSS_CLASSES#" href="#LINK_URL#" title="#LABEL!ATTR#" #LINK_ATTR# {if IS_DISABLED/}disabled{endif/}>',
'  <span class="rw-Button-label">',
'    <span class="rw-Button-icon" aria-hidden="true">',
'        <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">',
'            <path d="M19,3H5C3.343,3,2,4.343,2,6v13v0.828c0,1.746,1.974,2.762,3.395,1.747l2.823-2.016 C8.727,19.195,9.336,19,9.961,19H19c1.657,0,3-1.343,3-3V6C22,4.343,20.657,3,19,3z" opacity=".35" fill="#1a457e" />',
'            <path d="M23.138,0.376c-0.827-0.595-1.987-0.42-2.707,0.3l-5.832,5.832C14.216,6.892,14,7.412,14,7.955l0,1.259 C14,9.648,14.352,10,14.786,10l1.259,0c0.542,0,1.063-0.215,1.446-0.599l5.909-5.909C24.279,2.613,24.192,1.135,23.138,0.376z" fill="'
||'#1a457e" />',
'        </svg>',
'    </span>',
'    <span class="rw-Button-text"></span>',
'  </span>',
'</a>'))
);
wwv_flow_imp_shared.create_plugin_act_template(
 p_id=>wwv_flow_imp.id(219606054984602099)
,p_plugin_id=>wwv_flow_imp.id(219604216869600088)
,p_name=>'Excluir'
,p_type=>'BUTTON'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a class="padding-sm rw-Button{if IS_HOT/} is-hot{endif/} {if ICON_CLASSES/}rw-Button--iconText{else/}rw-Button--text{endif/} #CSS_CLASSES#" href="#LINK_URL#" title="#LABEL!ATTR#" #LINK_ATTR# {if IS_DISABLED/}disabled{endif/}>',
'  <span class="rw-Button-label">',
'    <span class="rw-Button-icon" aria-hidden="true">',
'        <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">',
'            <path d="M15.352,22H8.648c-1.513,0-2.789-1.127-2.977-2.628L4,6h16l-1.672,13.372 C18.141,20.873,16.865,22,15.352,22z" opacity=".35" fill="#1a457e" />',
'            <path d="M16,4H8V3c0-0.552,0.448-1,1-1h6c0.552,0,1,0.448,1,1V4z" fill="#1a457e" />',
'            <path d="M19,3C18.399,3,5.601,3,5,3C3.895,3,3,3.895,3,5c0,1.105,0.895,2,2,2c0.601,0,13.399,0,14,0c1.105,0,2-0.895,2-2 C21,3.895,20.105,3,19,3z" fill="#1a457e" />',
'            <path d="M22.5,24c-0.384,0-0.768-0.146-1.061-0.439l-6-6c-0.586-0.585-0.586-1.536,0-2.121c0.586-0.586,1.535-0.586,2.121,0l6,6 c0.586,0.585,0.586,1.536,0,2.121C23.268,23.854,22.884,24,22.5,24z" fill="#CB1100" />',
'            <path d="M16.5,24c-0.384,0-0.768-0.146-1.061-0.439c-0.586-0.585-0.586-1.536,0-2.121l6-6c0.586-0.586,1.535-0.586,2.121,0 c0.586,0.585,0.586,1.536,0,2.121l-6,6C17.268,23.854,16.884,24,16.5,24z" fill="#CB1100" />',
'        </svg>',
'    </span>',
'    <span class="rw-Button-text"></span>',
'  </span>',
'</a>'))
);
wwv_flow_imp_shared.create_plugin_act_template(
 p_id=>wwv_flow_imp.id(219695368706875943)
,p_plugin_id=>wwv_flow_imp.id(219604216869600088)
,p_name=>unistr('Mais informa\00E7\00F5es')
,p_type=>'BUTTON'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a class="padding-sm rw-Button{if IS_HOT/} is-hot{endif/} {if ICON_CLASSES/}rw-Button--iconText{else/}rw-Button--text{endif/} #CSS_CLASSES#" href="#LINK_URL#" title="#LABEL!ATTR#" #LINK_ATTR# {if IS_DISABLED/}disabled{endif/}>',
'  <span class="rw-Button-label">',
'    <span class="rw-Button-icon" aria-hidden="true">',
'        <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">',
'            <circle cx="12" cy="12" r="10" opacity=".35" fill="#1A457E" />',
'            <path d="M11,17v-5c0-0.552,0.448-1,1-1h0c0.552,0,1,0.448,1,1v5c0,0.552-0.448,1-1,1h0C11.448,18,11,17.552,11,17z" fill="#1A457E" />',
'            <circle cx="12" cy="7.5" r="1.5" fill="#1A457E" />',
'              <path d="M22.5,17.5h-2v-2c0-0.829-0.671-1.5-1.5-1.5s-1.5,0.671-1.5,1.5v2h-2c-0.829,0-1.5,0.671-1.5,1.5s0.671,1.5,1.5,1.5h2v2 c0,0.829,0.671,1.5,1.5,1.5s1.5-0.671,1.5-1.5v-2h2c0.829,0,1.5-0.671,1.5-1.5S23.329,17.5,22.5,17.5z" fill="#1A45'
||'7E" />',
'',
'        </svg>',
'    </span>',
'    <span class="rw-Button-text"></span>',
'  </span>',
'</a>'))
);
wwv_flow_imp_shared.create_plugin_act_template(
 p_id=>wwv_flow_imp.id(224058910933529774)
,p_plugin_id=>wwv_flow_imp.id(219604216869600088)
,p_name=>'Duplicar'
,p_type=>'BUTTON'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a class="padding-sm rw-Button{if IS_HOT/} is-hot{endif/} {if ICON_CLASSES/}rw-Button--iconText{else/}rw-Button--text{endif/} #CSS_CLASSES#" href="#LINK_URL#" title="#LABEL!ATTR#" #LINK_ATTR# {if IS_DISABLED/}disabled{endif/}>',
'  <span class="rw-Button-label">',
'    <span class="rw-Button-icon" aria-hidden="true">',
'        <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">',
'            <path d="M21,17c0-0.737-0.405-1.375-1-1.722V8l-6-6H7C5.343,2,4,3.343,4,5v14c0,1.657,1.343,3,3,3h10c0.09,0,0.175-0.019,0.264-0.027C17.607,22.583,18.252,23,19,23c1.103,0,2-0.897,2-2c1.103,0,2-0.897,2-2S22.103,17,21,17z" opacity=".35" fill="'
||'#1A457E" />',
'            <path d="M14,6V2l6,6h-4C14.895,8,14,7.105,14,6z" fill="#1A457E" />',
'            <path d="M8,12c0,0.552,0.448,1,1,1h6c0.552,0,1-0.448,1-1s-0.448-1-1-1H9C8.448,11,8,11.448,8,12z" fill="#1A457E" />',
'            <path d="M13.226,15.046C13.151,15.028,13.08,15,13,15H9c-0.553,0-1,0.448-1,1s0.447,1,1,1h3.294C12.503,16.296,12.82,15.638,13.226,15.046z" fill="#1A457E" />',
'            <path d="M19,14c-2.76,0-5,2.24-5,5s2.24,5,5,5s5-2.24,5-5S21.76,14,19,14z M21.5,20H20v1.5c0,0.55-0.45,1-1,1s-1-0.45-1-1V20h-1.5c-0.55,0-1-0.45-1-1s0.45-1,1-1H18v-1.5c0-0.55,0.45-1,1-1s1,0.45,1,1V18h1.5c0.55,0,1,0.45,1,1S22.05,20,21.5,20z" '
||'fill="#1A457E" />',
'        </svg>',
'    </span>',
'    <span class="rw-Button-text"></span>',
'  </span>',
'</a>'))
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(219606423803603244)
,p_plugin_id=>wwv_flow_imp.id(219604216869600088)
,p_name=>'Editar'
,p_static_id=>'EDITAR'
,p_display_sequence=>10
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(219605763134601282)
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(219606648176604002)
,p_plugin_id=>wwv_flow_imp.id(219604216869600088)
,p_name=>'Excluir'
,p_static_id=>'EXCLUIR'
,p_display_sequence=>20
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(219606054984602099)
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(219695721337877928)
,p_plugin_id=>wwv_flow_imp.id(219604216869600088)
,p_name=>unistr('Mais informa\00E7\00F5es')
,p_static_id=>'MAIS_INFORMACOES'
,p_display_sequence=>30
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(219695368706875943)
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(224059375435533409)
,p_plugin_id=>wwv_flow_imp.id(219604216869600088)
,p_name=>'Duplicar'
,p_static_id=>'DUPLICAR'
,p_display_sequence=>40
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(224058910933529774)
);
wwv_flow_imp.component_end;
end;
/
