prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 1000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(306468862834923835)
,p_theme_id=>42
,p_name=>'Redwood Light'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Redwood-Theme#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(306469086185923835)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(306469286829923835)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(306469426177923835)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(306469613650923835)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Slate.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(306503370326946046)
,p_theme_id=>42
,p_name=>'NG Light'
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-BG":"#1a457e","@g_Accent-OG":"#fcfcfc","@g_Link-Base":"#48b0f7","@g_Body-BG":"#e7ebee","@g_Body-Text":"#1a457e","@g_Actions-Col-BG":"#fafafa","@g_Actions-Col-Text":"#1a457e","@g_Body-Title-BG":"#e7ebee","@g_Body-Title'
||'-FG":"#1a457e","@l_Left-Col-BG":"#ffffff","@l_Left-Col-Text":"#1a457e","@g_Nav_Style":"light","@g_Nav-BG":"#e7ebee","@g_Nav-FG":"#1a457e","@g_Nav-Active-BG":"#cfd7dd","@g_Nav-Active-FG":"#1a457e","@g_Nav-Accent-BG":"#cfd7dd","@g_Nav-Accent-FG":"#1a45'
||'7e","@g_Nav-Badge-BG":"#006bd8","@g_Nav-Badge-FG":"#ffffff","@g_NavBarMenu-Active-BG":"#006bd8","@g_NavBarMenu-Active-FG":"#ffffff","@g_Region-Header-BG":"#e7ebee","@g_Region-Header-FG":"#1a457e","@g_Region-BG":"#e7ebee","@g_Region-FG":"#1a457e","@g_'
||'Success-BG":"#76ca02","@g_Success-FG":"#ffffff","@g_Form-Item-BG":"#ffffff","@g_Form-Item-FG":"#1a457e","@l_Button-Primary-BG":"#309fdb","@l_Button-Primary-Text":"#ffffff","@l_Button-Hot-BG":"#1a457e","@l_Button-Hot-Text":"#ffffff","@l_Button-Success'
||'-BG":"#76ca02","@l_Button-Success-Text":"#ffffff","@g_Button-BG":"#eceeef","@g_Button-Text":"#1a457e"},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#306503370326946046.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
