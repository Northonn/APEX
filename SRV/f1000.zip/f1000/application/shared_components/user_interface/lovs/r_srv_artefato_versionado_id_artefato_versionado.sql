prompt --application/shared_components/user_interface/lovs/r_srv_artefato_versionado_id_artefato_versionado
begin
--   Manifest
--     R_SRV_ARTEFATO_VERSIONADO.ID_ARTEFATO_VERSIONADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(76781198992722301)
,p_lov_name=>'R_SRV_ARTEFATO_VERSIONADO.ID_ARTEFATO_VERSIONADO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.titulo_artefato||'' (''||b.codigo_artefato||'')'' as display_value,',
'       d.versao, ',
'       b.descricao_artefato,',
'       a.id as return_value',
'from srv_artefato_versionado a',
'left join srv_artefato b on  b.id = a.id_artefato',
'left join srv_aplicacao_versionada c on c.id = a.id_aplicacao_versionada',
'left join srv_sistema_versionado d on d.id = c.id_sistema_versionado'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'RETURN_VALUE'
,p_display_column_name=>'DISPLAY_VALUE'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(77940896502274391)
,p_query_column_name=>'DISPLAY_VALUE'
,p_heading=>'srv_artefato.titulo_artefato_l'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(77941671371274394)
,p_query_column_name=>'VERSAO'
,p_heading=>'srv_sistema_versionado.versao_l'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(77941296406274393)
,p_query_column_name=>'DESCRICAO_ARTEFATO'
,p_heading=>'srv_artefato.descricao_artefato_l'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(77942036553274395)
,p_query_column_name=>'RETURN_VALUE'
,p_display_sequence=>40
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp.component_end;
end;
/
