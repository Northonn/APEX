prompt --application/shared_components/user_interface/lovs/r_srv_sistema_versionado_versao
begin
--   Manifest
--     R_SRV_SISTEMA_VERSIONADO.VERSAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(53451032270411810)
,p_lov_name=>'R_SRV_SISTEMA_VERSIONADO.VERSAO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.versao || '' - '' || b.nome_sistema as d, a.id as r  from srv_sistema_versionado a',
'join srv_sistema b on b.id = a.id_sistema'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'SRV_SISTEMA_VERSIONADO'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
