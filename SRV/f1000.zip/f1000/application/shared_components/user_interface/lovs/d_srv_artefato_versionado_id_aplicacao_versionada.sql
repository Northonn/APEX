prompt --application/shared_components/user_interface/lovs/d_srv_artefato_versionado_id_aplicacao_versionada
begin
--   Manifest
--     D_SRV_ARTEFATO_VERSIONADO.ID_APLICACAO_VERSIONADA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(75899682025435945)
,p_lov_name=>'D_SRV_ARTEFATO_VERSIONADO.ID_APLICACAO_VERSIONADA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ap.NOME_APLICACAO || '' - '' || b.versao AS display_value,',
'       av.id AS return_value',
'FROM SRV_APLICACAO_VERSIONADA av',
'LEFT JOIN SRV_APLICACAO ap ON  ap.id = av.ID_APLICACAO',
'LEFT JOIN SRV_SISTEMA_VERSIONADO b ON b.id = av.ID_SISTEMA_VERSIONADO ;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'RETURN_VALUE'
,p_display_column_name=>'DISPLAY_VALUE'
,p_default_sort_column_name=>'DISPLAY_VALUE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
