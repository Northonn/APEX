prompt --application/shared_components/user_interface/lovs/d_srv_idioma_situacao
begin
--   Manifest
--     D_SRV_IDIOMA.SITUACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(70650984268039620)
,p_lov_name=>'D_SRV_IDIOMA.SITUACAO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_idioma'',''situacao'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
