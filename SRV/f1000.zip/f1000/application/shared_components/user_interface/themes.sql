prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 1000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(306469846731923839)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(306307910376923732)
,p_default_dialog_template=>wwv_flow_imp.id(306325325666923741)
,p_error_template=>wwv_flow_imp.id(306322751452923739)
,p_printer_friendly_template=>wwv_flow_imp.id(306307910376923732)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(306322751452923739)
,p_default_button_template=>wwv_flow_imp.id(306466836923923829)
,p_default_region_template=>wwv_flow_imp.id(306369115795923766)
,p_default_chart_template=>wwv_flow_imp.id(306369115795923766)
,p_default_form_template=>wwv_flow_imp.id(306369115795923766)
,p_default_reportr_template=>wwv_flow_imp.id(306369115795923766)
,p_default_tabform_template=>wwv_flow_imp.id(306369115795923766)
,p_default_wizard_template=>wwv_flow_imp.id(306369115795923766)
,p_default_menur_template=>wwv_flow_imp.id(306381711276923773)
,p_default_listr_template=>wwv_flow_imp.id(306369115795923766)
,p_default_irr_template=>wwv_flow_imp.id(306367078990923765)
,p_default_report_template=>wwv_flow_imp.id(306420272842923797)
,p_default_label_template=>wwv_flow_imp.id(306464296217923826)
,p_default_menu_template=>wwv_flow_imp.id(306468478539923831)
,p_default_calendar_template=>wwv_flow_imp.id(306468555817923832)
,p_default_list_template=>wwv_flow_imp.id(306454209904923818)
,p_default_nav_list_template=>wwv_flow_imp.id(306463003420923824)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(306463003420923824)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(306461235989923823)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(306336319192923749)
,p_default_dialogr_template=>wwv_flow_imp.id(306333568715923748)
,p_default_option_label=>wwv_flow_imp.id(306464296217923826)
,p_default_required_label=>wwv_flow_imp.id(306465611604923827)
,p_default_navbar_list_template=>wwv_flow_imp.id(306460825664923823)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/22.1/')
,p_files_version=>685
,p_custom_library_file_urls=>'#WORKSPACE_FILES#icons_staff.css'
,p_icon_library=>'FONTAPEX_LATEST'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#WORKSPACE_FILES#theme-staff#MIN#.css'
);
wwv_flow_imp.component_end;
end;
/
