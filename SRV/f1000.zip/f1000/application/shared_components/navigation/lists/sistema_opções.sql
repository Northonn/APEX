prompt --application/shared_components/navigation/lists/sistema_opções
begin
--   Manifest
--     LIST: Sistema Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(50355126106196204)
,p_name=>unistr('Sistema Op\00E7\00F5es')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(50355361577196205)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Vers\00E3o')
,p_list_item_link_target=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.:123:P123_ID_SISTEMA,P123_ID_TENANT:&P118_ID.,&P118_ID_TENANT.:'
,p_list_item_icon=>'fa-code-fork'
,p_list_text_01=>unistr('Permite realizar a cria\00E7\00E3o e altera\00E7\00E3o das vers\00F5es do sistema.')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
