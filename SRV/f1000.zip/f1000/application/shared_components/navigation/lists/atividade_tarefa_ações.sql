prompt --application/shared_components/navigation/lists/atividade_tarefa_ações
begin
--   Manifest
--     LIST: Atividade tarefa Ações
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(15714569812403824)
,p_name=>unistr('Atividade tarefa A\00E7\00F5es')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15714798695403825)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Copiar'
,p_list_item_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:202:P202_ID:&P205_ID.:'
,p_list_item_icon=>'fa-copy'
,p_list_text_06=>'u-success'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15715192293403826)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Excluir'
,p_list_item_link_target=>'f?p=&APP_ID.:204:&SESSION.::&DEBUG.:204:P204_ID:&P205_ID.:'
,p_list_item_icon=>'fa-trash'
,p_list_text_06=>'u-danger'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
