prompt --application/shared_components/navigation/lists/atividade_tarefa_opções
begin
--   Manifest
--     LIST: Atividade tarefa Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(15713655169398390)
,p_name=>unistr('Atividade tarefa Op\00E7\00F5es')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15713858329398391)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Colunas'
,p_list_item_link_target=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.:203:P203_ID:&P205_ID.:'
,p_list_item_icon=>'fa-edit'
,p_list_text_01=>unistr('Permite realizar a altera\00E7\00E3o dos artefatos.')
,p_list_text_06=>'u-hot'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
