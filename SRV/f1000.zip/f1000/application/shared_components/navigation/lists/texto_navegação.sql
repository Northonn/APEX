prompt --application/shared_components/navigation/lists/texto_navegação
begin
--   Manifest
--     LIST: Texto - navegação
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(54244818773426189)
,p_name=>unistr('Texto - navega\00E7\00E3o')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(54245290681433105)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Idiomas dos textos'
,p_list_item_link_target=>'f?p=&APP_ID.:232:&SESSION.::&DEBUG.:232:P232_ID_TEXTO,P232_ID_TENANT:&P230_ID.,&P230_ID_TENANT.:'
,p_list_item_icon=>'fa-language'
,p_list_text_01=>unistr('Compartilhamento de cadastro permite a reutiliza\00E7\00E3o de cadastros entre os tenants.')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
