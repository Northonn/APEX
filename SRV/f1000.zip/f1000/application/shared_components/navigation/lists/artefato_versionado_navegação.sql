prompt --application/shared_components/navigation/lists/artefato_versionado_navegação
begin
--   Manifest
--     LIST: Artefato Versionado Navegação
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(76934429397502341)
,p_name=>unistr('Artefato Versionado Navega\00E7\00E3o')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(77082635194678852)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Liberar artefato'
,p_list_item_link_target=>'f?p=&APP_ID.:234:&SESSION.::&DEBUG.:234:P234_ID:&P243_ID.:'
,p_list_item_icon=>'fa-unlock'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select id from srv_artefato_versionado where id = :P243_ID and data_checkin is not null'
,p_list_text_01=>unistr('Libera as altera\00E7\00F5es realizadas no artefato')
,p_list_text_06=>'u-success'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(76934635036502343)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('A\00E7\00E3o din\00E2mica')
,p_list_item_link_target=>'f?p=&APP_ID.:240:&SESSION.::&DEBUG.:240:P240_ID,P240_ID_TENANT:&P243_ID.,&P243_ID_TENANT.:'
,p_list_item_icon=>'fa-dynamic-content'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   return bo_srv_artefato_versionado.opcoes_versao(:P243_ID);',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>unistr('Controle de a\00E7\00E3o din\00E2mica da vers\00E3o do artefato')
,p_list_text_06=>'u-hot'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(77660927254361526)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Bot\00E3o a\00E7\00E3o')
,p_list_item_link_target=>'f?p=&APP_ID.:246:&SESSION.::&DEBUG.:246:P246_ID,P246_ID_TENANT:&P243_ID.,&P243_ID_TENANT.:'
,p_list_item_icon=>'fa-check-circle-o'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   return bo_srv_artefato_versionado.opcoes_versao(:P243_ID);',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>unistr('Controle de bot\00E3o a\00E7\00E3o da vers\00E3o do artefato')
,p_list_text_06=>'u-hot'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(77727269843581007)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Regra de execu\00E7\00E3o')
,p_list_item_link_target=>'f?p=&APP_ID.:250:&SESSION.::&DEBUG.:250:P250_ID,P250_ID_TENANT:&P243_ID.,&P243_ID_TENANT.:'
,p_list_item_icon=>'fa-area-chart'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   return bo_srv_artefato_versionado.opcoes_versao(:P243_ID);',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>unistr('Controle de regras de execu\00E7\00E3o da vers\00E3o do artefato')
,p_list_text_06=>'u-hot'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(77806859584790598)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Crud din\00E2mico')
,p_list_item_link_target=>'f?p=&APP_ID.:254:&SESSION.::&DEBUG.:254:P254_ID,P254_ID_TENANT:&P243_ID.,&P243_ID_TENANT.:'
,p_list_item_icon=>'fa-database'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   return bo_srv_artefato_versionado.opcoes_versao(:P243_ID);',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>unistr('Controle de crud din\00E2mico da vers\00E3o do artefato')
,p_list_text_06=>'u-hot'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(77120343672982722)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Releases'
,p_list_item_link_target=>'f?p=&APP_ID.:245:&SESSION.::&DEBUG.:245:P245_ID_ARTEFATO_VERSIONADO:&P243_ID.:'
,p_list_item_icon=>'fa-history'
,p_list_text_01=>'Controle de releases do artefato versionado'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
