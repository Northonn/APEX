prompt --application/shared_components/navigation/lists/agendamento_repetir_dias_da_semana
begin
--   Manifest
--     LIST: Agendamento repetir dias da semana
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(278724366186750757)
,p_name=>'Agendamento repetir dias da semana'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(278724630350750758)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Dias da Semana'
,p_list_text_03=>'data-id="1"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
