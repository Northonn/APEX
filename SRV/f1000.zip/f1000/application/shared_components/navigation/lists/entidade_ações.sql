prompt --application/shared_components/navigation/lists/entidade_ações
begin
--   Manifest
--     LIST: Entidade ações
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(211096937093997826)
,p_name=>unistr('Entidade a\00E7\00F5es')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12851042277811333)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Colunas'
,p_list_item_link_target=>'f?p=&APP_ID.:143:&SESSION.::&DEBUG.::P143_ID_ENTIDADE:&P140_ID.:'
,p_list_item_icon=>'fa-badges'
,p_list_text_01=>unistr('Permite realizar a cria\00E7\00E3o e altera\00E7\00E3o das colunas da entidade.')
,p_list_text_06=>'u-hot'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
