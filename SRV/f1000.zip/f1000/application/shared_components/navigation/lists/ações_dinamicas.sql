prompt --application/shared_components/navigation/lists/ações_dinamicas
begin
--   Manifest
--     LIST: Ações dinamicas
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(78594541718382494)
,p_name=>unistr('A\00E7\00F5es dinamicas')
,p_list_type=>'FUNCTION_RETURNING_SQL_QUERY'
,p_list_language=>'PLSQL'
,p_list_query=>'return PKG_UI.buscar_acoes(:P9000_ID,:P9000_PAGINA);'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp.component_end;
end;
/
