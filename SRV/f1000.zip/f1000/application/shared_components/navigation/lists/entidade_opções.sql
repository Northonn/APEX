prompt --application/shared_components/navigation/lists/entidade_opções
begin
--   Manifest
--     LIST: Entidade opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(12861892705935425)
,p_name=>unistr('Entidade op\00E7\00F5es')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12862002020935426)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Editar'
,p_list_item_link_target=>'f?p=&APP_ID.:142:&SESSION.::&DEBUG.:142:P142_ID:&P140_ID.:'
,p_list_item_icon=>'fa-edit'
,p_list_text_06=>'u-hot'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12871531090990274)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Copiar'
,p_list_item_link_target=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:139:P139_ID:&P140_ID.:'
,p_list_item_icon=>'fa-copy'
,p_list_text_06=>'u-success'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12862414759935427)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Excluir'
,p_list_item_link_target=>'f?p=&APP_ID.:144:&SESSION.::&DEBUG.::P144_ID:&P140_ID.:'
,p_list_item_icon=>'fa-trash'
,p_list_text_06=>'u-danger'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
