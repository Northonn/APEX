prompt --application/shared_components/navigation/lists/action_list_interactive_report1
begin
--   Manifest
--     LIST: Action list interactive report1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(53505747501523068)
,p_name=>'Action list interactive report1'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(53506067730523070)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Salvar dados'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-download'
,p_list_text_01=>unistr('Permite salvar o relat\00F3rio em diversos formatos')
,p_list_text_03=>unistr('data-id="irDownload" title="Permite salvar o relat\00F3rio em diversos formatos"')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(53506465690523072)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Ordenar'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-sort-amount-asc-alt'
,p_list_text_01=>'Permite ordenar a consulta por diversas colunas ao mesmo tempo'
,p_list_text_03=>'data-id="irOrdering" title="Permite ordenar a consulta por diversas colunas ao mesmo tempo"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(53506877336523072)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Colunas'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-columns'
,p_list_text_01=>'Permitir ocultar, mostrar e mover colunas'
,p_list_text_03=>'data-id="irColumn" title="Permitir ocultar, mostrar e mover colunas"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(53507202981523073)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Destacar'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-star-o'
,p_list_text_01=>unistr('Permite aplicar destaque as linhas de acordo com defini\00E7\00F5es realizadas pelo usu\00E1rio')
,p_list_text_03=>unistr('data-id="irHighlight" title="Permite aplicar destaque as linhas de acordo com defini\00E7\00F5es realizadas pelo usu\00E1rio"')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(53507685211523074)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Linhas por p\00E1gina')
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-layout-3row'
,p_list_text_01=>'Permite informar a quantidade de linhas que deseja apresentar na consulta'
,p_list_text_03=>'id="irRowsPerPage" title="Permite informar a quantidade de linhas que deseja apresentar na consulta"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
