prompt --application/shared_components/navigation/lists/tipo_de_tarefas_ações
begin
--   Manifest
--     LIST: Tipo de tarefas Ações
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(15977180143978112)
,p_name=>unistr('Tipo de tarefas A\00E7\00F5es')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15977387745978113)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Copiar'
,p_list_item_link_target=>'f?p=&APP_ID.:208:&SESSION.::&DEBUG.:208:P208_ID:&P211_ID.:'
,p_list_item_icon=>'fa-copy'
,p_list_text_06=>'u-success'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15977723409978128)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Excluir'
,p_list_item_link_target=>'f?p=&APP_ID.:210:&SESSION.::&DEBUG.:210:P210_ID:&P211_ID.:'
,p_list_item_icon=>'fa-trash'
,p_list_text_06=>'u-danger'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
