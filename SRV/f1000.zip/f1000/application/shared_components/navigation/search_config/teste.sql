prompt --application/shared_components/navigation/search_config/teste
begin
--   Manifest
--     SEARCH CONFIG: Teste
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(74070684683996485)
,p_label=>'Teste'
,p_static_id=>'teste'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'SRV_ARTEFATO'
,p_searchable_columns=>'TITULO_ARTEFATO:DESCRICAO_ARTEFATO:AJUDA:ARQUIVO_FONTE:CODIGO_ARTEFATO:LINGUAGEM:TIPO_ARTEFATO'
,p_pk_column_name=>'ID'
,p_title_column_name=>'TITULO_ARTEFATO'
,p_subtitle_column_name=>'DESCRICAO_ARTEFATO'
,p_description_column_name=>'AJUDA'
,p_badge_column_name=>'ID_DESENVOLVEDOR'
,p_last_modified_column_name=>'DATA_ALTERACAO'
,p_custom_01_column_name=>'CODIGO_ARTEFATO'
,p_custom_02_column_name=>'LINGUAGEM'
,p_custom_03_column_name=>'ID_ANALISTA'
,p_score_column_name=>'ID'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:153:&APP_SESSION.::&DEBUG.::P153_ID:&ID.'
,p_icon_source_type=>'INITIALS'
);
wwv_flow_imp.component_end;
end;
/
