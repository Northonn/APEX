prompt --application/shared_components/email/templates/alteracoes_na_area_do_chamado_prioridade_prazo
begin
--   Manifest
--     REPORT LAYOUT: Alteracoes na area do chamado prioridade prazo
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(269851131317861013)
,p_name=>'Alteracoes na area do chamado prioridade prazo'
,p_static_id=>'ALTERACOES_NA_AREA_DO_CHAMADO_PRIORIDADE_PRAZO'
,p_version_number=>2
,p_subject=>unistr('Altera\00E7\00F5es no chamado NG')
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<strong>Confirma\00E7\00E3o de altera\00E7\00F5es no chamado para o sistema NG</strong><br>'),
'<br>',
unistr('<strong>Altera\00E7\00F5es no chamado:</strong> #ID_CHAMADO#<br>'),
unistr('<strong>Respons\00E1vel pelas altera\00E7\00F5es:</strong> #USUARIO_NOME#<br>'),
unistr('<strong>\00C1rea do chamado:</strong> #AREA_CHAMADO#<br>'),
'<strong>Prioridade:</strong> #PRIORIDADE#<br>',
'<strong>Prazo:</strong> #PRAZO#<br>',
unistr('<strong>T\00EDtulo:</strong> #TITULO#<br>'),
unistr('<strong>Descri\00E7\00E3o:</strong> #DESCRICAO#<br>'),
'<br>',
'<a href="https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com/ords/r/srvdev/ng-srv/sup-consulta-chamado?session=704047012200768&P140_ABRE_CHAT=#ID_CHAMADO#" style="font-size: 14px;">Visite o SRV para acompanhar o progresso do seu chamado'
||'</a>.'))
,p_html_header=>unistr('<b style="font-size: 24px;">Altera\00E7\00F5es no chamado NG</b>')
,p_html_footer=>unistr('N\00E3o responder esse e-mail')
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
