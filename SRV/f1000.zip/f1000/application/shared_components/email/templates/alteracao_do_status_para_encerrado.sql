prompt --application/shared_components/email/templates/alteracao_do_status_para_encerrado
begin
--   Manifest
--     REPORT LAYOUT: Alteracao do status para encerrado
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(275703650236855957)
,p_name=>'Alteracao do status para encerrado'
,p_static_id=>'ALTERACAO_DO_STATUS_PARA_ENCERRADO'
,p_version_number=>2
,p_subject=>'Chamado encerrado'
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<strong>Confirma\00E7\00E3o do encerramento do chamado para o sistema NG</strong><br>'),
'<br>',
'<strong>O chamado foi liberado pelo setor de qualidade para testes</strong><br>',
'<strong>Solicitante:</strong> #USUARIO_NOME#<br>',
unistr('<strong>N\00FAmero do chamado:</strong> #ID_CHAMADO#<br>'),
'<br>',
unistr('<a href="https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com/ords/r/srvdev/ng-srv/sup-consulta-chamado?session=704047012200768&P140_ABRE_CHAT=#ID_CHAMADO#" style="font-size: 14px;">Visite o SRV, utilize a op\00E7\00E3o de movimenta\00E7\00E3o do chamad')
||'o para solicitar maior prazo de testes</a>.'))
,p_html_header=>'<b style="font-size: 24px;">Chamado encerrado</b>'
,p_html_footer=>unistr('N\00E3o responder esse e-mail')
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
