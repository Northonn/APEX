prompt --application/shared_components/data_profiles/list_language
begin
--   Manifest
--     DATA PROFILE: list-language
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(202274418136837970)
,p_name=>'list-language'
,p_format=>'JSON'
,p_row_selector=>'links'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(202274611376837973)
,p_data_profile_id=>wwv_flow_imp.id(202274418136837970)
,p_name=>'REL'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'rel'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(202274966759837974)
,p_data_profile_id=>wwv_flow_imp.id(202274418136837970)
,p_name=>'HREF'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'href'
);
wwv_flow_imp.component_end;
end;
/
