prompt --application/pages/page_00220
begin
--   Manifest
--     PAGE: 00220
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>220
,p_name=>unistr('Artefato - Vers\00F5es')
,p_alias=>unistr('ARTEFATO-VERS\00D5ES')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Vers\00F5es do artefato')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-actions{',
'    display: none;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240423131854'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76735639341985240)
,p_plug_name=>'Cards'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.id,',
'    a.id_tenant,',
'    a.id_artefato,',
'    a.data_checkin,',
'    e.nome as des_usuario,',
'    c.nome_aplicacao||'' - ''|| d.versao as des_versao,',
'    pkg_util.dominio_retorna_tag(''srv_artefato_versionado'',''situacao'',a.situacao) as des_situacao',
'    /*pkg_componentes.html_card_colunas(',
'        ''srv_artefato_versionado.especificacao_tecnica_l'',',
'        a.especificacao_tecnica',
'    ) as atributo1 */   ',
'from srv_artefato_versionado a',
'left join srv_aplicacao_versionada b on b.id = a.id_aplicacao_versionada',
'left join srv_aplicacao c on c.id = b.id_aplicacao',
'left join srv_sistema_versionado d on d.id = b.id_sistema_versionado',
'left join mpd_usuario e on e.id = a.id_usuario_checkin',
'where a.id_artefato = :P220_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P220_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(76735766284985241)
,p_region_id=>wwv_flow_imp.id(76735639341985240)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'DES_VERSAO'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DES_SITUACAO'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.',
'</div>'))
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'DES_USUARIO'
,p_badge_css_classes=>'u-warning'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(76735851795985242)
,p_card_id=>wwv_flow_imp.id(76735766284985241)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:221:&SESSION.::&DEBUG.:221:P221_ID,P221_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(78687719613497928)
,p_card_id=>wwv_flow_imp.id(76735766284985241)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_ID,P9000_PAGINA:&ID.,220'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(379198181218221527)
,p_plug_name=>'button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>'<div id="active_facets"></div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75733027337317604)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(76735639341985240)
,p_button_name=>'BTN_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'ORDER_BY_ITEM'
,p_button_redirect_url=>'f?p=&APP_ID.:221:&SESSION.::&DEBUG.:221:P221_ID_ARTEFATO:&P220_ID.'
,p_button_css_classes=>'u-pullRight'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75789651596529242)
,p_name=>'P220_ID_TENANT'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(218636511250120244)
,p_name=>'P220_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75736411054317629)
,p_name=>'onDialogClosedCards'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(76735639341985240)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75736933167317632)
,p_event_id=>wwv_flow_imp.id(75736411054317629)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(76735639341985240)
);
wwv_flow_imp.component_end;
end;
/
