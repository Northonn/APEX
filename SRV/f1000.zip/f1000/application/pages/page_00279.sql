prompt --application/pages/page_00279
begin
--   Manifest
--     PAGE: 00279
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>279
,p_name=>'Funcionalidades - Lista de funcionalidades do grupo'
,p_alias=>'FUNCIONALIDADES-LISTA-DE-FUNCIONALIDADES-DO-GRUPO'
,p_page_mode=>'MODAL'
,p_step_title=>'Funcionalidades - Lista de funcionalidades do grupo'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function goto_modal(p1)',
'{',
' var url = "f?p=&APP_ID.:455:&SESSION.";',
' var url1 = ''::NO::P455_METADATA_ENTIDADE_ID:''+p1',
' var l = ("javascript:apex.navigation.dialog(''f?p=&APP_ID.:455:&SESSION.").length;',
' var f = url.slice(0,l) + url.slice(l) + url1 ;',
' f = f.replace(":::::",":");',
' console.log(f);',
' window.location.href = f;',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("h1").append($("#icon_info"));',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-actions{',
'    display: none;',
'}',
'',
'.a-CardView-header{',
'    background-color: aliceblue;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'}',
'',
'.a-CardView-actions{',
'    padding: 0px;',
'}',
'',
'.a-CardView-items{',
'    grid-gap: 5px;',
'}'))
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_page_component_map=>'24'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240325205048'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(237234212093970230)
,p_plug_name=>'Pesquisa'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>60
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(237234377744970232)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(237234377744970232)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select A.ID,',
'       A.ID_TENANT,',
'       A.ID_GRUPO_FUNCIONALIDADE,',
'       A.ID_ARTEFATO_VERSIONADO,',
'       C.TITULO_ARTEFATO||'' (''||C.CODIGO_ARTEFATO||'')'' As TITULO     ',
'  from SRV_GRUPO_FUNCIONALIDADE_ARTEFATO a',
'  join srv_artefato_versionado b',
'  on b.id = a.id_artefato_versionado',
'  join srv_artefato c',
'  on c.id = b.id_artefato',
'  where A.id_artefato_versionado = :P279_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P279_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(79832392522373704)
,p_region_id=>wwv_flow_imp.id(237234377744970232)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITULO'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(79833460275373709)
,p_card_id=>wwv_flow_imp.id(79832392522373704)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:280:&SESSION.::&DEBUG.:280:P280_ID,P280_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(79834012083373710)
,p_card_id=>wwv_flow_imp.id(79832392522373704)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'BTN_EDITAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:280:&SESSION.::&DEBUG.:280:P280_ID,P280_EDITAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(79832800028373707)
,p_card_id=>wwv_flow_imp.id(79832392522373704)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_EXCLUIR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:281:&SESSION.::&DEBUG.:281:P281_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link u-danger-text'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79835004196373713)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(237234212093970230)
,p_button_name=>'REL_NOVO'
,p_button_static_id=>'REL_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--gapLeft:t-Button--padRight:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'ORDER_BY_ITEM'
,p_button_redirect_url=>'f?p=&APP_ID.:280:&SESSION.::&DEBUG.:280::'
,p_button_css_classes=>'u-pullRight'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(237248365113970339)
,p_name=>'P279_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(237234212093970230)
,p_prompt=>'Search'
,p_placeholder=>'Busca por srv_artefato.titulo_artefato_l'
,p_source=>'TITULO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(237249007070970345)
,p_name=>'P279_NOME_MENU'
,p_item_sequence=>1
,p_item_plug_id=>wwv_flow_imp.id(237234212093970230)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_prompt=>'srv_artefato.titulo_artefato_l'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411460000998121802)
,p_name=>'P279_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(79837369261373736)
,p_computation_sequence=>20
,p_computation_item=>'P279_NOME_MENU'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.titulo_artefato ',
'from srv_artefato a',
'join srv_artefato_versionado b',
'on b.id_artefato = a.id',
'where b.id = :P279_ID'))
,p_compute_when=>'P279_ID'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79849508343373770)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>100
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79850012233373771)
,p_event_id=>wwv_flow_imp.id(79849508343373770)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79847295512373765)
,p_name=>'onDialogClosedBTN_NOVO'
,p_event_sequence=>350
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(79835004196373713)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79848277179373767)
,p_event_id=>wwv_flow_imp.id(79847295512373765)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(237234377744970232)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79812745435511016)
,p_name=>'onDialogClosedLista'
,p_event_sequence=>370
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(237234377744970232)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79812861543511017)
,p_event_id=>wwv_flow_imp.id(79812745435511016)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(237234377744970232)
);
wwv_flow_imp.component_end;
end;
/
