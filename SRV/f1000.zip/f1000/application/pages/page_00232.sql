prompt --application/pages/page_00232
begin
--   Manifest
--     PAGE: 00232
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>232
,p_name=>unistr('Textos - Tradu\00E7\00F5es')
,p_alias=>unistr('TEXTOS-TRADU\00C7\00D5ES')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Tradu\00E7\00F5es')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'.a-CardView-header{',
'    background-color: aliceblue;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'}'))
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240315184813'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142898153547802613)
,p_plug_name=>'Lista G'
,p_region_css_classes=>'u-danger-text'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'   A.ID,',
'   A.TEXTO,',
'   B.NOME',
'from SRV_APLICACAO_TEXTO_TRADUZIDO A',
'join srv_idioma b on b.id = a.ID_IDIOMA',
'where a.ID_APLICACAO_TEXTO = :P232_ID_TEXTO'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P232_ID_TEXTO'
,p_plug_query_num_rows=>15
,p_plug_query_no_data_found=>unistr('Nenhuma tradu\00E7\00E3o dispon\00EDvel.')
,p_attribute_02=>'NOME'
,p_attribute_06=>'TEXTO'
,p_attribute_16=>'f?p=&APP_ID.:231:&SESSION.::&DEBUG.:231:P231_ID:&ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303465746671903950)
,p_plug_name=>'button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>'<div id="active_facets"></div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(304280701249232933)
,p_plug_name=>'Lista G'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select A.ID,',
'       A.DS_VARIAVEL,',
'       B.IDIOMA',
'  from SYS_VARIAVEL_DESCRICAO A',
'  join adm_idioma b on b.id = a.id_idioma',
'  where a.id_variavel = :P232_ID_VARIAVEL'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P232_ID_TEXTO'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'NEVER'
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(54264099941506517)
,p_region_id=>wwv_flow_imp.id(304280701249232933)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'IDIOMA'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DS_VARIAVEL'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'IDIOMA'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(54264562273506519)
,p_card_id=>wwv_flow_imp.id(54264099941506517)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>unistr('Mais informa\00E7\00F5es')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:162:&SESSION.::&DEBUG.::P162_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
,p_build_option_id=>wwv_flow_imp.id(306296283938923705)
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(54265089473506523)
,p_card_id=>wwv_flow_imp.id(54264099941506517)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>unistr('Op\00E7\00F5es')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:190:&SESSION.::&DEBUG.:190:P190_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
,p_build_option_id=>wwv_flow_imp.id(306296283938923705)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54262886645506512)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(142898153547802613)
,p_button_name=>'BTN_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'ORDER_BY_ITEM'
,p_button_redirect_url=>'f?p=&APP_ID.:231:&SESSION.::&DEBUG.:231:P231_ID_APLICACAO_TEXTO,P231_ID_TENANT:&P232_ID_TEXTO.,&P232_ID_TENANT.'
,p_button_css_classes=>'u-pullRight'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75848617749825244)
,p_name=>'P232_ID_TENANT'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142900474799802620)
,p_name=>'P232_ID_TEXTO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54266122661506526)
,p_name=>'OnAfterClosed G'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(304280701249232933)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54266655459506530)
,p_event_id=>wwv_flow_imp.id(54266122661506526)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(304280701249232933)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17943046706553037)
,p_name=>'onClose G'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(142898153547802613)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17943186758553038)
,p_event_id=>wwv_flow_imp.id(17943046706553037)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(142898153547802613)
);
wwv_flow_imp.component_end;
end;
/
