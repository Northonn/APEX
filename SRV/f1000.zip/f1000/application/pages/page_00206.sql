prompt --application/pages/page_00206
begin
--   Manifest
--     PAGE: 00206
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>206
,p_name=>'Atividade Tarefa - Mais detalhes'
,p_alias=>'ATIVIDADE-TAREFA-MAIS-DETALHES'
,p_page_mode=>'MODAL'
,p_step_title=>'Mais detalhes da atividade tarefa'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'ANTHONI'
,p_last_upd_yyyymmddhh24miss=>'20240222182802'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27662512354054939)
,p_plug_name=>'Artefatos - Mais detalhes do artefato'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NOME,',
'       DESCRICAO,',
'       STATUS,',
'    CASE',
'    WHEN STATUS = 1 THEN ''Ativado''',
'    WHEN STATUS = 2 THEN ''Desativado''',
'    ELSE ''INVALIDO''',
'   END DS_STATUS',
'  from SRV_ATIVIDADE_TAREFAS_1'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15720390935431143)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15535887512865917)
,p_name=>'P206_NOME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_item_source_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_prompt=>'Nome da atividade tarefa'
,p_source=>'NOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="text-align: start;"'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(306464112839923826)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_help_text=>'Nome da atividade tarefa inclusa no banco de dados'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15535984555865918)
,p_name=>'P206_DESCRICAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_item_source_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_prompt=>unistr('Descri\00E7\00E3o da atividade tarefa')
,p_source=>'DESCRICAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="text-align: start;"'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(306464112839923826)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_help_text=>unistr('Descri\00E7\00E3o da atividade tarefa inclusa no banco de dados')
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15536095934865919)
,p_name=>'P206_STATUS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_item_source_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15536188102865920)
,p_name=>'P206_DS_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_item_source_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_prompt=>'Status'
,p_source=>'DS_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="text-align: start;"'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(306464112839923826)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_help_text=>'Status da atividade tarefa inclusa no banco de dados'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27663865253054946)
,p_name=>'P206_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_item_source_plug_id=>wwv_flow_imp.id(27662512354054939)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15734312385431177)
,p_name=>'onClickCancel'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15720390935431143)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15734883018431178)
,p_event_id=>wwv_flow_imp.id(15734312385431177)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15733414917431175)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Process form Artefatos - Mais detalhes do artefato'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_ATIVIDADE_TAREFA'
,p_attribute_04=>'GET_ROW'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>15733414917431175
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15536221703865921)
,p_page_process_id=>wwv_flow_imp.id(15733414917431175)
,p_page_id=>206
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P206_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15536391075865922)
,p_page_process_id=>wwv_flow_imp.id(15733414917431175)
,p_page_id=>206
,p_name=>'p_nome'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P206_NOME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15536479116865923)
,p_page_process_id=>wwv_flow_imp.id(15733414917431175)
,p_page_id=>206
,p_name=>'p_descricao'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P206_DESCRICAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15536544977865924)
,p_page_process_id=>wwv_flow_imp.id(15733414917431175)
,p_page_id=>206
,p_name=>'p_status'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P206_STATUS'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15733097114431174)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(27662512354054939)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Artefatos - Mais detalhes do artefato'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>15733097114431174
);
wwv_flow_imp.component_end;
end;
/
