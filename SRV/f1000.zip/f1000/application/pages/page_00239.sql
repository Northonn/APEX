prompt --application/pages/page_00239
begin
--   Manifest
--     PAGE: 00239
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>239
,p_name=>'Artefatos - Auditoria'
,p_alias=>'ARTEFATOS-AUDITORIA'
,p_step_title=>'Artefatos - Auditoria'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-actions{',
'    display: none;',
'}',
'',
'.a-CardView-header{',
'    background-color: aliceblue;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'}',
'',
'.t-ButtonRegion-buttons',
'{',
' display: flex;',
' justify-content: flex-end;',
' align-items: center;',
'}',
'',
'.t-Region',
'{',
'    border: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(306307910376923732)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'24'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240228204335'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65536824754592718)
,p_plug_name=>'Lista de artefatos sem telas'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306342585759923752)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65536537207592715)
,p_plug_name=>'Pesquisa'
,p_parent_plug_id=>wwv_flow_imp.id(65536824754592718)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>30
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(77332412183004127)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77332412183004127)
,p_plug_name=>'Lista'
,p_parent_plug_id=>wwv_flow_imp.id(65536824754592718)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'   ar.id,',
'   ar.id_tenant,',
'   ( select l1.razao_social from mpd_tenant l1 where l1.id = ar.id_tenant) id_tenant_l$1,',
'   ar.id_aplicacao,',
'   ( select l2.nome_aplicacao from srv_aplicacao l2 where l2.id = ar.id_aplicacao) id_aplicacao_l$2,',
'   ar.titulo_artefato,',
'   ar.descricao_artefato,',
'   ar.ajuda,',
'   ar.arquivo_fonte,',
'   ar.codigo_artefato,',
'   ar.linguagem,',
'   ar.tipo_artefato,',
'   ar.id_analista,',
'   ( select l3.nome from mpd_usuario l3 where l3.id = ar.id_analista) id_analista_l$3,',
'   ar.id_desenvolvedor,',
'   ( select l4.nome from mpd_usuario l4 where l4.id = ar.id_desenvolvedor) id_desenvolvedor_l$4,',
'   ar.id_usuario_incluiu,',
'   ar.data_inclusao,',
'   ar.id_usuario_alterou,',
'   ar.data_alteracao,',
'   ap.nome_aplicacao,',
'    pkg_componentes.html_card_colunas(',
'        ''srv_artefato.tipo_artefato_l'',',
'        pkg_util.dominio_retorna_tag(''srv_artefato'',''tipo_artefato'',tipo_artefato)',
'    ) as atributo1,',
'    pkg_componentes.html_card_colunas(',
'        ''srv_artefato.linguagem_l'',',
'        pkg_util.dominio_retorna_tag(''srv_artefato'',''linguagem'',linguagem)',
'    ) as atributo2,',
'    pkg_componentes.html_card_colunas(',
'        ''srv_artefato.nome_aplicacao_l'',',
'        ap.nome_aplicacao',
'    ) as atributo3',
'from srv_artefato ar',
'join srv_aplicacao ap on ar.id_aplicacao = ap.id',
'where tipo_artefato = ''TE''',
'and not exists ( select 1 from APEX_APPLICATION_PAGES where page_id = ar.codigo_artefato and application_id = ap.codigo_aplicacao ) ',
'order by codigo_artefato;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(65556088091693331)
,p_region_id=>wwv_flow_imp.id(77332412183004127)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITULO_ARTEFATO'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DESCRICAO_ARTEFATO'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.',
'    &ATRIBUTO3!RAW.',
'</div>',
'',
'',
'',
'',
'',
'',
'',
''))
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'CODIGO_ARTEFATO'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(69281581731779704)
,p_card_id=>wwv_flow_imp.id(65556088091693331)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>10
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:151:P151_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65536931830592719)
,p_plug_name=>'Lista de telas sem artefatos'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306342585759923752)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65537025316592720)
,p_plug_name=>'Lista 1'
,p_parent_plug_id=>wwv_flow_imp.id(65536931830592719)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select ',
'    PAGE_NAME,',
'    WORKSPACE_DISPLAY_NAME,',
'    APPLICATION_ID,',
'    APPLICATION_NAME,',
'    PAGE_ID ,',
'    pkg_componentes.html_card_colunas(',
'        ''Workspace'',',
'        WORKSPACE_DISPLAY_NAME,',
'        ''s''',
'    ) as atributo1,',
'    pkg_componentes.html_card_colunas(',
unistr('        ''C\00F3digo da aplica\00E7\00E3o'','),
'        APPLICATION_ID,',
'        ''s''',
'    ) as atributo2',
'    from APEX_APPLICATION_PAGES a',
'join srv_aplicacao b on b.codigo_aplicacao = a.application_id',
'where not exists ( select 1 from srv_artefato c where c.id_aplicacao = b.id and a.page_id = c.codigo_artefato )',
'order by APPLICATION_NAME,PAGE_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(65537186897592721)
,p_region_id=>wwv_flow_imp.id(65537025316592720)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'PAGE_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'APPLICATION_NAME'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.',
'</div>',
'',
'',
'',
'',
'',
'',
'',
''))
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'PAGE_ID'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'PAGE_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65537994462592729)
,p_plug_name=>'Pesquisa 1'
,p_parent_plug_id=>wwv_flow_imp.id(65536931830592719)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(65537025316592720)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77331727280004117)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65536624322592716)
,p_name=>'P239_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(65536537207592715)
,p_prompt=>'Nome'
,p_placeholder=>'Buscar por nome'
,p_source=>'TITULO_ARTEFATO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65538046558592730)
,p_name=>'P239_SEARCH1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(65537994462592729)
,p_prompt=>'Nome'
,p_placeholder=>'Buscar por nome'
,p_source=>'PAGE_NAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65538132213592731)
,p_name=>'P239_CODIGO1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(65537994462592729)
,p_prompt=>unistr('C\00F3digo')
,p_source=>'PAGE_ID'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'EQUALS'
,p_attribute_07=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65538256339592732)
,p_name=>'P239_CODIGO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(65536537207592715)
,p_prompt=>unistr('C\00F3digo')
,p_source=>'CODIGO_ARTEFATO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'EQUALS'
,p_attribute_07=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(65580031830693427)
,p_name=>'onCloseArtefatoGrid'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(77332412183004127)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(65582072687693432)
,p_event_id=>wwv_flow_imp.id(65580031830693427)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77332412183004127)
);
wwv_flow_imp.component_end;
end;
/
