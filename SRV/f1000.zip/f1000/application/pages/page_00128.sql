prompt --application/pages/page_00128
begin
--   Manifest
--     PAGE: 00128
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>128
,p_name=>'Aplicacao - Deploy'
,p_alias=>'APLICACAO-DEPLOY'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Deploy de aplica\00E7\00E3o')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_protection_level=>'C'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when=>'P128_VISUALIZAR'
,p_page_component_map=>'16'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240417124459'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(247623401700235216)
,p_plug_name=>'Form'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86174859611218714)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(247623401700235216)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_CONFIRMAR'
,p_button_position=>'CREATE'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85957703010727004)
,p_name=>'P128_ID_NOVA_APLICACAO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(247623401700235216)
,p_prompt=>unistr('C\00F3digo da nova aplica\00E7\00E3o')
,p_placeholder=>unistr('Informe o c\00F3digo da nova aplica\00E7\00E3o')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>unistr('Aten\00E7\00E3o! Se informar o c\00F3digo de aplica\00E7\00E3o que j\00E1 existe o procedimento de deploy ir\00E1 substituir a aplica\00E7\00E3o.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170535010725377629)
,p_name=>'P128_ESQUEMA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(247623401700235216)
,p_prompt=>unistr('\00C1rea de trabalho')
,p_placeholder=>unistr('Selecione a \00E1rea de trabalho')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select WORKSPACE d, WORKSPACE_ID r from APEX_WORKSPACES'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170535908143377645)
,p_name=>'P128_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324442847017556626)
,p_name=>'P128_RESULTADO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324442976001556627)
,p_name=>'P128_RESULTADO_MENSAGEM'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(324645003302257383)
,p_name=>'P128_DUPLICAR'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(546502685187968853)
,p_name=>'P128_EDITAR'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(562013558785184312)
,p_name=>'P128_VISUALIZAR'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86177833595218738)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Deploy'
,p_process_sql_clob=>'deploy_aplicacao(:P128_ESQUEMA, :P128_ID, :P128_ID_NOVA_APLICACAO);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86177833595218738
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86178229320218740)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Closed'
,p_attribute_01=>'P128_RESULTADO_MENSAGEM'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86178229320218740
);
wwv_flow_imp.component_end;
end;
/
