prompt --application/pages/page_00211
begin
--   Manifest
--     PAGE: 00211
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>211
,p_name=>unistr('Tipo de Tarefa - Op\00E7\00F5es')
,p_alias=>unistr('TIPO-DE-TAREFA-OP\00C7\00D5ES')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Tipo de Tarefa - Op\00E7\00F5es')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306325325666923741)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240209192518'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58497393785355820)
,p_plug_name=>unistr('A\00E7\00F5es')
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58497657391355822)
,p_plug_name=>unistr('Op\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(58497393785355820)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(15976532466976847)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(306448239332923813)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58497714651355823)
,p_plug_name=>unistr('A\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(58497393785355820)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Cards--compact:t-Cards--displayIcons:t-Cards--spanHorizontally:t-Cards--hideBody:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(15977180143978112)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(306442605139923810)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58499327558355830)
,p_name=>'P211_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(58497393785355820)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
