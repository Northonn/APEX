prompt --application/pages/page_09992
begin
--   Manifest
--     PAGE: 09992
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9992
,p_name=>unistr('Aviso de confirma\00E7\00E3o de e-mail')
,p_alias=>unistr('AVISO-DE-CONFIRMA\00C7\00C3O-DE-E-MAIL')
,p_step_title=>unistr('Aviso de confirma\00E7\00E3o de e-mail')
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(187698945380989659)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Login-logo{',
'    border-radius: 100px;',
'}'))
,p_step_template=>wwv_flow_imp.id(306322751452923739)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'SRV-LAB'
,p_last_upd_yyyymmddhh24miss=>'20230811201511'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(632569347436160412)
,p_plug_name=>'Cadastro confirmado'
,p_icon_css_classes=>'fa-check-circle'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(306411171886923787)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(527831016045769405)
,p_plug_name=>'Sucesso'
,p_parent_plug_id=>wwv_flow_imp.id(632569347436160412)
,p_region_css_classes=>'st-back-transp'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--defaultIcons:t-Alert--success:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>20
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="st-titulo-login">Agora falta pouco!</div>',
'<br>',
'<div class="st-sub-titulo-login">Para confirmar seu cadastro, acesse seu e-mail por favor, clique no link "Confirme seu cadastro"</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
