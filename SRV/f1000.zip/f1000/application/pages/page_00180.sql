prompt --application/pages/page_00180
begin
--   Manifest
--     PAGE: 00180
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>180
,p_name=>'Idioma'
,p_alias=>'IDIOMA'
,p_step_title=>'Idioma'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$("h1").append($("#icon_info"));'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'24'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240321172740'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26631843545719636)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38602670097044161)
,p_plug_name=>'Lista'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'   NOME,',
'   CODIGO,',
'   SITUACAO,',
'   pkg_util.dominio_retorna_tag(''SRV_IDIOMA'',''CODIGO'',codigo) DS_CODIGO,',
'   pkg_util.dominio_retorna_tag(''SRV_IDIOMA'',''SITUACAO'',SITUACAO) DS_SITUACAO,',
'    pkg_componentes.html_card_colunas(',
'        ''SRV_IDIOMA.NOME_L'',',
'        NOME',
'    ) as atributo1,',
'    pkg_componentes.html_card_colunas(',
'        ''SRV_IDIOMA.CODIGO_L'',',
'        CODIGO',
'    ) as atributo2',
'from SRV_IDIOMA'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(14581234708878852)
,p_region_id=>wwv_flow_imp.id(38602670097044161)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CODIGO'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'DS_CODIGO'
,p_icon_position=>'START'
,p_badge_column_name=>'DS_SITUACAO'
,p_badge_label=>unistr('Situa\00E7\00E3o')
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(14581705954878854)
,p_card_id=>wwv_flow_imp.id(14581234708878852)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:181:&SESSION.::&DEBUG.:141:P181_ID,P181_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link padding-none margin-top-md '
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(14582399764878855)
,p_card_id=>wwv_flow_imp.id(14581234708878852)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:182:&SESSION.::&DEBUG.::P182_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link padding-none margin-top-md'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(79783624139757204)
,p_card_id=>wwv_flow_imp.id(14581234708878852)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>40
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_ID,P9000_PAGINA:&ID.,&APP_PAGE_ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link padding-none margin-top-md'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38602861959044161)
,p_plug_name=>'Pesquisa'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-sm'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>5
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(38602670097044161)
,p_attribute_01=>'0'
,p_attribute_02=>'Y'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(106695913162359974)
,p_plug_name=>'Button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>7
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14589290851878876)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(106695913162359974)
,p_button_name=>'Novo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:181:&SESSION.::&DEBUG.:181::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70367360532546839)
,p_name=>'P180_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38602861959044161)
,p_prompt=>'Search'
,p_placeholder=>'Buscar por SRV_IDIOMA.NOME_L ou SRV_IDIOMA.CODIGO_L'
,p_source=>'NOME,CODIGO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70367448422546840)
,p_name=>'P180_SITUACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38602861959044161)
,p_prompt=>'SRV_IDIOMA.SITUACAO_L'
,p_source=>'SITUACAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'D_SRV_IDIOMA.SITUACAO'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''srv_idioma'',''situacao'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>true
,p_suggestions_type=>'DYNAMIC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14591008977878882)
,p_name=>'onCloseLista'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(38602670097044161)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14591565043878883)
,p_event_id=>wwv_flow_imp.id(14591008977878882)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38602670097044161)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54493154950014519)
,p_event_id=>wwv_flow_imp.id(14591008977878882)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38602861959044161)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54492645745014514)
,p_name=>'onCloseNOVO'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(14589290851878876)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54492701773014515)
,p_event_id=>wwv_flow_imp.id(54492645745014514)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38602670097044161)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54492917379014517)
,p_event_id=>wwv_flow_imp.id(54492645745014514)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38602861959044161)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(71094121046691822)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>90
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(71094566856691824)
,p_event_id=>wwv_flow_imp.id(71094121046691822)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp.component_end;
end;
/
