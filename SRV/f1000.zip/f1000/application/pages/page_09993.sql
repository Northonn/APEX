prompt --application/pages/page_09993
begin
--   Manifest
--     PAGE: 09993
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9993
,p_name=>unistr('Aviso de convite j\00E1 utilizado')
,p_alias=>unistr('AVISO-DE-CONVITE-J\00C1-UTILIZADO')
,p_step_title=>unistr('Aviso de convite j\00E1 utilizado')
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(187698945380989659)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Login-logo{',
'    border-radius: 100px;',
'}'))
,p_step_template=>wwv_flow_imp.id(306322751452923739)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'SRV-LAB'
,p_last_upd_yyyymmddhh24miss=>'20230722211301'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(584479134560819205)
,p_plug_name=>'Cadastro confirmado'
,p_icon_css_classes=>'fa-check-circle'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(306411171886923787)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(479740803170428198)
,p_plug_name=>'Erro'
,p_parent_plug_id=>wwv_flow_imp.id(584479134560819205)
,p_region_css_classes=>'st-back-transp'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>20
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<div class="st-titulo-login">N\00E3o foi p\00F3ssivel acessar o convite</div>'),
'<br>',
unistr('<div class="st-sub-titulo-login">Poss\00EDveis causas</div>'),
unistr('<div class="st-detalhe-login">\2022 O convite j\00E1 foi utlizado</div>'),
unistr('<div class="st-detalhe-login">\2022 O convite foi exclu\00EDdo ou n\00E3o existe</div>'),
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(236726834261483055)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(584479134560819205)
,p_button_name=>'EXEC'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Acessar'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999::'
,p_database_action=>'INSERT'
);
wwv_flow_imp.component_end;
end;
/
