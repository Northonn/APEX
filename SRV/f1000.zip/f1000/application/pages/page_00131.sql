prompt --application/pages/page_00131
begin
--   Manifest
--     PAGE: 00131
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>131
,p_name=>unistr('Menu - A\00E7\00F5es')
,p_alias=>unistr('MENU-A\00C7\00D5ES')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Menu - A\00E7\00F5es')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function goto_modal(p1)',
'{',
' var url = "f?p=&APP_ID.:455:&SESSION.";',
' var url1 = ''::NO::P455_METADATA_ENTIDADE_ID:''+p1',
' var l = ("javascript:apex.navigation.dialog(''f?p=&APP_ID.:455:&SESSION.").length;',
' var f = url.slice(0,l) + url.slice(l) + url1 ;',
' f = f.replace(":::::",":");',
' console.log(f);',
' window.location.href = f;',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("h1").append($("#icon_info"));',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-actions{',
'    display: none;',
'}',
'',
'.a-CardView-header{',
'    background-color: aliceblue;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'}',
'',
'.a-CardView-actions{',
'    padding: 0px;',
'}',
'',
'.a-CardView-items{',
'    grid-gap: 5px;',
'}'))
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_page_component_map=>'24'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240325205543'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77853179770876919)
,p_plug_name=>'Pesquisa'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>60
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(77853345421876921)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77853345421876921)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id,',
'       a.id_tenant,',
'       a.id_menu,',
'       a.id_artefato_versionado,',
'       c.titulo_artefato',
'  from srv_menu_acao a',
'  join srv_artefato_versionado b ',
'  on b.id = a.id_artefato_versionado',
'  join srv_artefato c',
'  on c.id = b.id_artefato',
'  where a.id_menu = :P131_ID',
'  order by a.data_inclusao desc;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P131_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(77853470610876922)
,p_region_id=>wwv_flow_imp.id(77853345421876921)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITULO_ARTEFATO'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(77853532495876923)
,p_card_id=>wwv_flow_imp.id(77853470610876922)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:132:&SESSION.::&DEBUG.:132:P132_ID,P132_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(77853693356876924)
,p_card_id=>wwv_flow_imp.id(77853470610876922)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'BTN_EDITAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:132:&SESSION.::&DEBUG.:132:P132_ID,P132_EDITAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(77853798774876925)
,p_card_id=>wwv_flow_imp.id(77853470610876922)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_EXCLUIR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:133:&SESSION.::&DEBUG.:133:P133_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link u-danger-text'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(70826629101306828)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(77853179770876919)
,p_button_name=>'REL_NOVO'
,p_button_static_id=>'REL_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--gapLeft:t-Button--padRight:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'ORDER_BY_ITEM'
,p_button_redirect_url=>'f?p=&APP_ID.:132:&SESSION.::&DEBUG.:132:P132_ID_MENU:&P131_ID.'
,p_button_css_classes=>'u-pullRight'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(79815902393511048)
,p_branch_name=>'Go to 132'
,p_branch_action=>'f?p=&APP_ID.:132:&SESSION.::&DEBUG.:132:P132_ID_MENU:&P131_ID.'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'NOT_EXISTS'
,p_branch_condition=>'select 1 from srv_menu_acao where id_menu = :P131_ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77853202418876920)
,p_name=>'P131_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(77853179770876919)
,p_prompt=>'Search'
,p_placeholder=>'Busca por srv_artefato.titulo_l'
,p_source=>'TITULO_ARTEFATO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77853844375876926)
,p_name=>'P131_NOME_MENU'
,p_item_sequence=>1
,p_item_plug_id=>wwv_flow_imp.id(77853179770876919)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_prompt=>'srv_menu.titulo_l'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(252063409266028362)
,p_name=>'P131_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(77853950962876927)
,p_computation_sequence=>20
,p_computation_item=>'P131_NOME_MENU'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select ''(''||case when id_menu_pai is null then ''Raiz'' else (select titulo from srv_menu where id = a.id_menu_pai) end||'') ''|| titulo from srv_menu a where id = :P131_ID'
,p_compute_when=>'P131_ID'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(70845826989306877)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>100
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(70846346429306878)
,p_event_id=>wwv_flow_imp.id(70845826989306877)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(70843564596306871)
,p_name=>'onDialogClosedBTN_NOVO'
,p_event_sequence=>350
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(70826629101306828)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(70844559447306873)
,p_event_id=>wwv_flow_imp.id(70843564596306871)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77853345421876921)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79815464196511043)
,p_name=>'onDialogClosedLISTA'
,p_event_sequence=>360
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(77853345421876921)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79815501936511044)
,p_event_id=>wwv_flow_imp.id(79815464196511043)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77853345421876921)
);
wwv_flow_imp.component_end;
end;
/
