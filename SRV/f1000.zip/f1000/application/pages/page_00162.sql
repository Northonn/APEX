prompt --application/pages/page_00162
begin
--   Manifest
--     PAGE: 00162
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>162
,p_name=>unistr('Mensagens - Inclus\00E3o de tradu\00E7\00E3o')
,p_alias=>unistr('MENSAGENS-INCLUSAO-DE-TRADU\00C7\00C3O')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Incluir uma nova Tradu\00E7\00E3o')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("body").on("click", "#" + ''LIST_ABA'' + " " + ''.t-MediaList-itemWrap'', function (e) {',
'    e.preventDefault();',
'            var selectedID = $(this).data("id");',
'            AtribuirValorItem(''P51_ABA'',selectedID);',
'})'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region-bodyWrap{',
'    background-color: white;',
'    //border-radius: 10px !IMPORTANT;',
'}',
'',
'.st-radius-100{',
'    border-radius: 100%!IMPORTANT;',
'}',
'',
'.t-Form-labelContainer--hiddenLabel{',
'    display: none;',
'}',
'',
'.apex-item-text {',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group--popup-lov{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-popup-lov{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;    ',
'}',
'',
'.a-Button {',
'         border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'.a-Button--popupLOV{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'',
'.ap-password-eye{',
'    box-shadow: none!IMPORTANT;',
'}',
'',
'.st-item-center{   ',
'    display: block !IMPORTANT;',
'    text-align: center !IMPORTANT;',
'}',
'',
'.a-bloco{',
'    padding: 10px;',
'}',
'',
'.apex-item-filedrop{',
'    border: none;',
'}',
'',
'.apex-item-filedrop-progress{',
'    border: none;',
'}',
'',
'.apex-item-filedrop{',
'    color: var(--ut-body-text-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240325195051'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129067389672012635355)
,p_plug_name=>unistr('Incluir uma nova tradu\00E7\00E3o da mensagem')
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading js-removeLandmark:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'SRV_APLICACAO_MENSAGEM_TRADUZIDA'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77889641479637563)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_SALVAR'
,p_button_position=>'NEXT'
,p_button_condition=>'P162_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76148722691440038)
,p_name=>'P162_ID_TENANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_item_source_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_source=>'ID_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76148828563440039)
,p_name=>'P162_RESULTADO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76148995022440040)
,p_name=>'P162_RESULTADO_MENSAGEM'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77861208957543306)
,p_name=>'P162_ID_APLICACAO_MENSAGEM'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_item_source_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_source=>'ID_APLICACAO_MENSAGEM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77861317209543307)
,p_name=>'P162_ID_IDIOMA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_item_source_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_prompt=>'SRV_APLICACAO_MENSAGEM_TRADUZIDA.ID_IDIOMA_L'
,p_placeholder=>'SRV_APLICACAO_MENSAGEM_TRADUZIDA.ID_IDIOMA_I'
,p_source=>'ID_IDIOMA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'R_SRV_IDIOMA.NOME'
,p_cSize=>30
,p_cattributes_element=>'style="text-align: start;"'
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>'SRV_APLICACAO_MENSAGEM_TRADUZIDA.ID_IDIOMA_H'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77861458990543308)
,p_name=>'P162_MENSAGEM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_item_source_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_prompt=>'SRV_APLICACAO_MENSAGEM_TRADUZIDA.MENSAGEM_L'
,p_placeholder=>'SRV_APLICACAO_MENSAGEM_TRADUZIDA.MENSAGEM_I'
,p_source=>'MENSAGEM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>512
,p_tag_attributes=>'style="text-align: start;"'
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'SRV_APLICACAO_MENSAGEM_TRADUZIDA.MENSAGEM_H'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77861546242543309)
,p_name=>'P162_AJUDA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_item_source_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_prompt=>'SRV_APLICACAO_MENSAGEM_TRADUZIDA.AJUDA_L'
,p_placeholder=>'SRV_APLICACAO_MENSAGEM_TRADUZIDA.AJUDA_I'
,p_source=>'AJUDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>512
,p_cattributes_element=>'style="text-align: start;"'
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'SRV_APLICACAO_MENSAGEM_TRADUZIDA.AJUDA_H'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77861653237543310)
,p_name=>'P162_DATA_INCLUSAO'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_item_source_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77861742985543311)
,p_name=>'P162_ID_USUARIO_INCLUIU'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_item_source_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77861886150543312)
,p_name=>'P162_DATA_ALTERACAO'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_item_source_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77861933414543313)
,p_name=>'P162_ID_USUARIO_ALTEROU'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_item_source_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306862244314146942)
,p_name=>'P162_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_item_source_plug_id=>wwv_flow_imp.id(129067389672012635355)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77899324596637590)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'INCLUI_REGISTRO'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_SRV_APLICACAO_MENSAGEM_TRADUZIDA'
,p_attribute_04=>'INCLUI_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE_FOTO,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'&P162_RESULTADO_MENSAGEM.'
,p_internal_uid=>77899324596637590
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76148105839440032)
,p_page_process_id=>wwv_flow_imp.id(77899324596637590)
,p_page_id=>162
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P162_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76148281974440033)
,p_page_process_id=>wwv_flow_imp.id(77899324596637590)
,p_page_id=>162
,p_name=>'p_id_aplicacao_mensagem'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P162_ID_APLICACAO_MENSAGEM'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76148381559440034)
,p_page_process_id=>wwv_flow_imp.id(77899324596637590)
,p_page_id=>162
,p_name=>'p_id'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P162_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76148416343440035)
,p_page_process_id=>wwv_flow_imp.id(77899324596637590)
,p_page_id=>162
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>80
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76148566936440036)
,p_page_process_id=>wwv_flow_imp.id(77899324596637590)
,p_page_id=>162
,p_name=>'p_resultado'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>90
,p_value_type=>'ITEM'
,p_value=>'P162_RESULTADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76148607944440037)
,p_page_process_id=>wwv_flow_imp.id(77899324596637590)
,p_page_id=>162
,p_name=>'p_resultado_mensagem'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P162_RESULTADO_MENSAGEM'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(78702263546034801)
,p_page_process_id=>wwv_flow_imp.id(77899324596637590)
,p_page_id=>162
,p_name=>'p_id_idioma'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P162_ID_IDIOMA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(78702321560034802)
,p_page_process_id=>wwv_flow_imp.id(77899324596637590)
,p_page_id=>162
,p_name=>'p_mensagem'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P162_MENSAGEM'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(78702492314034803)
,p_page_process_id=>wwv_flow_imp.id(77899324596637590)
,p_page_id=>162
,p_name=>'p_ajuda'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P162_AJUDA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77862737246543321)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>77862737246543321
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77898946136637590)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(129067389672012635355)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Incluir conte\00FAdo')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>77898946136637590
);
wwv_flow_imp.component_end;
end;
/
