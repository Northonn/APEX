prompt --application/pages/page_00280
begin
--   Manifest
--     PAGE: 00280
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>280
,p_name=>'Funcionalidades- Incluir um novo grupo - funcionalidade ao artefato'
,p_alias=>'FUNCIONALIDADES-INCLUIR-UM-NOVO-GRUPO-FUNCIONALIDADE-AO-ARTEFATO'
,p_page_mode=>'MODAL'
,p_step_title=>'Funcionalidades- Incluir um novo grupo - funcionalidade ao artefato'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("body").on("click", "#" + ''LIST_ABA'' + " " + ''.t-MediaList-itemWrap'', function (e) {',
'    e.preventDefault();',
'            var selectedID = $(this).data("id");',
'            AtribuirValorItem(''P51_ABA'',selectedID);',
'})'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region-bodyWrap{',
'    background-color: white;',
'    //border-radius: 10px !IMPORTANT;',
'}',
'',
'.st-radius-100{',
'    border-radius: 100%!IMPORTANT;',
'}',
'',
'.t-Form-labelContainer--hiddenLabel{',
'    display: none;',
'}',
'',
'.apex-item-text {',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group--popup-lov{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-popup-lov{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;    ',
'}',
'',
'.a-Button {',
'         border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'.a-Button--popupLOV{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'',
'.ap-password-eye{',
'    box-shadow: none!IMPORTANT;',
'}',
'',
'.st-item-center{   ',
'    display: block !IMPORTANT;',
'    text-align: center !IMPORTANT;',
'}',
'',
'.a-bloco{',
'    padding: 10px;',
'}',
'',
'.apex-item-filedrop{',
'    border: none;',
'}',
'',
'.apex-item-filedrop-progress{',
'    border: none;',
'}',
'',
'.apex-item-filedrop{',
'    color: var(--ut-body-text-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when=>'P280_VISUALIZAR'
,p_page_component_map=>'17'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240423124139'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129355206403355040275)
,p_plug_name=>'Incluir um novo grupo - funcionalidade'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading js-removeLandmark:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>33
,p_query_type=>'TABLE'
,p_query_table=>'SRV_GRUPO_FUNCIONALIDADE_ARTEFATO'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79861871685448076)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_GRAVAR'
,p_button_position=>'CREATE'
,p_button_condition=>':P280_EDITAR IS NULL AND :P280_VISUALIZAR IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79861479392448074)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_GRAVAR'
,p_button_position=>'CREATE'
,p_button_condition=>':P280_ID IS NOT NULL AND :P280_VISUALIZAR IS NULL AND :P280_DUPLICAR IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79812151519511010)
,p_name=>'P280_ID_GRUPO_FUNCIONALIDADE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_item_source_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_prompt=>'srv_grupo_funcionalidade_artefato.id_grupo_funcionalidade_l'
,p_placeholder=>'srv_grupo_funcionalidade_artefato.id_grupo_funcionalidade_i'
,p_source=>'ID_GRUPO_FUNCIONALIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'R_SRV_GRUPO_FUNCIONALIDADE.TITULO'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>'srv_grupo_funcionalidade_artefato.id_grupo_funcionalidade_h'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79812201719511011)
,p_name=>'P280_ID_ARTEFATO_VERSIONADO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_item_source_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_prompt=>'srv_grupo_funcionalidade_artefato.id_artefato_versionado_l'
,p_placeholder=>'srv_grupo_funcionalidade_artefato.id_artefato_versionado_i'
,p_source=>'ID_ARTEFATO_VERSIONADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'R_SRV_ARTEFATO_VERSIONADO.ID_ARTEFATO_VERSIONADO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.titulo_artefato||'' (''||b.codigo_artefato||'')'' as display_value,',
'       d.versao, ',
'       b.descricao_artefato,',
'       a.id as return_value',
'from srv_artefato_versionado a',
'left join srv_artefato b on  b.id = a.id_artefato',
'left join srv_aplicacao_versionada c on c.id = a.id_aplicacao_versionada',
'left join srv_sistema_versionado d on d.id = c.id_sistema_versionado'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>'srv_grupo_funcionalidade_artefato.id_artefato_versionado_h'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(315256595801672082)
,p_name=>'P280_VISUALIZAR'
,p_item_sequence=>1
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(315256693049672083)
,p_name=>'P280_DUPLICAR'
,p_item_sequence=>2
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(315257986873672096)
,p_name=>'P280_EDITAR'
,p_item_sequence=>3
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365680714715906940)
,p_name=>'P280_ID_TENANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_item_source_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_source=>'ID_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'SRV_SISTEMA.ID_TENANT_H'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365681014194906943)
,p_name=>'P280_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_item_source_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365681187414906944)
,p_name=>'P280_DATA_INCLUSAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_item_source_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365681278659906945)
,p_name=>'P280_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_item_source_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365681356487906946)
,p_name=>'P280_DATA_ALTERACAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_item_source_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(391810570087271489)
,p_name=>'P280_RESULTADO'
,p_item_sequence=>4
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(391810742099271490)
,p_name=>'P280_RESULTADO_MENSAGEM'
,p_item_sequence=>5
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(594684146112551875)
,p_name=>'P280_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_item_source_plug_id=>wwv_flow_imp.id(129355206403355040275)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(79870660417448102)
,p_computation_sequence=>10
,p_computation_item=>'P280_ID_TENANT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_id_usuario number := pkg_util.retorna_id_usuario_logado;',
'    v_id_tenant number;',
'begin',
'    select id_tenant into v_id_tenant from mpd_usuario where id = v_id_usuario;',
'    return v_id_tenant;',
'end;    '))
,p_compute_when=>'P280_EDITAR'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79870964524448103)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'INCLUI_REGISTRO'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_SRV_GRUPO_FUNCIONALIDADE_ARTEFATO'
,p_attribute_04=>'INCLUI_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(79861871685448076)
,p_process_success_message=>'&P280_RESULTADO_MENSAGEM.'
,p_internal_uid=>79870964524448103
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79812394043511012)
,p_page_process_id=>wwv_flow_imp.id(79870964524448103)
,p_page_id=>280
,p_name=>'p_id_grupo_funcionalidade'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P280_ID_GRUPO_FUNCIONALIDADE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79812472216511013)
,p_page_process_id=>wwv_flow_imp.id(79870964524448103)
,p_page_id=>280
,p_name=>'p_id_artefato_versionado'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P280_ID_ARTEFATO_VERSIONADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79872493786448113)
,p_page_process_id=>wwv_flow_imp.id(79870964524448103)
,p_page_id=>280
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P280_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79872939551448114)
,p_page_process_id=>wwv_flow_imp.id(79870964524448103)
,p_page_id=>280
,p_name=>'p_id'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P280_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79873475079448115)
,p_page_process_id=>wwv_flow_imp.id(79870964524448103)
,p_page_id=>280
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79873973903448116)
,p_page_process_id=>wwv_flow_imp.id(79870964524448103)
,p_page_id=>280
,p_name=>'p_resultado'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P280_RESULTADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79874465081448117)
,p_page_process_id=>wwv_flow_imp.id(79870964524448103)
,p_page_id=>280
,p_name=>'p_resultado_mensagem'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P280_RESULTADO_MENSAGEM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79874834600448118)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'ALTERA_REGISTRO'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_SRV_GRUPO_FUNCIONALIDADE_ARTEFATO'
,p_attribute_04=>'ALTERA_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(79861479392448074)
,p_process_success_message=>'&P280_RESULTADO_MENSAGEM.'
,p_internal_uid=>79874834600448118
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79812550107511014)
,p_page_process_id=>wwv_flow_imp.id(79874834600448118)
,p_page_id=>280
,p_name=>'p_id_grupo_funcionalidade'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>110
,p_value_type=>'ITEM'
,p_value=>'P280_ID_GRUPO_FUNCIONALIDADE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79812652709511015)
,p_page_process_id=>wwv_flow_imp.id(79874834600448118)
,p_page_id=>280
,p_name=>'p_id_artefato_versionado'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>120
,p_value_type=>'ITEM'
,p_value=>'P280_ID_ARTEFATO_VERSIONADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79876305278448121)
,p_page_process_id=>wwv_flow_imp.id(79874834600448118)
,p_page_id=>280
,p_name=>'p_data_alteracao'
,p_direction=>'IN'
,p_data_type=>'TIMESTAMP'
,p_has_default=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P280_DATA_ALTERACAO'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79876876346448122)
,p_page_process_id=>wwv_flow_imp.id(79874834600448118)
,p_page_id=>280
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P280_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79877307113448123)
,p_page_process_id=>wwv_flow_imp.id(79874834600448118)
,p_page_id=>280
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P280_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79877849047448124)
,p_page_process_id=>wwv_flow_imp.id(79874834600448118)
,p_page_id=>280
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79878311246448125)
,p_page_process_id=>wwv_flow_imp.id(79874834600448118)
,p_page_id=>280
,p_name=>'p_resultado'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P280_RESULTADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(79878819051448126)
,p_page_process_id=>wwv_flow_imp.id(79874834600448118)
,p_page_id=>280
,p_name=>'p_resultado_mensagem'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P280_RESULTADO_MENSAGEM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79879203245448127)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_01=>'P280_RESULTADO_MENSAGEM'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>79879203245448127
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79868522756448095)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(129355206403355040275)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Incluir conte\00FAdo')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>79868522756448095
);
wwv_flow_imp.component_end;
end;
/
