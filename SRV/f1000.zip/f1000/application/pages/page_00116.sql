prompt --application/pages/page_00116
begin
--   Manifest
--     PAGE: 00116
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>116
,p_name=>unistr('Menu - Op\00E7\00F5es')
,p_alias=>unistr('MENU-OP\00C7\00D5ES')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Op\00E7\00F5es')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240325195815'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(81993549067307097)
,p_plug_name=>unistr('A\00E7\00F5es')
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(124050113266319589)
,p_plug_name=>unistr('Op\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(81993549067307097)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(70857691823337093)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(74610762990968672)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(70204071365924982)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(81993549067307097)
,p_button_name=>'BTN_EDITAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EDITAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:115:P115_ID,P115_RETORNO:&P116_ID.,1'
,p_button_css_classes=>'border-radius-100 button-lg'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(70203623095924981)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(81993549067307097)
,p_button_name=>'BTN_DUPLICAR'
,p_button_static_id=>'BTN_DELETE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_DUPLICAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:115:P115_ID,P115_DUPLICAR:&P116_ID.,1'
,p_button_css_classes=>'border-radius-100 button-lg'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(70203298325924980)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(81993549067307097)
,p_button_name=>'BTN_EXCLUIR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EXCLUIR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.:128:P128_ID:&P116_ID.'
,p_button_css_classes=>'border-radius-100 button-lg'
,p_icon_css_classes=>'fa-trash '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81995504136307105)
,p_name=>'P116_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(81993549067307097)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77218070831050843)
,p_name=>unistr('onDialogClosedOp\00E7\00F5es')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(81993549067307097)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77218152034050844)
,p_event_id=>wwv_flow_imp.id(77218070831050843)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'document.location.reload(true);'
);
wwv_flow_imp.component_end;
end;
/
