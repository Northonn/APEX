prompt --application/pages/page_09996
begin
--   Manifest
--     PAGE: 09996
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9996
,p_name=>'Verifica Token'
,p_alias=>'VERIFICA-TOKEN'
,p_step_title=>'Verifica Token'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(187698945380989659)
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.addEventListener("paste", function(e) {',
'  // if the target is a text input',
'  ',
'  if (e.target.type === "text") {',
'   var data = e.clipboardData.getData(''Text'');',
'   // split clipboard text into single characters',
'   apex.item( "P9996_TOKEN" ).setValue( data );',
'   data = data.split('''');',
'   ',
'   // find all other text inputs',
'   [].forEach.call(document.querySelectorAll("input[type=text]"), (node, index) => {',
'      // And set input value to the relative character',
'      if (node.id != ''P9996_TOKEN'')',
'        node.value = data[index];',
'      ',
'      ',
'    });',
'  }',
'});',
'',
'function moveToNext(event, nextInputId) {',
'  //alert(''moveToNext'');  ',
'  var token = $("#digito1").val() + $("#digito2").val() + $("#digito3").val() + $("#digito4").val();',
' ',
'  apex.item( "P9996_TOKEN" ).setValue( token );  ',
unistr('  // Verifica se a tecla pressionada \00E9 num\00E9rica (0-9)'),
'  if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {',
unistr('    // Move o foco para o pr\00F3ximo campo de entrada'),
'    document.getElementById(nextInputId).focus();',
'    document.getElementById(nextInputId).select();',
'    ',
'  }',
'}',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.st-font-size-40{',
'    font-size: 30px;',
'    padding: 10px;',
'}',
'',
'#form {',
'    margin: 20px auto 20px;',
'}',
'',
'input {',
'    margin: 0 5px;',
'    text-align: center;',
'    line-height: 80px;',
'    font-size: 50px;',
'    border: solid 1px #ccc;',
'    box-shadow: 0 0 5px #ccc inset;',
'    outline: none;',
'    transition: all .2s ease-in-out;',
'    border-radius: 3px;',
'    width: 20%;',
'}    ',
'',
'input:focus {',
'    border-color: rgb(63, 146, 255);',
'    box-shadow: 0 0 5px rgb(63, 146, 255) inset;',
'}',
'',
'input::selection {',
'    background: transparent;',
'}',
'     ',
'      ',
'     '))
,p_step_template=>wwv_flow_imp.id(306322751452923739)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'SRV-LAB'
,p_last_upd_yyyymmddhh24miss=>'20230722211245'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(464537987203468825)
,p_plug_name=>'MBP'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306411171886923787)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(417431895473369448)
,p_plug_name=>unistr('Informe o c\00F3digo de verifica\00E7\00E3o')
,p_parent_plug_id=>wwv_flow_imp.id(464537987203468825)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>40
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="st-vertical-center" id="form">',
'    <input  id="digito1" type="text" onkeyup="moveToNext(event, ''digito2'')" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />',
'    <input  id="digito2" type="text" onkeyup="moveToNext(event, ''digito3'')" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />',
'    <input  id="digito3" type="text" onkeyup="moveToNext(event, ''digito4'')" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />',
'    <input  id="digito4" type="text" onkeyup="moveToNext(event, ''digito1'')" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" style="margin-right: 0px;" />',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(417555057563666546)
,p_plug_name=>'Bloco aviso aplicativo'
,p_parent_plug_id=>wwv_flow_imp.id(464537987203468825)
,p_region_css_classes=>'st-back-transp'
,p_icon_css_classes=>'fa-mobile'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>20
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9996_MODELO_MFA'
,p_plug_display_when_cond2=>'1'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<div style="text-align: center; font-size: 12px;">Se voc\00EA ainda n\00E3o instalou o nosso aplicativo <strong>STAFF Autenticador</strong>, clique na imagem a seguir.</div>'),
'<a href="https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com/ords/r/staff/staff-autenticador/lista-de-usu%C3%A1rios" target="_blank">',
'    <div style="text-align: center;">',
'        <img style="height: 40px; margin-top: 10px;" src="#APP_FILES#logo-google-play.png" alt="Instalar STAFF Autenticador">',
'    </div>',
'</a>',
'<div style="text-align: center; margin-top: 10px; font-size: 12px;">',
unistr('    <span>Caso tenha alguma d\00FAvida sobre como acessar o aplicativo STAFF Autenticador,</span>'),
'    <a href="https://scribehow.com/shared/Acessando_o_STAFF_autenticador__00GgZSD7QqiVL4xE-oxUrw" target="_blank">',
'        <span style="text-align: center;">acesse o guia aqui.</span>',
'    </a>',
'</div>',
'<br>',
unistr('<div class="st-titulo-login">Informe o c\00F3digo de verifica\00E7\00E3o</div>'),
'<div class="st-detalhe-login">gerado pelo aplicativo STAFF Autenticador</div>',
'',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(417555329110666549)
,p_plug_name=>'Bloco aviso email'
,p_parent_plug_id=>wwv_flow_imp.id(464537987203468825)
,p_region_css_classes=>'st-back-transp'
,p_icon_css_classes=>'fa-envelope-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>30
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9996_MODELO_MFA'
,p_plug_display_when_cond2=>'2'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<div class="st-titulo-login">Informe o c\00F3digo de verifica\00E7\00E3o</div>'),
unistr('<div class="st-detalhe-login">envido para o e-mail do usu\00E1rio</div>')))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(420318802969314792)
,p_plug_name=>'Logo'
,p_parent_plug_id=>wwv_flow_imp.id(464537987203468825)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="#APP_FILES#logo.png" style="height: 30px;" alt="Minha Figura"></img>',
'<div class="st-titulo-app">&APP_NAME.</div>',
'<div style="font-size: 18px;">&P9997_USERNAME.</div>',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(236704865430472944)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(464537987203468825)
,p_button_name=>'LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Acessar'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236705284968472945)
,p_name=>'P9996_USERNAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(464537987203468825)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236705745066472945)
,p_name=>'P9996_MODELO_MFA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(464537987203468825)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('1 - Aplicativo de autentica\00E7\00E3o'),
'2 - E-mail',
'3 - SMS'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236706682204472946)
,p_name=>'P9996_TOKEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(417431895473369448)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(236707819558472947)
,p_validation_name=>'P9996_TOKEN-Valid Token'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_message varchar(255);',
'begin',
'    l_message := PKG_API_SEGURANCA.valid_mfa(:P9996_USERNAME,:P9996_TOKEN, :P9996_MODELO_MFA);',
'    return l_message;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(236704865430472944)
,p_associated_item=>wwv_flow_imp.id(236706682204472946)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(236708181190472947)
,p_validation_name=>'P9996_TOKEN-Valid Not Null'
,p_validation_sequence=>20
,p_validation=>'P9996_TOKEN'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('C\00F3digo de verifica\00E7\00E3o deve ser informado')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(236704865430472944)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(236708507583472947)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'PROCESS_LOGIN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(236704865430472944)
,p_internal_uid=>62039162045117829
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(236709002142472947)
,p_page_process_id=>wwv_flow_imp.id(236708507583472947)
,p_page_id=>9996
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9996_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(236709489208472948)
,p_page_process_id=>wwv_flow_imp.id(236708507583472947)
,p_page_id=>9996
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9996_TOKEN'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(236709955847472948)
,p_page_process_id=>wwv_flow_imp.id(236708507583472947)
,p_page_id=>9996
,p_name=>'p_auth_type'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9996_MODELO_MFA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(236710478155472949)
,p_page_process_id=>wwv_flow_imp.id(236708507583472947)
,p_page_id=>9996
,p_name=>'p_app_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_ID'
);
wwv_flow_imp.component_end;
end;
/
