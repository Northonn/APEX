prompt --application/pages/page_09001
begin
--   Manifest
--     PAGE: 09001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9001
,p_name=>unistr('Confirmar a\00E7\00E3o gen\00E9rica')
,p_alias=>unistr('CONFIRMAR-A\00C7\00C3O-GEN\00C9RICA')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Confirmar a\00E7\00E3o')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240320183325'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78687494516497925)
,p_plug_name=>'botao'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>110
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(416587583215868760)
,p_name=>unistr('Confirma\00E7\00E3o')
,p_region_name=>'button_bar'
,p_template=>wwv_flow_imp.id(306369115795923766)
,p_display_sequence=>100
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Cards--displaySubtitle:t-Cards--featured force-fa-lg:t-Cards--spanHorizontally:t-Cards--animColorFill:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_metodo_detalhe  varchar2(256) := nvl(:P9001_METODO_DETALHE, ''BO_SRV_MENU.detalhe_registro'');',
unistr('    v_acao            varchar2(256) := nvl(:P9001_ACAO, ''A\00E7\00E3o'');'),
'    v_id              number := nvl(:P9001_ID,0);',
'    v_sql             clob;',
'begin',
'',
unistr('    v_sql := v_sql || ''select ''''Nome da a\00E7\00E3o'''' as CARD_TITLE, '';'),
'    v_sql := v_sql || ''       ''''''||v_acao||'''''' as CARD_SUBTITLE, '';',
'    -- v_sql := v_sql || ''       ''''fa-question'''' as CARD_ICON, '';',
'    v_sql := v_sql || ''       ''''u-question'''' as CARD_COLOR, '';',
'    v_sql := v_sql || ''       '''''''' as CARD_MODIFIERS, '';',
'    v_sql := v_sql || ''       '''''''' as CARD_LINK, '';',
'    v_sql := v_sql || ''       ''||v_metodo_detalhe||''(p_id => ''||v_id||'') as CARD_TEXT, '';',
'    v_sql := v_sql || ''       '''''''' as CARD_SUBTEXT '';',
'    v_sql := v_sql || ''  from dual'';',
'        apex_debug.error(''v_metodo_detalhe :'' ||v_sql);',
'',
'    return v_sql;',
'',
'end;'))
,p_header=>unistr('<h4 style="text-align: center;">Voc\00EA deseja realmente executar esta a\00E7\00E3o?</h4>')
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P9001_ID,P9001_METODO_DETALHE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(306424861607923799)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(78894524356391328)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>80
,p_column_heading=>'Card Title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(78894987771391329)
,p_query_column_id=>2
,p_column_alias=>'CARD_SUBTITLE'
,p_column_display_sequence=>90
,p_column_heading=>'Card Subtitle'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(78895706591391334)
,p_query_column_id=>3
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>110
,p_column_heading=>'Card Color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(78896192125391334)
,p_query_column_id=>4
,p_column_alias=>'CARD_MODIFIERS'
,p_column_display_sequence=>120
,p_column_heading=>'Card Modifiers'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(78896586942391336)
,p_query_column_id=>5
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>130
,p_column_heading=>'Card Link'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(78896927635391337)
,p_query_column_id=>6
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>70
,p_column_heading=>'Card Text'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(78897319484391338)
,p_query_column_id=>7
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>140
,p_column_heading=>'Card Subtext'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(78687393895497924)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(78687494516497925)
,p_button_name=>'BTN_CONFIRMAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_CONFIRMAR'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78686927962497920)
,p_name=>'P9001_METODO_EXECUCAO'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78687034409497921)
,p_name=>'P9001_METODO_DETALHE'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78687584252497926)
,p_name=>'P9001_ACAO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(242615554664566546)
,p_name=>'P9001_RESULTADO'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(242616598575566556)
,p_name=>'P9001_RESULTADO_MENSAGEM'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(416630806665868990)
,p_name=>'P9001_ID'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(78687125039497922)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'executar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_sql clob;',
'begin',
'    execute immediate ''begin ''|| :P9001_METODO_EXECUCAO ||''(p_id => :P9001_ID, p_resultado => :P9001_RESULTADO, p_resultado_mensagem => :P9001_RESULTADO_MENSAGEM); end;'' using :P9001_ID, out :P9001_RESULTADO, out :P9001_RESULTADO_MENSAGEM;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'&P9001_RESULTADO_MENSAGEM.'
,p_internal_uid=>78687125039497922
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(78687250466497923)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'closed'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>78687250466497923
);
wwv_flow_imp.component_end;
end;
/
