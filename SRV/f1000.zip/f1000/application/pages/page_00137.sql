prompt --application/pages/page_00137
begin
--   Manifest
--     PAGE: 00137
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>137
,p_name=>'Entidade - Auditoria'
,p_alias=>'ENTIDADE-AUDITORIA'
,p_step_title=>'Entidade - Auditoria'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-actions{',
'    display: none;',
'}',
'',
'.a-CardView-header{',
'    background-color: aliceblue;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'}',
'',
'.t-ButtonRegion-buttons',
'{',
' display: flex;',
' justify-content: flex-end;',
' align-items: center;',
'}',
'',
'.t-Region',
'{',
'    border: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(306307910376923732)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'24'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240301002551'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(139932742131418885)
,p_plug_name=>unistr('Lista de entidades criadas no banco de dados que n\00E3o est\00E3o no cadastro de entidades')
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(139932454584418882)
,p_plug_name=>'Pesquisa'
,p_parent_plug_id=>wwv_flow_imp.id(139932742131418885)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>30
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(151728329559830294)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(151728329559830294)
,p_plug_name=>'Lista'
,p_parent_plug_id=>wwv_flow_imp.id(139932742131418885)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleC'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lower(TABLE_NAME) as COLUMN_HEADER, ',
'    lower(bo_srv_entidade.retorna_colunas_banco(TABLE_NAME)) as lista_colunas',
'from all_tables where OWNER = (Select OWNER from APEX_applications where application_id = 1000 )',
'and lower(TABLE_NAME) not in (Select lower(nome_entidade) from srv_entidade) '))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(74415532378945801)
,p_region_id=>wwv_flow_imp.id(151728329559830294)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'COLUMN_HEADER'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="padding-top-sm">',
'    &LISTA_COLUNAS!RAW.',
'</div>',
''))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(151727644656830284)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(139935444402418931)
,p_name=>'P137_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(139932454584418882)
,p_prompt=>'Nome da entidade'
,p_placeholder=>'Buscar por nome'
,p_source=>'COLUMN_HEADER'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(74402610907826238)
,p_name=>'onCloseArtefatoGrid'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(151728329559830294)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74403132956826240)
,p_event_id=>wwv_flow_imp.id(74402610907826238)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(151728329559830294)
);
wwv_flow_imp.component_end;
end;
/
