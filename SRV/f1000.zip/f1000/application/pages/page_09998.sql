prompt --application/pages/page_09998
begin
--   Manifest
--     PAGE: 09998
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9998
,p_name=>unistr('Cadastro de usu\00E1rio')
,p_alias=>unistr('CADASTRO-DE-USU\00C1RIO')
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(187698945380989659)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Login-logo{',
'    border-radius: 100px;',
'}'))
,p_step_template=>wwv_flow_imp.id(306322751452923739)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'SRV-LAB'
,p_last_upd_yyyymmddhh24miss=>'20230811200350'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(332276652235485266)
,p_plug_name=>unistr('Cadastre seu usu\00E1rio')
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(306411171886923787)
,p_plug_display_sequence=>20
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="#APP_FILES#logo.png" style="height: 30px;" alt="Minha Figura"></img>',
'<div class="st-titulo-app">&APP_NAME.</div>',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(288454615185490232)
,p_plug_name=>unistr('Cadastre seu usu\00E1rio')
,p_parent_plug_id=>wwv_flow_imp.id(332276652235485266)
,p_region_css_classes=>'st-back-transp'
,p_icon_css_classes=>'fa-user-plus'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>10
,p_plug_header=>unistr('<div class="st-titulo-login">Cadastre seu usu\00E1rio</div>')
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184224445181889364)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(288454615185490232)
,p_button_name=>'CADASTRAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cadastrar'
,p_button_position=>'PREVIOUS'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(184236748951889377)
,p_branch_name=>'Go to Login'
,p_branch_action=>'f?p=&APP_ID.:9992:&SESSION.::&DEBUG.:9992::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(184237116511889377)
,p_branch_name=>'Redirect Login'
,p_branch_action=>'f?p=&APP_ID.:9993:&SESSION.::&DEBUG.:9993::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'NOT_EXISTS'
,p_branch_condition=>'Select * from TEMP_ENVIA_CONVITE where TOKEN_CONVITE = :P9998_TOKEN_CONVITE and nvl(situacao,0) = 1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283734896336894582)
,p_name=>'P9998_NOME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(288454615185490232)
,p_prompt=>'Nome completo'
,p_placeholder=>'Informe seu nome completo '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(306464296217923826)
,p_item_template_options=>'#DEFAULT#:margin-top-md'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283734982263894583)
,p_name=>'P9998_EMAIL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(288454615185490232)
,p_prompt=>'E-mail'
,p_placeholder=>'Informe seu e-mail'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(306464296217923826)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'EMAIL'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(285262373072368966)
,p_name=>'P9998_USERNAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(288454615185490232)
,p_prompt=>unistr('Nome de usu\00E1rio')
,p_placeholder=>unistr('Informe seu nome de usu\00E1rio para acesso ao sistema')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(306464296217923826)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(285262837806368969)
,p_name=>'P9998_PASSWORD'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(288454615185490232)
,p_prompt=>'Senha'
,p_placeholder=>'Informe sua senha'
,p_display_as=>'PLUGIN_COM.FOS.ADVANCED_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(306464296217923826)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'enabled-click-press'
,p_attribute_02=>'collapsible'
,p_attribute_03=>'Excelente'
,p_attribute_04=>'require-min-length:require-number:require-spec-char:require-capital-letter:show-pwd-strength-bar:show-caps-lock-on:enable-inline-icons'
,p_attribute_05=>'7'
,p_attribute_06=>'Deve conter pelo menos #MIN_LENGTH# caracteres.'
,p_attribute_07=>'1'
,p_attribute_08=>unistr('Pelo menos #MIN_NUMS# n\00FAmeros.')
,p_attribute_09=>unistr('?><,./|}[]~\00A7@#$%')
,p_attribute_10=>'2'
,p_attribute_11=>'Pelo menos #MIN_SPEC_CHARS# da lista: #SPEC_CHARS_LIST#'
,p_attribute_12=>'1'
,p_attribute_13=>unistr('Deve conter pelo menos #MIN_CAPS# letras mai\00FAsculas')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(285302305833402634)
,p_name=>'P9998_TELEFONE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(288454615185490232)
,p_prompt=>'Telefone'
,p_placeholder=>unistr('Informe seu n\00FAmero de telefone')
,p_display_as=>'PLUGIN_APEX MASK PLUGIN'
,p_cSize=>30
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(306464296217923826)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'(99) 99999-9999'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(285302430681402635)
,p_name=>'P9998_C_PASSWORD'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(288454615185490232)
,p_prompt=>'Confirmar senha'
,p_placeholder=>'Confirme sua senha'
,p_display_as=>'PLUGIN_COM.FOS.ADVANCED_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(306464296217923826)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'enabled-toggle'
,p_attribute_04=>'is-confirmation-item'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(285303404809402658)
,p_name=>'P9998_TIPO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(332276652235485266)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287162619042340140)
,p_name=>'P9998_TOKEN_VERIFICAO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(332276652235485266)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287163601304340149)
,p_name=>'P9998_TOKEN_CONVITE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(332276652235485266)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(184226909540889368)
,p_validation_name=>'P9998_USERNAME-Valid Username existe'
,p_validation_sequence=>10
,p_validation=>'return PKG_USUARIO.valid_username(:P9998_USERNAME);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_associated_item=>wwv_flow_imp.id(285262373072368966)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(184228568091889369)
,p_validation_name=>'P9998_USERNAME-Valid'
,p_validation_sequence=>20
,p_validation=>'P9998_USERNAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Nome de usu\00E1rio deve ser informado')
,p_associated_item=>wwv_flow_imp.id(285262373072368966)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(184227345753889368)
,p_validation_name=>'P9998_NOME-Valid'
,p_validation_sequence=>30
,p_validation=>'P9998_NOME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Nome completo deve ser informado'
,p_associated_item=>wwv_flow_imp.id(283734896336894582)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(184227755673889368)
,p_validation_name=>'P9998_EMAIL-Valid'
,p_validation_sequence=>40
,p_validation=>'P9998_EMAIL'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'E-mail deve ser informado'
,p_associated_item=>wwv_flow_imp.id(283734982263894583)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(184228094745889369)
,p_validation_name=>'P9998_TELEFONE-Valid'
,p_validation_sequence=>50
,p_validation=>'P9998_TELEFONE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Telefone deve ser informado'
,p_associated_item=>wwv_flow_imp.id(285302305833402634)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(184230140017889370)
,p_validation_name=>'P9998_TELEFONE-Valid_1'
,p_validation_sequence=>60
,p_validation=>'P9998_TELEFONE'
,p_validation2=>'^\([1-9]{2}\) [9]{0,1}[6-9]{1}[0-9]{3}\-[0-9]{4}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>unistr('Telefone inv\00E1lido')
,p_associated_item=>wwv_flow_imp.id(285302305833402634)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(184228968411889369)
,p_validation_name=>'P9998_PASSWORD-Valid'
,p_validation_sequence=>70
,p_validation=>'P9998_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Senha deve ser informada'
,p_associated_item=>wwv_flow_imp.id(285262837806368969)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(184229324509889369)
,p_validation_name=>'P9998_C_PASSWORD-Valid'
,p_validation_sequence=>80
,p_validation=>':P9998_C_PASSWORD = :P9998_PASSWORD'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('As senhas n\00E3o conferem')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(285302430681402635)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(184229740110889370)
,p_validation_name=>'P9998_C_PASSWORD-Valid_1'
,p_validation_sequence=>90
,p_validation=>'P9998_C_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('As senhas n\00E3o conferem')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(285302430681402635)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(184230472370889370)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Create user'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_USUARIO'
,p_attribute_04=>'CREATE_USER'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>33113478306778382
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(184230952506889372)
,p_page_process_id=>wwv_flow_imp.id(184230472370889370)
,p_page_id=>9998
,p_name=>'p_nome'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9998_NOME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(184231453487889372)
,p_page_process_id=>wwv_flow_imp.id(184230472370889370)
,p_page_id=>9998
,p_name=>'p_email'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9998_EMAIL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(184231955161889373)
,p_page_process_id=>wwv_flow_imp.id(184230472370889370)
,p_page_id=>9998
,p_name=>'p_telefone'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9998_TELEFONE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(184232427366889373)
,p_page_process_id=>wwv_flow_imp.id(184230472370889370)
,p_page_id=>9998
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P9998_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(184232952519889373)
,p_page_process_id=>wwv_flow_imp.id(184230472370889370)
,p_page_id=>9998
,p_name=>'p_senha'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9998_PASSWORD'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(184233434111889374)
,p_page_process_id=>wwv_flow_imp.id(184230472370889370)
,p_page_id=>9998
,p_name=>'p_tipo'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P9998_TIPO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(184233982262889374)
,p_page_process_id=>wwv_flow_imp.id(184230472370889370)
,p_page_id=>9998
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P9998_TOKEN_VERIFICAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(184234445305889374)
,p_page_process_id=>wwv_flow_imp.id(184230472370889370)
,p_page_id=>9998
,p_name=>'p_token_convite'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P9998_TOKEN_CONVITE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(184235218280889376)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Atualiza convite'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_USUARIO'
,p_attribute_04=>'ATUALIZA_SITUACAO_INVITE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>33118224216778388
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(184235778594889376)
,p_page_process_id=>wwv_flow_imp.id(184235218280889376)
,p_page_id=>9998
,p_name=>'p_token_convite'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9998_TOKEN_CONVITE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(184236197059889376)
,p_page_process_id=>wwv_flow_imp.id(184235218280889376)
,p_page_id=>9998
,p_name=>'p_situacao'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'STATIC'
,p_value=>'2'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(184234851124889375)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Envia e-mail confirma\00E7\00E3o')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url varchar2(6000);',
'    l_email varchar(255);',
'begin',
'    l_url := ''https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com''||',
'              APEX_UTIL.PREPARE_URL(',
'                p_url => ''f?p='' || :APP_ALIAS || '':9994:::NO::P9994_USERNAME,P9994_TOKEN_VERIFICAO:'' || :P9998_USERNAME||'',''||:P9998_TOKEN_VERIFICAO);',
'    PKG_USUARIO.email_confirma_cadastro(:P9998_USERNAME, :P9998_EMAIL, l_url);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('Seu usu\00E1rio foi criado com sucesso!')
,p_internal_uid=>33117857060778387
);
wwv_flow_imp.component_end;
end;
/
