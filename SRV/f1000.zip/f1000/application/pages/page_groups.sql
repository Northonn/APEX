prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 1000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(306495092575923869)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(177940915213953136)
,p_group_name=>'Agendamentos'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(177624173585264357)
,p_group_name=>'Artefatos'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(191599221849848069)
,p_group_name=>'Cadastro auxiliar'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(174693719710428397)
,p_group_name=>'Chamados'
,p_group_desc=>unistr('Grupo de p\00E1ginas do projeto de chamados.')
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(188462046107410429)
,p_group_name=>'Controle de acesso'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(176616308538866345)
,p_group_name=>'Convites'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(192992578335205669)
,p_group_name=>'Importar dados'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(187698945380989659)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(193816068302258639)
,p_group_name=>'Tabela'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(187699013442990645)
,p_group_name=>'Template'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(176854419803520021)
,p_group_name=>'Tutorial'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(177844404947575662)
,p_group_name=>'Usuarios'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(177961266757568588)
,p_group_name=>'Webservices'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(176230481133950898)
,p_group_name=>'Workspace'
);
wwv_flow_imp.component_end;
end;
/
