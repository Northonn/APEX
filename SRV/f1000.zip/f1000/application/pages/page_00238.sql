prompt --application/pages/page_00238
begin
--   Manifest
--     PAGE: 00238
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>238
,p_name=>'Traducao - Excluir'
,p_alias=>'TRADUCAO-EXCLUIR'
,p_page_mode=>'MODAL'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240227224854'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(444543806886090266)
,p_plug_name=>'Deseja realmente excluir esse registro?'
,p_region_name=>'button_bar'
,p_icon_css_classes=>'fa-trash'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--wizard:t-Alert--customIcons:t-Alert--danger'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>90
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(55524760045798960)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(444543806886090266)
,p_button_name=>'CONFIRMAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Confirmar'
,p_button_position=>'CREATE'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127026801076993980)
,p_name=>'P238_ID_IDIOMA'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(444543806886090266)
,p_prompt=>'Idioma'
,p_placeholder=>'Selecione o idioma que deseja excluir'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.nome as d,',
'       a.translated_app_language as r',
'from apex_application_trans_map a ',
'join srv_idioma b on lower(b.codigo) = lower(a.translated_app_language)',
'where a.primary_application_id = :p238_id_aplicacao'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(444599912395090556)
,p_name=>'P238_ID_APLICACAO'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(55526761885798968)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'exclui'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_TRADUCAO'
,p_attribute_04=>'EXCLUI'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(55524760045798960)
,p_internal_uid=>55526761885798968
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(55527292366798969)
,p_page_process_id=>wwv_flow_imp.id(55526761885798968)
,p_page_id=>238
,p_name=>'p_id_aplicacao'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P238_ID_APLICACAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(55527731303798970)
,p_page_process_id=>wwv_flow_imp.id(55526761885798968)
,p_page_id=>238
,p_name=>'p_codigo_idioma'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P238_ID_IDIOMA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(55526315235798967)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Closed'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(55524760045798960)
,p_internal_uid=>55526315235798967
);
wwv_flow_imp.component_end;
end;
/
