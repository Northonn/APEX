prompt --application/pages/page_00141
begin
--   Manifest
--     PAGE: 00141
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>141
,p_name=>'Entidade - Mais detalhes da entidade'
,p_alias=>'ENTIDADE-MAIS-DETALHES-DA-ENTIDADE'
,p_step_title=>'Entidade - Mais detalhes da entidade'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$("h1").append($("#icon_info"));'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-side{',
'    width: auto;',
'    box-shadow: none;',
'    max-width: 450px;',
'}'))
,p_step_template=>wwv_flow_imp.id(306300532099923727)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'24'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240308194512'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12056742951840828)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12056892462840829)
,p_plug_name=>'Dados gerais'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody:margin-top-md:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306342585759923752)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin   ',
'    Htp.p(''<div class="a-bloco" id="BLOCO2">'');',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_ENTIDADE.NOME_ENTIDADE_L'',''fa-hardware'',:P141_NOME_ENTIDADE));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_ENTIDADE.DESCRICAO_ENTIDADE_L'',''fa-package'',:P141_DESCRICAO_ENTIDADE));    ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_ENTIDADE.COMPARTILHAMENTO_L'',''fa-code-group'',:P141_COMPARTILHAMENTO));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_ENTIDADE.CARGA_INICIAL_L'',''fa-code'',:P141_CARGA_INICIAL));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_ENTIDADE.ATUALIZACAO_L'',''fa-code'',:P141_ATUALIZACAO,'''',''S''));',
'    Htp.p(''</div>'');',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12057181925840832)
,p_plug_name=>'Colunas'
,p_region_name=>'PAINEL3'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody:margin-top-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(306342585759923752)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_08'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12057340498840834)
,p_plug_name=>'Lista'
,p_parent_plug_id=>wwv_flow_imp.id(12057181925840832)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id,',
'       a.nome_coluna,',
'       a.nome_coluna_banco,',
'       pkg_componentes.html_card_colunas(',
'        ''srv_entidade_coluna.tipo_dado'',',
'        pkg_util.dominio_retorna_tag(''srv_entidade_coluna'',''tipo_dado'',tipo_dado)',
'       ) as atributo1,',
'       pkg_componentes.html_card_colunas(',
'        ''srv_entidade_coluna.tamanho'',',
'        nvl(to_char(tamanho),''N/A'')',
'       ) as atributo2,',
'       pkg_util.dominio_retorna_tag(''srv_entidade_coluna'',''tipo_dado'',tipo_dado) as des_tipo_dado,',
'       case when (',
'                  select count(1) ',
'                  from all_tab_columns ',
'                  where lower(table_name) = lower(b.nome_entidade) ',
'                  and lower(column_name) = lower(trim(a.nome_coluna_banco))',
unistr('                 ) > 0 then '''' else ''N\00E3o criada no banco de dados'' end as des_situacao,'),
'       case when (',
'                  select count(1) ',
'                  from all_tab_columns ',
'                  where lower(table_name) = lower(b.nome_entidade) ',
'                  and lower(column_name) = lower(trim(a.nome_coluna_banco))',
'                 ) > 0 then ''S'' else ''N'' end as situacao                     ',
'from srv_entidade_coluna a',
'join srv_entidade b on b.id = a.id_entidade',
'where id_entidade = :p141_id',
'order by ordenacao'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P141_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(71325363877807632)
,p_region_id=>wwv_flow_imp.id(12057340498840834)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME_COLUNA_BANCO'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'NOME_COLUNA'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.',
'    &ATRIBUTO3!RAW.',
'</div>'))
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'DES_SITUACAO'
,p_badge_css_classes=>'u-danger'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(71325420661807633)
,p_card_id=>wwv_flow_imp.id(71325363877807632)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:146:&SESSION.::&DEBUG.::P146_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--link padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(71325587920807634)
,p_card_id=>wwv_flow_imp.id(71325363877807632)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:136:&SESSION.::&DEBUG.:136:P136_ID,P136_ID_ENTIDADE:&ID.,&P141_ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--link padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(71325774775807636)
,p_plug_name=>'Pesquisa'
,p_parent_plug_id=>wwv_flow_imp.id(12057181925840832)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(12057340498840834)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12993162200294319)
,p_plug_name=>'form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306367078990923765)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       nome_entidade,',
'       descricao_entidade,',
'       pkg_util.dominio_retorna_tag(''srv_entidade'',''compartilhamento'',compartilhamento) as compartilhamento,',
'       pkg_util.dominio_retorna_tag(''srv_entidade'',''carga_inicial'',carga_inicial) as carga_inicial,',
'       pkg_util.dominio_retorna_tag(''srv_entidade'',''atualizacao'',atualizacao) as atualizacao',
'from srv_entidade'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12057023726840831)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12056892462840829)
,p_button_name=>'EDITAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Editar'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:139:P139_ID:&P141_ID.'
,p_icon_css_classes=>'ico-edit-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12057215326840833)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12057181925840832)
,p_button_name=>'EDIT_COLUNAS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--gapRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Editars'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:143:&SESSION.::&DEBUG.:143:P143_ID_ENTIDADE:&P141_ID.'
,p_icon_css_classes=>'ico-edit-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12056999555840830)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12056892462840829)
,p_button_name=>'EXCLUIR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Excluir'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:144:&SESSION.::&DEBUG.::P144_ID:&P141_ID.'
,p_icon_css_classes=>'ico-trash-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12993366751294321)
,p_name=>'P141_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_item_source_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12993642911294324)
,p_name=>'P141_COMPARTILHAMENTO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_item_source_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_source=>'COMPARTILHAMENTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12993803481294326)
,p_name=>'P141_ATUALIZACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_item_source_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_source=>'ATUALIZACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12993980795294327)
,p_name=>'P141_NOME_ENTIDADE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_item_source_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_source=>'NOME_ENTIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12994079034294328)
,p_name=>'P141_DESCRICAO_ENTIDADE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_item_source_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_source=>'DESCRICAO_ENTIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71325678402807635)
,p_name=>'P141_CARGA_INICIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_item_source_plug_id=>wwv_flow_imp.id(12993162200294319)
,p_prompt=>'Carga Inicial'
,p_source=>'CARGA_INICIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(306464296217923826)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71325824242807637)
,p_name=>'P141_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(71325774775807636)
,p_prompt=>'Search'
,p_placeholder=>'Buscar por srv_entidade_coluna.nome_coluna_l ou srv_entidade_coluna.nome_coluna_banco_l'
,p_source=>'NOME_COLUNA,NOME_COLUNA_BANCO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71325940000807638)
,p_name=>'P141_SITUACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(71325774775807636)
,p_prompt=>'Coluna criada?'
,p_source=>'SITUACAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_GERAL.SIM_NAO'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''geral'',''sim_nao'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_suggestions_type=>'DYNAMIC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(71326729170807646)
,p_name=>'onCloseLista'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12057340498840834)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(71326841526807647)
,p_event_id=>wwv_flow_imp.id(71326729170807646)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12057340498840834)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76095290299385926)
,p_name=>'onClosedEditar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(12057023726840831)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76095335347385927)
,p_event_id=>wwv_flow_imp.id(76095290299385926)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload().'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12993297889294320)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(12993162200294319)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Entidade - Mais detalhes da entidade'
,p_internal_uid=>12993297889294320
);
wwv_flow_imp.component_end;
end;
/
