prompt --application/pages/page_00134
begin
--   Manifest
--     PAGE: 00134
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>134
,p_name=>unistr('Tradu\00E7\00E3o - Visualizar')
,p_alias=>unistr('TRADU\00C7\00C3O-VISUALIZAR')
,p_step_title=>unistr('Tradu\00E7\00E3o - Visualizar')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-side{',
'    width: auto;',
'    max-width: 480px;',
'}',
'',
'.a-IRR-actions{',
'    display: none;',
'} ',
'',
''))
,p_step_template=>wwv_flow_imp.id(306300532099923727)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'24'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240227223539'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(232092685145988835)
,p_plug_name=>'LAB_DADOS_GERAIS'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306342585759923752)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin   ',
'    Htp.p(''<div class="a-bloco margin-10" id="BLOCO2">'');',
unistr('    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''Nome da aplica\00E7\00E3o'',''fa-hardware'',:P134_PRIMARY_APPLICATION_NAME,p_label_fixo => ''s''));'),
unistr('    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''N\00FAmero da aplica\00E7\00E3o'',''fa-key'',:P134_PRIMARY_APPLICATION_ID,p_label_fixo => ''s''));    '),
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''Workspace'',''fa-code-fork'',:P134_WORKSPACE,P_ULTIMO=>''s'',p_label_fixo => ''s''));',
'    Htp.p(''</div>'');',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(281039958252394917)
,p_plug_name=>unistr('A\00E7\00F5es')
,p_region_name=>'ACTION'
,p_region_template_options=>'#DEFAULT#:js-dialog-nosize'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showDesc:u-colors'
,p_plug_template=>wwv_flow_imp.id(181614828578350055)
,p_plug_display_sequence=>80
,p_plug_display_point=>'REGION_POSITION_04'
,p_list_id=>wwv_flow_imp.id(187595265019590282)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(306448239332923813)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(370479765104304035)
,p_plug_name=>'Textos'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(306342585759923752)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_08'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(71174425164934704)
,p_name=>'Lista CR'
,p_region_name=>'LISTA_CR'
,p_parent_plug_id=>wwv_flow_imp.id(370479765104304035)
,p_template=>wwv_flow_imp.id(306369115795923766)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select from_string, to_string, language_code, application_id,  ',
'case when dbms_lob.substr(from_string,32767) <> dbms_lob.substr(to_string,32767) then ''S'' else ''N'' end as traduzido ',
'from apex_application_trans_repos',
'where application_id = :P134_PRIMARY_APPLICATION_ID'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P134_PRIMARY_APPLICATION_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(306420272842923797)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(71175583370934715)
,p_query_column_id=>1
,p_column_alias=>'FROM_STRING'
,p_column_display_sequence=>110
,p_column_heading=>'From String'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(71175618038934716)
,p_query_column_id=>2
,p_column_alias=>'TO_STRING'
,p_column_display_sequence=>120
,p_column_heading=>'To String'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(71175816215934718)
,p_query_column_id=>3
,p_column_alias=>'LANGUAGE_CODE'
,p_column_display_sequence=>140
,p_column_heading=>'Language Code'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(71174867064934708)
,p_query_column_id=>4
,p_column_alias=>'APPLICATION_ID'
,p_column_display_sequence=>40
,p_column_heading=>'Application Id'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(71177866466934738)
,p_query_column_id=>5
,p_column_alias=>'TRADUZIDO'
,p_column_display_sequence=>150
,p_column_heading=>'Traduzido'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(71176969816934729)
,p_plug_name=>'Pesquisa'
,p_parent_plug_id=>wwv_flow_imp.id(370479765104304035)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-sm:margin-left-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(71174425164934704)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53872191351136949352)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_parent_plug_id=>wwv_flow_imp.id(370479765104304035)
,p_region_template_options=>'#DEFAULT#:margin-left-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(306367078990923765)
,p_plug_display_sequence=>30
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql varchar(2000);',
'begin',
'    l_sql := q''~',
'        select ',
'            to_char(a.from_string) from_string,',
'            to_char(a.to_string) to_string,',
'            b.nome,',
'            a.application_id,',
'            a.id,',
'            language_code,',
'            ''opcao'' as opcao',
'        from apex_application_trans_repos a',
'        left join srv_idioma b on lower(b.codigo) = lower(a.language_code)',
'        where a.application_id = :P134_PRIMARY_APPLICATION_ID        ',
'        and (to_char(a.from_string) like ''%''||:P134_SEARCH||''%'' or to_char(a.to_string) like ''%''||:P134_SEARCH||''%'')',
'        and lower(a.language_code) = lower(nvl(:P134_IDIOMA,a.language_code))',
'        ~'';',
'    if :P134_TRADUZIDO = ''S'' then',
'        l_sql := l_sql || '' and dbms_lob.substr(from_string,32767) <> dbms_lob.substr(to_string,32767)'';',
'    else    ',
'        l_sql := l_sql || '' and dbms_lob.substr(from_string,32767) = dbms_lob.substr(to_string,32767)'';',
'    end if;    ',
'',
'    return l_sql;',
'end;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P134_PRIMARY_APPLICATION_ID,P134_SEARCH,P134_IDIOMA,P134_TRADUZIDO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Rela\00E7\00E3o dos assuntos a serem apresentados no tutorial')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(415321115201634618)
,p_max_row_count=>'1000000'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NORTHONN'
,p_internal_uid=>415321115201634618
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71174336928934703)
,p_db_column_name=>'NOME'
,p_display_order=>30
,p_column_identifier=>'S'
,p_column_label=>'Idioma'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71322214188807601)
,p_db_column_name=>'OPCAO'
,p_display_order=>40
,p_column_identifier=>'T'
,p_column_label=>'LAB_ACAO'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_BOTOES_LISTAGEM_AVANCADO'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71322411742807603)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>50
,p_column_identifier=>'U'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71322550072807604)
,p_db_column_name=>'ID'
,p_display_order=>60
,p_column_identifier=>'V'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71322776944807606)
,p_db_column_name=>'LANGUAGE_CODE'
,p_display_order=>70
,p_column_identifier=>'W'
,p_column_label=>'Language Code'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71322822554807607)
,p_db_column_name=>'FROM_STRING'
,p_display_order=>80
,p_column_identifier=>'X'
,p_column_label=>'Texto original'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71322923302807608)
,p_db_column_name=>'TO_STRING'
,p_display_order=>90
,p_column_identifier=>'Y'
,p_column_label=>'Texto traduzido'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(415395229608205182)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'448217'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOME:FROM_STRING:TO_STRING:OPCAO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53793518867575734197)
,p_plug_name=>'Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306367078990923765)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    distinct WORKSPACE, ',
'    PRIMARY_APPLICATION_ID, ',
'    PRIMARY_APPLICATION_NAME, ',
'    pkg_traducao.lista_traducao(PRIMARY_APPLICATION_ID) as lista_aplicacao',
'from apex_application_trans_map ',
'where WORKSPACE <> ''INTERNAL''  '))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80814895173971258095)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(71114554806806651)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(370479765104304035)
,p_button_name=>'BTN_VALORES'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EDITAR'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:226:&SESSION.::&DEBUG.:226:P226_ID_DOMINIO:&P134_ID.'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa ico-edit-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(71112975091806644)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(232092685145988835)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EXCLUIR '
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:238:&SESSION.::&DEBUG.:238:P238_ID_APLICACAO:&P134_PRIMARY_APPLICATION_ID.'
,p_icon_css_classes=>'fa ico-trash-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(71114129537806650)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(370479765104304035)
,p_button_name=>'BTN_UTILITARIOS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--gapRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_UTILITARIOS'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-tools-sm'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70368043284546846)
,p_name=>'P134_WORKSPACE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(53793518867575734197)
,p_item_source_plug_id=>wwv_flow_imp.id(53793518867575734197)
,p_source=>'WORKSPACE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70368133893546847)
,p_name=>'P134_PRIMARY_APPLICATION_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(53793518867575734197)
,p_item_source_plug_id=>wwv_flow_imp.id(53793518867575734197)
,p_source=>'PRIMARY_APPLICATION_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70368273891546848)
,p_name=>'P134_PRIMARY_APPLICATION_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(53793518867575734197)
,p_item_source_plug_id=>wwv_flow_imp.id(53793518867575734197)
,p_source=>'PRIMARY_APPLICATION_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70368335048546849)
,p_name=>'P134_LISTA_APLICACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(53793518867575734197)
,p_item_source_plug_id=>wwv_flow_imp.id(53793518867575734197)
,p_source=>'LISTA_APLICACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71177025564934730)
,p_name=>'P134_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(71176969816934729)
,p_prompt=>'Search'
,p_placeholder=>'Buscar por texto original ou texto traduzido'
,p_source=>'FROM_STRING,TO_STRING'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71177421284934734)
,p_name=>'P134_TRADUZIDO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(71176969816934729)
,p_prompt=>'Texto traduzido?'
,p_source=>'TRADUZIDO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'D_GERAL.SIM_NAO'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''geral'',''sim_nao'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>false
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_suggestions_type=>'STATIC'
,p_suggestions_source=>'S'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71178076712934740)
,p_name=>'P134_IDIOMA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(71176969816934729)
,p_prompt=>'Idioma'
,p_source=>'LANGUAGE_CODE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'select nome d, codigo r from srv_idioma'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>false
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_suggestions_type=>'DYNAMIC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(71121520350806680)
,p_name=>'onClosedDelete'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(71112975091806644)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(71122016216806681)
,p_event_id=>wwv_flow_imp.id(71121520350806680)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'history.back()'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(71122466584806682)
,p_name=>'onClickBOT_LIST_ACOES'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(71114129537806650)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(71122951412806683)
,p_event_id=>wwv_flow_imp.id(71122466584806682)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281039958252394917)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(71123399150806684)
,p_name=>unistr('onClickAc\00F5es')
,p_event_sequence=>130
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(281039958252394917)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(71123868689806685)
,p_event_id=>wwv_flow_imp.id(71123399150806684)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281039958252394917)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(71177169344934731)
,p_name=>'onChangePesquisa'
,p_event_sequence=>140
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(71176969816934729)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(71177299921934732)
,p_event_id=>wwv_flow_imp.id(71177169344934731)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const milissegundos = 1 * 1000;',
'setTimeout(function() {',
'    apex.region("LISTA").refresh();',
'}, milissegundos);',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(71119497034806674)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(53793518867575734197)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Mais detalhes do tutorial'
,p_internal_uid=>71119497034806674
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(71322320157807602)
,p_ir_column_id=>wwv_flow_imp.id(71322214188807601)
,p_position_id=>wwv_flow_imp.id(219650775531049839)
,p_display_sequence=>10
,p_label=>'BTN_EDITAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:135:P135_ID_APLICACAO,P135_IDIOMA,P135_FROM_STRING,P135_TO_STRING:#APPLICATION_ID#,#LANGUAGE_CODE#,#FROM_STRING#,#TO_STRING#'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp.component_end;
end;
/
