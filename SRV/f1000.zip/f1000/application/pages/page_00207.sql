prompt --application/pages/page_00207
begin
--   Manifest
--     PAGE: 00207
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>207
,p_name=>'Tipos de Tarefaa'
,p_alias=>'TIPOS-DE-TAREFAA'
,p_step_title=>'Tipos de Tarefaa'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$("h1").append($("#icon_info"));'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-CardView-header{',
'    background-color: aliceblue;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'}',
'',
'.t-DialogRegion-buttons{',
'    display: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(306300532099923727)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240209193318'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43586068013059829)
,p_plug_name=>'Tipos de tarefas'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useRegionTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55534300001364319)
,p_plug_name=>'Artefatos Grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'   NOME,',
'   DESCRICAO,',
'   STATUS,',
'   CASE',
'    WHEN STATUS = 1 THEN ''Ativado''',
'    WHEN STATUS = 2 THEN ''Desativado''',
'    ELSE ''INVALIDO''',
'   END DS_STATUS',
'  from SRV_TIPO_TAREFAS'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(15919593216905309)
,p_region_id=>wwv_flow_imp.id(55534300001364319)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row">',
'    <div class="col col-9 apex-col-auto col-start">',
unistr('        <div style="font-size: 12px;font-style: italic;">Descri\00E7\00E3o</div>'),
'        <div style="font-weight: bold;">&DESCRICAO.</div>',
'    </div>',
'    <div class="col col-3 apex-col-auto" style="text-align: end;">',
'        <div style="font-size: 12px;font-style: italic;">Status</div>',
'        <div style="font-weight: bold;">&DS_STATUS.</div>',
'    </div>',
'</div>'))
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'NOME'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(15920086716905310)
,p_card_id=>wwv_flow_imp.id(15919593216905309)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>unistr('Mais informa\00E7\00F5es')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:212:&SESSION.::&DEBUG.:212:P212_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(15920632282905312)
,p_card_id=>wwv_flow_imp.id(15919593216905309)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>unistr('Op\00E7\00F5es')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:211:&SESSION.::&DEBUG.:211:P211_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55534491863364319)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-sm:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(55534300001364319)
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55546120534435611)
,p_plug_name=>'Artefatos Row'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NOME,',
'       DESCRICAO,',
'       STATUS,',
'        CASE',
'            WHEN STATUS = 1 THEN ''Ativado''',
'            WHEN STATUS = 2 THEN ''Desativado''',
'            ELSE ''INVALIDO''',
'        END DS_STATUS',
'  from SRV_TIPO_TAREFAS'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(15922639486905322)
,p_region_id=>wwv_flow_imp.id(55546120534435611)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row">',
'    <div class="col col-5 padding-left-md padding-top-md">',
'        <div class="a-CardView-headerBody">',
unistr('            <div class="ng-estilo-titulo-mi">Descri\00E7\00E3o</div>'),
'            <div class="row">',
'                <div class="col col-12 apex-col-auto col-start">',
'                    <h5 class="margin-top-none">&DESCRICAO.</h5>',
'                </div>',
'            </div>',
'        </div>',
'    </div>  ',
'',
'    <div class="col col-2 padding-left-md padding-top-md">',
'        <div class="a-CardView-headerBody">',
'            <div class="ng-estilo-titulo-mi">Status</div>',
'            <div class="row">',
'                <div class="col col-12 apex-col-auto col-start">',
'                    <h5 class="margin-top-none">&DS_STATUS.</h5>',
'                </div>',
'            </div>',
'        </div>',
'    </div> ',
'</div>'))
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'NOME'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(15923108734905324)
,p_card_id=>wwv_flow_imp.id(15922639486905322)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>unistr('Mais informa\00E7\00F5es')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:212:&SESSION.::&DEBUG.:212:P212_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(15923739815905325)
,p_card_id=>wwv_flow_imp.id(15922639486905322)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>unistr('Op\00E7\00F5es')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:211:&SESSION.::&DEBUG.:211:P211_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123627543066680132)
,p_plug_name=>'Button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15924795789905328)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(123627543066680132)
,p_button_name=>'SHOW_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Esconder filtro'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter '
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15925103370905330)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(123627543066680132)
,p_button_name=>'HIDE_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Mostrar filtro'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter fam-x fam-is-danger'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15925564568905330)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(123627543066680132)
,p_button_name=>'SHOW_ROW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Visualizar em linhas'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-media-list'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15925920970905331)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(123627543066680132)
,p_button_name=>'SHOW_GRID'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Visualizar em grade'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-cards'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15926344466905333)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(123627543066680132)
,p_button_name=>'Novo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Novo'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:208:&SESSION.::&DEBUG.:208::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44406438206582740)
,p_name=>'P207_FIL_SITUACAO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(55534491863364319)
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:Ativado;1,Desativado;2'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55547551981364378)
,p_name=>'P207_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(55534491863364319)
,p_prompt=>unistr('Pesquise por Nome ou descri\00E7\00E3o')
,p_placeholder=>unistr('Pesquise por t\00EDtulo ou descri\00E7\00E3o')
,p_source=>'NOME, DESCRICAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15928185804905343)
,p_name=>'Show_search'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15924795789905328)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15928611130905344)
,p_event_id=>wwv_flow_imp.id(15928185804905343)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). hide();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15929144206905346)
,p_event_id=>wwv_flow_imp.id(15928185804905343)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15925103370905330)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15929650040905347)
,p_event_id=>wwv_flow_imp.id(15928185804905343)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15924795789905328)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15930016733905348)
,p_name=>'hide_search'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15925103370905330)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15930506418905349)
,p_event_id=>wwv_flow_imp.id(15930016733905348)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). show();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15931089363905350)
,p_event_id=>wwv_flow_imp.id(15930016733905348)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15924795789905328)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15931570429905351)
,p_event_id=>wwv_flow_imp.id(15930016733905348)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15925103370905330)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15931951357905352)
,p_name=>'show_ROW'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15925564568905330)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15932472630905353)
,p_event_id=>wwv_flow_imp.id(15931951357905352)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15925920970905331)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15932984511905354)
,p_event_id=>wwv_flow_imp.id(15931951357905352)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15925564568905330)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15933433378905355)
,p_event_id=>wwv_flow_imp.id(15931951357905352)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(55546120534435611)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15933957011905356)
,p_event_id=>wwv_flow_imp.id(15931951357905352)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(55534300001364319)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15934384557905357)
,p_name=>'show_grid'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15925920970905331)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15934849661905358)
,p_event_id=>wwv_flow_imp.id(15934384557905357)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15925564568905330)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15935811847905360)
,p_event_id=>wwv_flow_imp.id(15934384557905357)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(55534300001364319)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15935367971905359)
,p_event_id=>wwv_flow_imp.id(15934384557905357)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15925920970905331)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15936317085905361)
,p_event_id=>wwv_flow_imp.id(15934384557905357)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(55546120534435611)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15927259738905340)
,p_name=>'After-close'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(55534300001364319)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15927716647905342)
,p_event_id=>wwv_flow_imp.id(15927259738905340)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(55534300001364319)
);
wwv_flow_imp.component_end;
end;
/
