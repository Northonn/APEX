prompt --application/pages/page_00123
begin
--   Manifest
--     PAGE: 00123
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>123
,p_name=>'Sistema - Lista versao'
,p_alias=>'SISTEMA-LISTA-VERSAO'
,p_page_mode=>'MODAL'
,p_step_title=>'Sistema - Lista versao'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-CardView-actions{',
'    padding: 0px;',
'}',
'',
'.a-CardView-items{',
'    grid-gap: 5px;',
'}'))
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'24'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240314141253'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(225402108981691370)
,p_plug_name=>'Pesquisa'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>40
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(367747576834094030)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(367747576834094030)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id,',
'       a.id_tenant,',
'       a.id_sistema,',
'       a.versao,',
'       a.situacao,',
'       pkg_util.dominio_retorna_tag(''srv_sistema_versionado'',''situacao'',a.situacao) as des_situacao,',
'       a.data_descontinuidade,',
'       a.id_menu,',
'       a.id_grupo_funcionalidade',
'  from srv_sistema_versionado a',
'  where a.id_sistema = :P123_ID_SISTEMA',
'  '))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P123_ID_SISTEMA'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(75362843115487865)
,p_region_id=>wwv_flow_imp.id(367747576834094030)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'VERSAO'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DATA_DESCONTINUIDADE'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'DES_SITUACAO'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(75363342538487868)
,p_card_id=>wwv_flow_imp.id(75362843115487865)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.:125:P125_ID,P125_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(75363933997487870)
,p_card_id=>wwv_flow_imp.id(75362843115487865)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_EDITAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.:125:P125_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(75364592037487872)
,p_card_id=>wwv_flow_imp.id(75362843115487865)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>40
,p_label=>'BTN_EXCLUIR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:127:&SESSION.::&DEBUG.:127:P127_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link u-danger-text'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(528315169958195367)
,p_plug_name=>'button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>'<div id="active_facets"></div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75365569312487875)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(225402108981691370)
,p_button_name=>'BTN_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'ORDER_BY_ITEM'
,p_button_redirect_url=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.:125:P125_ID_SISTEMA,P125_ID_TENANT:&P123_ID_SISTEMA.,&P123_ID_TENANT.'
,p_button_css_classes=>'u-pullRight'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75311373052760347)
,p_name=>'P123_ID_TENANT'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(225410363985691410)
,p_name=>'P123_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(225402108981691370)
,p_prompt=>'Search'
,p_placeholder=>'Buscar por srv_sistema_versionado.versao_l'
,p_source=>'VERSAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226024026788364502)
,p_name=>'P123_NOME_SISTEMA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(225402108981691370)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_prompt=>'srv_sistema.nome_sistema_l'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(367761124536094135)
,p_name=>'P123_ID_SISTEMA'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(75367133501487889)
,p_computation_sequence=>10
,p_computation_item=>'P123_NOME_SISTEMA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select ''(''||codigo_sistema||'') ''|| nome_sistema from srv_sistema where id = :P123_ID_SISTEMA'
,p_compute_when=>'P123_ID_SISTEMA'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75368381305487893)
,p_name=>'onClosedLista'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(367747576834094030)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75368887099487895)
,p_event_id=>wwv_flow_imp.id(75368381305487893)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(367747576834094030)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75367402989487890)
,p_name=>'onClosedBTN_NOVO'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(75365569312487875)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75367940005487892)
,p_event_id=>wwv_flow_imp.id(75367402989487890)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(367747576834094030)
);
wwv_flow_imp.component_end;
end;
/
