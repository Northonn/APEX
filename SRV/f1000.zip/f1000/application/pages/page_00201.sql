prompt --application/pages/page_00201
begin
--   Manifest
--     PAGE: 00201
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>201
,p_name=>'Atividade Tarefa'
,p_alias=>'ATIVIDADE-TAREFA'
,p_step_title=>'Atividade Tarefa'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$("h1").append($("#icon_info"));'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-actions{',
'    display: none;',
'}',
'',
'.a-CardView-header{',
'    background-color: aliceblue;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'}',
'',
'.t-ButtonRegion-buttons',
'{',
' display: flex;',
' justify-content: flex-end;',
' align-items: center;',
'}',
'',
'.t-Region',
'{',
'    border: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(306300532099923727)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'ANTHONI'
,p_last_upd_yyyymmddhh24miss=>'20240222182441'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27645328829134499)
,p_plug_name=>'Entidades'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39616155380459024)
,p_plug_name=>'Atividade_tarefa Grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'   NOME,',
'   DESCRICAO,',
'   STATUS,',
'   CASE',
'    WHEN STATUS = 1 THEN ''Ativado''',
'    WHEN STATUS = 2 THEN ''Desativado''',
'    ELSE ''INVALIDO''',
'   END DS_STATUS',
'  from SRV_ATIVIDADE_TAREFAS'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(15594756811293714)
,p_region_id=>wwv_flow_imp.id(39616155380459024)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row">',
'    <div class="col col-9 apex-col-auto col-start">',
unistr('        <div style="font-size: 12px;font-style: italic;">Descri\00E7\00E3o</div>'),
'        <div style="font-weight: bold;">&DESCRICAO.</div>',
'    </div>',
'    <div class="col col-3 apex-col-auto" style="text-align: end;">',
'        <div style="font-size: 12px;font-style: italic;">Status</div>',
'        <div style="font-weight: bold;">&DS_STATUS.</div>',
'    </div>',
'</div>'))
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'NOME'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(15595239805293716)
,p_card_id=>wwv_flow_imp.id(15594756811293714)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>unistr('Mais informa\00E7\00F5es')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:206:&SESSION.::&DEBUG.:206:P206_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(15595882174293717)
,p_card_id=>wwv_flow_imp.id(15594756811293714)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>unistr('Op\00E7\00F5es')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:205:&SESSION.::&DEBUG.::P205_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39616347242459024)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-sm:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(39616155380459024)
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39627975913530316)
,p_plug_name=>'Atividade_tarefa Row'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NOME,',
'       DESCRICAO,',
'       STATUS,',
'        CASE',
'            WHEN STATUS = 1 THEN ''Ativado''',
'            WHEN STATUS = 2 THEN ''Desativado''',
'            ELSE ''INVALIDO''',
'        END DS_STATUS',
'  from SRV_ATIVIDADE_TAREFAS'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(15598703180293728)
,p_region_id=>wwv_flow_imp.id(39627975913530316)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row">',
'    <div class="col col-5 padding-left-md padding-top-md">',
'        <div class="a-CardView-headerBody">',
unistr('            <div class="ng-estilo-titulo-mi">Descri\00E7\00E3o</div>'),
'            <div class="row">',
'                <div class="col col-12 apex-col-auto col-start">',
'                    <h5 class="margin-top-none">&DESCRICAO.</h5>',
'                </div>',
'            </div>',
'        </div>',
'    </div>  ',
'',
'    <div class="col col-2 padding-left-md padding-top-md">',
'        <div class="a-CardView-headerBody">',
'            <div class="ng-estilo-titulo-mi">Status</div>',
'            <div class="row">',
'                <div class="col col-12 apex-col-auto col-start">',
'                    <h5 class="margin-top-none">&DS_STATUS.</h5>',
'                </div>',
'            </div>',
'        </div>',
'    </div> ',
'</div>'))
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'NOME'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(15599277212293730)
,p_card_id=>wwv_flow_imp.id(15598703180293728)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>unistr('Mais informa\00E7\00F5es')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:206:&SESSION.::&DEBUG.:206:P206_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(15599801965293731)
,p_card_id=>wwv_flow_imp.id(15598703180293728)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>unistr('Op\00E7\00F5es')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:205:&SESSION.::&DEBUG.::P205_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54521756638090911)
,p_plug_name=>'Search row'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-sm:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(39627975913530316)
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107709398445774837)
,p_plug_name=>'Button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15601229117293735)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(107709398445774837)
,p_button_name=>'HIDE_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Esconder filtro'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter '
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15601603910293736)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(107709398445774837)
,p_button_name=>'SHOW_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Mostrar filtro'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter fam-x fam-is-danger'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15602079453293737)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(107709398445774837)
,p_button_name=>'SHOW_ROW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Visualizar em linhas'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-media-list'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15602433549293738)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(107709398445774837)
,p_button_name=>'SHOW_GRID'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Visualizar em grade'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-cards'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15602885320293738)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(107709398445774837)
,p_button_name=>'Novo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Novo'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:202::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28484786755677426)
,p_name=>'P201_FIL_SITUACAO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(39616347242459024)
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:Ativado;1,Desativado;2'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39625900530459064)
,p_name=>'P201_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(39616347242459024)
,p_prompt=>unistr('Pesquise por Nome ou descri\00E7\00E3o')
,p_placeholder=>unistr('Pesquise por t\00EDtulo ou descri\00E7\00E3o')
,p_source=>'NOME, DESCRICAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54521823325090912)
,p_name=>'P201_SEARCH_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(54521756638090911)
,p_prompt=>unistr('Pesquise por Nome ou descri\00E7\00E3o')
,p_placeholder=>unistr('Pesquise por t\00EDtulo ou descri\00E7\00E3o')
,p_source=>'NOME, DESCRICAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54521926175090913)
,p_name=>'P201_FIL_SITUACAO_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54521756638090911)
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:Ativado;1,Desativado;2'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15605559050293745)
,p_name=>'onClickEscondePesquisa'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15601229117293735)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15606064740293746)
,p_event_id=>wwv_flow_imp.id(15605559050293745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). hide();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15606500586293747)
,p_event_id=>wwv_flow_imp.id(15605559050293745)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15601603910293736)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15607026136293748)
,p_event_id=>wwv_flow_imp.id(15605559050293745)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15601229117293735)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15607449566293749)
,p_name=>'onClickMostraPesquisa'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15601603910293736)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15607991482293750)
,p_event_id=>wwv_flow_imp.id(15607449566293749)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). show();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15608466344293751)
,p_event_id=>wwv_flow_imp.id(15607449566293749)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15601229117293735)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15608968090293752)
,p_event_id=>wwv_flow_imp.id(15607449566293749)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15601603910293736)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15609306615293753)
,p_name=>'onClickMostraLinhas'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15602079453293737)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15609810756293755)
,p_event_id=>wwv_flow_imp.id(15609306615293753)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15602433549293738)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15610804862293757)
,p_event_id=>wwv_flow_imp.id(15609306615293753)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39627975913530316)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54523975993090933)
,p_event_id=>wwv_flow_imp.id(15609306615293753)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54521756638090911)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54523881635090932)
,p_event_id=>wwv_flow_imp.id(15609306615293753)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39616347242459024)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15610358263293756)
,p_event_id=>wwv_flow_imp.id(15609306615293753)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15602079453293737)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15611315426293758)
,p_event_id=>wwv_flow_imp.id(15609306615293753)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39616155380459024)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15611750744293758)
,p_name=>'onClickMostraGrid'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15602433549293738)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15612238327293759)
,p_event_id=>wwv_flow_imp.id(15611750744293758)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15602079453293737)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15613219601293762)
,p_event_id=>wwv_flow_imp.id(15611750744293758)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39616155380459024)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54524082962090934)
,p_event_id=>wwv_flow_imp.id(15611750744293758)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39616347242459024)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54524192242090935)
,p_event_id=>wwv_flow_imp.id(15611750744293758)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54521756638090911)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15612796695293761)
,p_event_id=>wwv_flow_imp.id(15611750744293758)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(15602433549293738)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15613728779293763)
,p_event_id=>wwv_flow_imp.id(15611750744293758)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39627975913530316)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15604648002293743)
,p_name=>'Atividade_tarefa Grid'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(39616155380459024)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54522757854090921)
,p_event_id=>wwv_flow_imp.id(15604648002293743)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39616155380459024)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54522863482090922)
,p_event_id=>wwv_flow_imp.id(15604648002293743)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39627975913530316)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54522948117090923)
,p_event_id=>wwv_flow_imp.id(15604648002293743)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39616347242459024)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54523080435090924)
,p_event_id=>wwv_flow_imp.id(15604648002293743)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54521756638090911)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54522225485090916)
,p_name=>'onCloseNOVO'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15602885320293738)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54522369494090917)
,p_event_id=>wwv_flow_imp.id(54522225485090916)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39616155380459024)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54522449554090918)
,p_event_id=>wwv_flow_imp.id(54522225485090916)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39627975913530316)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54522619781090920)
,p_event_id=>wwv_flow_imp.id(54522225485090916)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39616347242459024)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54522555125090919)
,p_event_id=>wwv_flow_imp.id(54522225485090916)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54521756638090911)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54523173628090925)
,p_name=>'onCloseAtividade_tarefa Row'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(39627975913530316)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54523368827090927)
,p_event_id=>wwv_flow_imp.id(54523173628090925)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39616155380459024)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54523440748090928)
,p_event_id=>wwv_flow_imp.id(54523173628090925)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39627975913530316)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54523530073090929)
,p_event_id=>wwv_flow_imp.id(54523173628090925)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39616347242459024)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54523630930090930)
,p_event_id=>wwv_flow_imp.id(54523173628090925)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54521756638090911)
);
wwv_flow_imp.component_end;
end;
/
