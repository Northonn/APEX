prompt --application/pages/page_07643
begin
--   Manifest
--     PAGE: 07643
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>7643
,p_name=>'Teste de Mensagem'
,p_alias=>'TESTE-DE-MENSAGEM'
,p_page_mode=>'MODAL'
,p_step_title=>'Teste de Mensagem'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240424131501'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80928352261742739)
,p_plug_name=>'Teste de mensagem'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading js-removeLandmark:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(80929090547742746)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(80928352261742739)
,p_button_name=>'TESTAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Testar'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80928404058742740)
,p_name=>'P7643_NOME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(80928352261742739)
,p_prompt=>'Nome'
,p_placeholder=>unistr('Informe o nome do usu\00E1rio')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Nome do usu\00E1rio')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80928572958742741)
,p_name=>'P7643_TELEFONE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(80928352261742739)
,p_prompt=>'Telefone'
,p_placeholder=>unistr('Informe o telefone do usu\00E1rio')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Telefone do usu\00E1rio')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80928669835742742)
,p_name=>'P7643_ENDERECO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(80928352261742739)
,p_prompt=>'Endereco'
,p_placeholder=>unistr('Informe o endere\00E7o do usu\00E1rio')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Endere\00E7o do usu\00E1rio')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80928720561742743)
,p_name=>'P7643_MENSAGEM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(80928352261742739)
,p_prompt=>'Mensagem'
,p_placeholder=>'Mensagem'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select codigo_mensagem from srv_aplicacao_mensagem order by codigo_mensagem',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80928848373742744)
,p_name=>'P7643_EXIBIR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(80928352261742739)
,p_prompt=>unistr('Tipo de exibi\00E7\00E3o')
,p_placeholder=>unistr('Exibi\00E7\00E3o')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>unistr('STATIC2:Notifica\00E7\00E3o;1,Inline ;2,Notifica\00E7\00E3o + inline;3')
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80928955527742745)
,p_name=>'P7643_CAMPO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(80928352261742739)
,p_prompt=>'Campo'
,p_placeholder=>'Campo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select label from apex_application_page_items where application_id = :app_id and page_id = :app_page_id and display_as = ''Text Field'''
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80929154068742747)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Teste de mensagem'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_exibir varchar2(10);',
'    l_parametros_mensagem varchar2(255) := :P7643_CAMPO;',
'    l_parametros_ajuda varchar2(255) := :P7643_CAMPO;',
'begin',
'    if :P7643_EXIBIR = 1 then',
'        l_exibir := pk_constants.c_exibe_pagina;',
'    elsif :P7643_EXIBIR = 2 then',
'        l_exibir := pk_constants.c_exibe_campo;',
'    elsif :P7643_EXIBIR = 3 then',
'        l_exibir := pk_constants.c_exibe_pagina_campo;',
'    end if;    ',
'    pkg_api_mensagem.exibir_mensagem(',
'        pkg_api_mensagem.busca_mensagem (',
'            p_codigo_mensagem       => :P7643_MENSAGEM,        ',
'            p_exibicao              => l_exibir,',
'            p_nome_coluna           => :P7643_CAMPO,',
'            p_page_id               => :app_page_id,',
'            p_parametros_mensagem   => l_parametros_mensagem,',
'            p_parametros_ajuda      => l_parametros_ajuda',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(80929090547742746)
,p_internal_uid=>80929154068742747
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(90561255137397135)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into imp_pedidocompra2 ',
'(id_tenant,',
'numero_pedido,',
'id_fornecedor,',
'id_importador,',
'id_comprador,',
'nome_vendedor,',
'id_moeda,',
'modalidade_importacao,',
'id_trading,',
'id_natureza_operacao,',
'id_viatransporte,',
'id_incoterm,',
'id_local_embarque,',
'id_local_chegada,',
'id_condicao_pagamento,',
'id_idioma,',
'data_confirmacao_pedido,',
'status_pedido,',
'numero_proforma,',
'tipo_entrega,',
'valor_total_mercadoria,',
'valor_desconto,',
'valor_despesa_origem,',
'valor_total_condicao_venda,',
'status_atendimento,',
'id_usuario_incluiu,',
'id_usuario_alterou',
')',
'values',
'(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, SYSDATE, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_required_patch=>wwv_flow_imp.id(306296283938923705)
,p_internal_uid=>90561255137397135
);
wwv_flow_imp.component_end;
end;
/
