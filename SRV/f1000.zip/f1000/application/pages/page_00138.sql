prompt --application/pages/page_00138
begin
--   Manifest
--     PAGE: 00138
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>138
,p_name=>'Entidades'
,p_alias=>'ENTIDADES'
,p_step_title=>'Entidades'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$("h1").append($("#icon_info"));'
,p_step_template=>wwv_flow_imp.id(306300532099923727)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240308171852'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12054386964840804)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12408404134724502)
,p_plug_name=>'Carregar dados'
,p_region_template_options=>'#DEFAULT#:js-popup-callout:js-dialog-nosize:js-popup-pos-inside'
,p_plug_template=>wwv_flow_imp.id(181614828578350055)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_04'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12408968512724507)
,p_plug_name=>'Carregar dados'
,p_parent_plug_id=>wwv_flow_imp.id(12408404134724502)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>40
,p_plug_header=>unistr('<h3 style="text-align: center;">Deseja carregar o arquivo para importa\00E7\00E3o?</h3>')
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12409052667724508)
,p_plug_name=>'Salvar modelo'
,p_parent_plug_id=>wwv_flow_imp.id(12408404134724502)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_header=>unistr('<h3 class="margin-top-none" style="text-align: center;">Deseja salvar o arquivo de modelo da importa\00E7\00E3o?</h3>')
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12409111552724509)
,p_plug_name=>'Ou'
,p_parent_plug_id=>wwv_flow_imp.id(12408404134724502)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_plug_source=>'<div class="margin-top-lg" style="text-align: center; color:darkgray;">------- ou -------</div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24025213516165329)
,p_plug_name=>'Lista'
,p_region_name=>'CARDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id,',
'       a.id_tenant,',
'       a.id_sistema_versionado,',
'       nome_entidade,',
'       case',
'        when length(descricao_entidade) > 50 then concat(substr(descricao_entidade, 1,50), ''...'') ',
'        else descricao_entidade',
'       end as descricao_entidade,',
'       fonte_carga_inicial,',
'       fonte_atualizacao,',
'       compartilhamento,',
'       carga_inicial,',
'       atualizacao,',
'       pkg_componentes.html_card_colunas(',
'            ''srv_entidade.compartilhamento_l'',',
'            pkg_util.dominio_retorna_tag(''srv_entidade'',''compartilhamento'',compartilhamento)',
'       ) as atributo1,',
'       pkg_componentes.html_card_colunas(',
'            ''srv_entidade.carga_inicial_l'',',
'            pkg_util.dominio_retorna_tag(''srv_entidade'',''carga_inicial'',carga_inicial)',
'       ) as atributo2,',
'       pkg_componentes.html_card_colunas(',
'            ''srv_entidade.atualizacao_l'',',
'            pkg_util.dominio_retorna_tag(''srv_entidade'',''atualizacao'',atualizacao)',
'       ) as atributo3,  ',
'       /*pkg_componentes.html_badge(''Colunas a sincronizar'',',
'            bo_srv_entidade.retorna_colunas_inconsistentes(a.id),',
'            ''u-warning u-bold u-font-size-sm'') as atributo4,         */',
unistr('       /*case when (select count(1) from all_tables where upper(table_name) = upper(nome_entidade)) = 0 then ''N\00E3o criada'' end as des_situacao_banco,*/'),
'       case when (select count(1) from all_tables where upper(table_name) = upper(nome_entidade)) > 0 then ''S'' else ''N'' end as situacao_banco,',
unistr('       case when (Select count(1) from ALL_OBJECTS where lower(OBJECT_NAME) = lower(''bo_''||nome_entidade) and OBJECT_TYPE = ''PACKAGE'') > 0 then '''' else ''BO n\00E3o criado'' end as des_situacao_bo'),
'       ',
'  from srv_entidade a',
' '))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(12248578585854519)
,p_region_id=>wwv_flow_imp.id(24025213516165329)
,p_layout_type=>'GRID'
,p_grid_column_count=>2
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME_ENTIDADE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DESCRICAO_ENTIDADE'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.',
'    &ATRIBUTO3!RAW.',
'</div>'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'&ATRIBUTO4!RAW.'
,p_badge_column_name=>'DES_SITUACAO_BO'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12249055692854520)
,p_card_id=>wwv_flow_imp.id(12248578585854519)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:141:&SESSION.::&DEBUG.:141:P141_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12249645516854522)
,p_card_id=>wwv_flow_imp.id(12248578585854519)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.::P140_ID,P140_NOME_TABELA:&ID.,&NOME_ENTIDADE.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24025405378165329)
,p_plug_name=>'Pesquisa'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-left-sm'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(24025213516165329)
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92118456581481142)
,p_plug_name=>'Button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12408529884724503)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12409052667724508)
,p_button_name=>'IMP_SALVAR_MODELO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(306466985742923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar modelo'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12408649227724504)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12408968512724507)
,p_button_name=>'IMP_CARREGAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconLeft:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(306466985742923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_UPLOAD'
,p_button_redirect_url=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:113::'
,p_icon_css_classes=>'fa-upload'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12254901378854539)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(92118456581481142)
,p_button_name=>'HIDE_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_ESCONDE_FILTRO'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-filter-list-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12255396272854540)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(92118456581481142)
,p_button_name=>'SHOW_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_MOSTRA_FILTRO'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-filter-list-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12255766171854541)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(92118456581481142)
,p_button_name=>'SHOW_ROW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_MOSTRA_LINHA'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-card-line-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12256194384854542)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(92118456581481142)
,p_button_name=>'SHOW_GRID'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_MOSTRA_GRADE'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-card-grid-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12408345064724501)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(92118456581481142)
,p_button_name=>'IMPORT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_UPLOAD'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-upload-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69283319454779722)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(92118456581481142)
,p_button_name=>'Exportar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EXPORTAR'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:0:&SESSION.:APPLICATION_PROCESS=DOWNLOAD_DIAGRAM:&DEBUG.::DOWNLOAD_DIAGRAM_LISTA_TABELA:&P138_ID_FILTRADOS.'
,p_icon_css_classes=>'fa ico-diagram-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12256533686854543)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(92118456581481142)
,p_button_name=>'Novo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:139::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12054730518840808)
,p_name=>'P138_FIL_CARGA_INICIAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(24025405378165329)
,p_prompt=>'srv_entidade.carga_inicial_l'
,p_source=>'CARGA_INICIAL'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_SRV_ENTIDADE.CARGA'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''srv_entidade'',''carga_inicial'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12054833765840809)
,p_name=>'P138_FIL_ATUALIZACAO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(24025405378165329)
,p_prompt=>'srv_entidade.atualizacao_l'
,p_source=>'ATUALIZACAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_SRV_ENTIDADE.ATUALIZACAO'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''srv_entidade'',''atualizacao'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12887789016383705)
,p_name=>'P138_FIL_COMPARTILHAMENTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24025405378165329)
,p_prompt=>'srv_entidade.compartilhamento_l'
,p_source=>'COMPARTILHAMENTO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_SRV_ENTIDADE.COMPARTILHAMENTO'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''srv_entidade'',''compartilhamento'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24029005862165344)
,p_name=>'P138_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24025405378165329)
,p_placeholder=>'Buscar por srv_entidade.nome_entidade_l ou srv_entidade.descricao_entidade_l'
,p_source=>'NOME_ENTIDADE,DESCRICAO_ENTIDADE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71326951797807648)
,p_name=>'P138_SITUACAO_BANCO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(24025405378165329)
,p_prompt=>'Entidade criada?'
,p_source=>'SITUACAO_BANCO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'D_GERAL.SIM_NAO'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''geral'',''sim_nao'')'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_05=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12257497025854546)
,p_name=>'onClickEscondePesquisa'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(12254901378854539)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12257941668854547)
,p_event_id=>wwv_flow_imp.id(12257497025854546)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). hide();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12258474325854549)
,p_event_id=>wwv_flow_imp.id(12257497025854546)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(12255396272854540)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12258943123854550)
,p_event_id=>wwv_flow_imp.id(12257497025854546)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(12254901378854539)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12259302992854551)
,p_name=>'onClickMostraPesquisa'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(12255396272854540)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12259825587854552)
,p_event_id=>wwv_flow_imp.id(12259302992854551)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). show();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12260364489854553)
,p_event_id=>wwv_flow_imp.id(12259302992854551)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(12254901378854539)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12260809411854554)
,p_event_id=>wwv_flow_imp.id(12259302992854551)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(12255396272854540)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12261208879854555)
,p_name=>'onClickMostraLinhas'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(12255766171854541)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12261771271854556)
,p_event_id=>wwv_flow_imp.id(12261208879854555)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(12256194384854542)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12262250942854557)
,p_event_id=>wwv_flow_imp.id(12261208879854555)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(12255766171854541)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12263202751854559)
,p_event_id=>wwv_flow_imp.id(12261208879854555)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(24025213516165329)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16818574501112443)
,p_event_id=>wwv_flow_imp.id(12261208879854555)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(24025405378165329)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12263644377854560)
,p_name=>'onClickMostraGrade'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(12256194384854542)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12264188378854561)
,p_event_id=>wwv_flow_imp.id(12263644377854560)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(12255766171854541)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12265157991854563)
,p_event_id=>wwv_flow_imp.id(12263644377854560)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(24025213516165329)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16818676174112444)
,p_event_id=>wwv_flow_imp.id(12263644377854560)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(24025405378165329)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12264605159854562)
,p_event_id=>wwv_flow_imp.id(12263644377854560)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(12256194384854542)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12408734779724505)
,p_name=>'onClickImportar'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(12408345064724501)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12408818105724506)
,p_event_id=>wwv_flow_imp.id(12408734779724505)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12408404134724502)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11933395531580150)
,p_name=>'onAfterCloseLista'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(24025213516165329)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12887361267383701)
,p_event_id=>wwv_flow_imp.id(11933395531580150)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(24025213516165329)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12887464641383702)
,p_name=>'onClickCarregasDados'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12408404134724502)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12887512173383703)
,p_event_id=>wwv_flow_imp.id(12887464641383702)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12408404134724502)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(71095670001708297)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>90
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(71096056016708299)
,p_event_id=>wwv_flow_imp.id(71095670001708297)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(71324160393807620)
,p_name=>'onCloseImportar'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(12408649227724504)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(71324208198807621)
,p_event_id=>wwv_flow_imp.id(71324160393807620)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(24025213516165329)
);
wwv_flow_imp.component_end;
end;
/
