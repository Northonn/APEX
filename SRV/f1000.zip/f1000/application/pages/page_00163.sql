prompt --application/pages/page_00163
begin
--   Manifest
--     PAGE: 00163
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>163
,p_name=>unistr('Mensagens - Op\00E7\00F5es')
,p_alias=>unistr('MENSAGENS-OP\00C7\00D5ES')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Op\00E7\00F5es')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240325195136'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(90236564754314982864)
,p_plug_name=>unistr('Op\00E7\00F5es das mensagens')
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(282106748184034546)
,p_plug_name=>unistr('Op\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(90236564754314982864)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showArrow:t-LinksList--actions:t-LinksList--showIcons'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(78054163615130545)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(306454209904923818)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53237571940005929)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(90236564754314982864)
,p_button_name=>'BTN_EDITAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EDITAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:165:&SESSION.::&DEBUG.:165:P165_ID:&P163_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53237685944005930)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(90236564754314982864)
,p_button_name=>'BTN_DUPLICAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_DUPLICAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:161:&SESSION.::&DEBUG.:161:P161_ID:&P163_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53237763120005931)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(90236564754314982864)
,p_button_name=>'BTN_EXCLUIR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EXCLUIR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:164:&SESSION.::&DEBUG.:164:P164_ID:&P163_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-trash'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76149284762440043)
,p_name=>'P163_ID_TENANT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(90236564754314982864)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(281849459594083017)
,p_name=>'P163_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(90236564754314982864)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(282107256433034556)
,p_name=>'P163_BLOQUEADO_POR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(90236564754314982864)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(78050469073090803)
,p_name=>'Page load'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(78050979520090804)
,p_event_id=>wwv_flow_imp.id(78050469073090803)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(window).width() < 480) {',
'    $( "ul.t-Cards" ).removeClass( "t-Cards--spanHorizontally" );',
'    $( "ul.t-Cards" ).addClass( "t-Cards--float" );',
'}',
'else {',
'    $( "ul.t-Cards" ).addClass( "t-Cards--spanHorizontally" );',
'    $( "ul.t-Cards" ).removeClass( "t-Cards--float" );',
'}'))
);
wwv_flow_imp.component_end;
end;
/
