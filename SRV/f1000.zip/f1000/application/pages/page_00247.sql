prompt --application/pages/page_00247
begin
--   Manifest
--     PAGE: 00247
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>247
,p_name=>unistr('Artefatos - Incluir um novo bot\00E3o a\00E7\00E3o')
,p_alias=>unistr('ARTEFATOS-INCLUIR-UM-NOVO-BOT\00C3O-A\00C7\00C3O')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Artefatos - Incluir um novo bot\00E3o a\00E7\00E3o')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("body").on("click", "#" + ''LIST_ABA'' + " " + ''.t-MediaList-itemWrap'', function (e) {',
'    e.preventDefault();',
'            var selectedID = $(this).data("id");',
'            AtribuirValorItem(''P51_ABA'',selectedID);',
'})'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region-bodyWrap{',
'    background-color: white;',
'    //border-radius: 10px !IMPORTANT;',
'}',
'',
'.st-radius-100{',
'    border-radius: 100%!IMPORTANT;',
'}',
'',
'.t-Form-labelContainer--hiddenLabel{',
'    display: none;',
'}',
'',
'.apex-item-text {',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group--popup-lov{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-popup-lov{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;    ',
'}',
'',
'.a-Button {',
'         border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'.a-Button--popupLOV{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'',
'.ap-password-eye{',
'    box-shadow: none!IMPORTANT;',
'}',
'',
'.st-item-center{   ',
'    display: block !IMPORTANT;',
'    text-align: center !IMPORTANT;',
'}',
'',
'.a-bloco{',
'    padding: 10px;',
'}',
'',
'.apex-item-filedrop{',
'    border: none;',
'}',
'',
'.apex-item-filedrop-progress{',
'    border: none;',
'}',
'',
'.apex-item-filedrop{',
'    color: var(--ut-body-text-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when=>'P247_VISUALIZAR'
,p_page_component_map=>'17'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240423124139'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129194371696872776757)
,p_plug_name=>unistr('Incluir um novo bot\00E3o a\00E7\00E3o')
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading js-removeLandmark:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>33
,p_query_type=>'TABLE'
,p_query_table=>'SRV_ARTEFATO_BOTAO_ACAO'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77664007486423294)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_GRAVAR'
,p_button_position=>'CREATE'
,p_button_condition=>':P247_EDITAR IS NULL AND :P247_VISUALIZAR IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77663627405423292)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_GRAVAR'
,p_button_position=>'CREATE'
,p_button_condition=>':P247_ID IS NOT NULL AND :P247_VISUALIZAR IS NULL AND :P247_DUPLICAR IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77626178610123041)
,p_name=>'P247_ID_ARTEFATO_VERSIONADO_EXIBIR'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_item_source_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_prompt=>'srv_artefato_botao_acao.id_artefato_versionado_exibir_l'
,p_placeholder=>'srv_artefato_botao_acao.id_artefato_versionado_exibir_i'
,p_source=>'ID_ARTEFATO_VERSIONADO_EXIBIR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'R_SRV_ARTEFATO_VERSIONADO.ID_ARTEFATO_VERSIONADO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.titulo_artefato||'' (''||b.codigo_artefato||'')'' as display_value,',
'       d.versao, ',
'       b.descricao_artefato,',
'       a.id as return_value',
'from srv_artefato_versionado a',
'left join srv_artefato b on  b.id = a.id_artefato',
'left join srv_aplicacao_versionada c on c.id = a.id_aplicacao_versionada',
'left join srv_sistema_versionado d on d.id = c.id_sistema_versionado'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>'srv_artefato_botao_acao.id_artefato_versionado_exibir_h'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154397101373408505)
,p_name=>'P247_ID_ARTEFATO_VERSIONADO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_item_source_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_source=>'ID_ARTEFATO_VERSIONADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154406589908408550)
,p_name=>'P247_VISUALIZAR'
,p_item_sequence=>1
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154406687156408551)
,p_name=>'P247_DUPLICAR'
,p_item_sequence=>2
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154407980980408564)
,p_name=>'P247_EDITAR'
,p_item_sequence=>3
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204843082665643435)
,p_name=>'P247_ID_TENANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_item_source_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_source=>'ID_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'mpd_tenant.razao_social_h'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204843382144643438)
,p_name=>'P247_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_item_source_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204843555364643439)
,p_name=>'P247_DATA_INCLUSAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_item_source_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204843646609643440)
,p_name=>'P247_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_item_source_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204843724437643441)
,p_name=>'P247_DATA_ALTERACAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_item_source_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(230960472111007949)
,p_name=>'P247_RESULTADO'
,p_item_sequence=>4
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(230960644123007950)
,p_name=>'P247_RESULTADO_MENSAGEM'
,p_item_sequence=>5
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(433846514062288370)
,p_name=>'P247_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_item_source_plug_id=>wwv_flow_imp.id(129194371696872776757)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(79783992934757207)
,p_computation_sequence=>10
,p_computation_item=>'P247_ID_TENANT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select id_tenant from srv_artefato_versionado where id = :P247_ID_ARTEFATO_VERSIONADO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77677887476423344)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'INCLUI_REGISTRO'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_SRV_ARTEFATO_BOTAO_ACAO'
,p_attribute_04=>'INCLUI_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(77664007486423294)
,p_process_success_message=>'&P247_RESULTADO_MENSAGEM.'
,p_internal_uid=>77677887476423344
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77626261403123042)
,p_page_process_id=>wwv_flow_imp.id(77677887476423344)
,p_page_id=>247
,p_name=>'p_id_artefato_versionado_exibir'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P247_ID_ARTEFATO_VERSIONADO_EXIBIR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77678329760423345)
,p_page_process_id=>wwv_flow_imp.id(77677887476423344)
,p_page_id=>247
,p_name=>'p_id_artefato_versionado'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>90
,p_value_type=>'ITEM'
,p_value=>'P247_ID_ARTEFATO_VERSIONADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77679849502423348)
,p_page_process_id=>wwv_flow_imp.id(77677887476423344)
,p_page_id=>247
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P247_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77680338762423349)
,p_page_process_id=>wwv_flow_imp.id(77677887476423344)
,p_page_id=>247
,p_name=>'p_id'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P247_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77680820032423350)
,p_page_process_id=>wwv_flow_imp.id(77677887476423344)
,p_page_id=>247
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77681391934423351)
,p_page_process_id=>wwv_flow_imp.id(77677887476423344)
,p_page_id=>247
,p_name=>'p_resultado'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P247_RESULTADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77681807798423352)
,p_page_process_id=>wwv_flow_imp.id(77677887476423344)
,p_page_id=>247
,p_name=>'p_resultado_mensagem'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P247_RESULTADO_MENSAGEM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77673427336423330)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'ALTERA_REGISTRO'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_SRV_ARTEFATO_BOTAO_ACAO'
,p_attribute_04=>'ALTERA_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(77663627405423292)
,p_process_success_message=>'&P247_RESULTADO_MENSAGEM.'
,p_internal_uid=>77673427336423330
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77626329810123043)
,p_page_process_id=>wwv_flow_imp.id(77673427336423330)
,p_page_id=>247
,p_name=>'p_id_artefato_versionado_exibir'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>90
,p_value_type=>'ITEM'
,p_value=>'P247_ID_ARTEFATO_VERSIONADO_EXIBIR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77626410261123044)
,p_page_process_id=>wwv_flow_imp.id(77673427336423330)
,p_page_id=>247
,p_name=>'p_data_alteracao'
,p_direction=>'IN'
,p_data_type=>'TIMESTAMP'
,p_has_default=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P247_DATA_ALTERACAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77673990918423336)
,p_page_process_id=>wwv_flow_imp.id(77673427336423330)
,p_page_id=>247
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P247_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77674451116423337)
,p_page_process_id=>wwv_flow_imp.id(77673427336423330)
,p_page_id=>247
,p_name=>'p_id_artefato_versionado'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P247_ID_ARTEFATO_VERSIONADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77675997205423340)
,p_page_process_id=>wwv_flow_imp.id(77673427336423330)
,p_page_id=>247
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P247_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77676486267423341)
,p_page_process_id=>wwv_flow_imp.id(77673427336423330)
,p_page_id=>247
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77676995333423342)
,p_page_process_id=>wwv_flow_imp.id(77673427336423330)
,p_page_id=>247
,p_name=>'p_resultado'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P247_RESULTADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(77677442758423343)
,p_page_process_id=>wwv_flow_imp.id(77673427336423330)
,p_page_id=>247
,p_name=>'p_resultado_mensagem'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P247_RESULTADO_MENSAGEM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77682269784423353)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_01=>'P247_RESULTADO_MENSAGEM'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>77682269784423353
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77672067270423320)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(129194371696872776757)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Incluir conte\00FAdo')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>77672067270423320
);
wwv_flow_imp.component_end;
end;
/
