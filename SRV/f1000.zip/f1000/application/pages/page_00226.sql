prompt --application/pages/page_00226
begin
--   Manifest
--     PAGE: 00226
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>226
,p_name=>'Dominio - Lista valores'
,p_alias=>'DOMINIO-LISTA-VALORES'
,p_page_mode=>'MODAL'
,p_step_title=>'Lista de valores'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240307113555'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142547135426977387)
,p_plug_name=>'Lista'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark:t-Form--large'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       tag,',
'       valor',
'  from srv_dominio_valor ',
'  where id_dominio = :P226_ID_DOMINIO',
'  order by valor'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P226_ID_DOMINIO'
,p_plug_query_num_rows=>15
,p_attribute_02=>'TAG'
,p_attribute_08=>'VALOR'
,p_attribute_16=>'f?p=&APP_ID.:227:&SESSION.::&DEBUG.:227:P227_ID:&ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303114728551078724)
,p_plug_name=>'button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>'<div id="active_facets"></div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53911810505681287)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(142547135426977387)
,p_button_name=>'BTN_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_redirect_url=>'f?p=&APP_ID.:227:&SESSION.::&DEBUG.:227:P227_ID_DOMINIO,P227_ID_TENANT,P227_ID_SISTEMA_VERSIONADO:&P226_ID_DOMINIO.,&P226_ID_TENANT.,&P226_ID_SISTEMA_VERSIONADO.'
,p_button_css_classes=>'u-pullRight'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(53960605650923320)
,p_branch_name=>'go to 227'
,p_branch_action=>'f?p=&APP_ID.:227:&SESSION.::&DEBUG.:227:P227_ID_DOMINIO:&P226_ID_DOMINIO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'NOT_EXISTS'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       tag,',
'       valor',
'  from srv_dominio_valor ',
'  where id_dominio = :P226_ID_DOMINIO'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75412537577820224)
,p_name=>'P226_ID_TENANT'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75412606699820225)
,p_name=>'P226_ID_SISTEMA_VERSIONADO'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142549553207977391)
,p_name=>'P226_ID_DOMINIO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53849371843394632)
,p_name=>'onClosedBtnNovo'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(53911810505681287)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53849475794394633)
,p_event_id=>wwv_flow_imp.id(53849371843394632)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(142547135426977387)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53849532923394634)
,p_name=>'onClosedLista'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(142547135426977387)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53849631404394635)
,p_event_id=>wwv_flow_imp.id(53849532923394634)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(142547135426977387)
);
wwv_flow_imp.component_end;
end;
/
