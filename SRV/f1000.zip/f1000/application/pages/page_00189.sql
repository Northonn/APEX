prompt --application/pages/page_00189
begin
--   Manifest
--     PAGE: 00189
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>189
,p_name=>'Projetos - Mais detalhes'
,p_alias=>'PROJETOS-MAIS-DETALHES'
,p_step_title=>'Projetos - Mais detalhes'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'a {',
'    font-size: 16px;',
'    font-weight: 100;',
'}',
'',
'.t-Body-side{',
'    width: auto;',
'    box-shadow: none;',
'    max-width: 450px;',
'}',
'',
'.t-Region{',
'    border: none;',
'}',
'',
'h5{',
'    margin-top: 0px;',
'    margin-bottom: 0px;',
'    font-weight: bold;',
'}',
'',
'a {',
'    font-size: 12px;',
'    font-weight: normal;',
'}'))
,p_step_template=>wwv_flow_imp.id(306300532099923727)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'ANTHONI'
,p_last_upd_yyyymmddhh24miss=>'20240304164010'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15307504254054534)
,p_plug_name=>'Documentos'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody:margin-top-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(306342585759923752)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_08'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15305589507054514)
,p_plug_name=>'Documentos'
,p_parent_plug_id=>wwv_flow_imp.id(15307504254054534)
,p_region_template_options=>'#DEFAULT#:margin-top-none:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306367078990923765)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'        id,',
'       NOME_DOCUMENTO,',
'       DESCRICAO,',
'       dbms_lob.getlength(anexo) anexo,',
'       ''btn_avancado'' AS btn_avancado,',
'       mimetype,',
'       filename',
'  from SRV_PROJETOS_DOCUMENTOS',
'   WHERE ID_PROJETO = :P189_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P189_ID'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(15305683104054515)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nenhum documento cadastrado neste projeto!'
,p_show_search_bar=>'N'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'ANTHONI'
,p_internal_uid=>15305683104054515
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15308793263054546)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'I'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15305779579054516)
,p_db_column_name=>'DESCRICAO'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Descricao'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15306934453054528)
,p_db_column_name=>'NOME_DOCUMENTO'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Nome Documento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15308650292054545)
,p_db_column_name=>'ANEXO'
,p_display_order=>40
,p_column_identifier=>'H'
,p_column_label=>'Anexo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:SRV_PROJETOS_DOCUMENTOS:ANEXO:ID::MIMETYPE:FILENAME:::attachment::'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15307144595054530)
,p_db_column_name=>'BTN_AVANCADO'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>unistr('A\00E7\00F5es')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_BOTOES_LISTAGEM_AVANCADO'
,p_heading_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15308833000054547)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>60
,p_column_identifier=>'J'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15308905273054548)
,p_db_column_name=>'FILENAME'
,p_display_order=>70
,p_column_identifier=>'K'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(15343306768192482)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'153434'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DESCRICAO:NOME_DOCUMENTO:ANEXO:BTN_AVANCADO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27341826668770539)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27341976179770540)
,p_plug_name=>'Dados gerais'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody:margin-top-md:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306342585759923752)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin   ',
'    Htp.p(''<div class="a-bloco" id="BLOCO2">'');',
'    /*',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_PROJETOS.NOME_PROJETO_L'',''fa-hardware'',:P189_NOME_PROJETO));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_PROJETOS.DESCRICAO_L'',''fa-package'',:P189_DESCRICAO));    ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_PROJETOS.ID_RESPONSAVEL_L'',''fa-code-group'',:P189_NOME_RESPONSAVEL));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_PROJETOS.DATA_INICIO_L'',''fa-code'',:P189_DATA_INICIO));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_PROJETOS.DATA_TERMINO_L'',''fa-code'',:P189_DATA_TERMINO));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_PROJETOS.TOTAL_HORAS_L'',''fa-code'',:P189_TOTAL_HORAS));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_PROJETOS.SITUACAO_L'',''fa-code'',:P189_DS_SITUACAO));',
'    */',
'    Htp.p(''<br>'');',
'    Htp.p(''</div>'');',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27342265642770543)
,p_plug_name=>'Tarefas'
,p_region_name=>'PAINEL3'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody:margin-top-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(306342585759923752)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_08'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27342424215770545)
,p_plug_name=>'Colunas'
,p_parent_plug_id=>wwv_flow_imp.id(27342265642770543)
,p_region_template_options=>'#DEFAULT#:margin-top-none:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306367078990923765)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    SPT.id,',
'    SPT.id_projeto,',
'    SPT.NOME_TAREFA,',
'    SPT.DESCRICAO,',
'    SPT.DATA_INICIO,',
'    SPT.DATA_TERMINO,',
'    SPT.TOTAL_HORAS,',
'    SPT.SITUACAO,',
'    ''btn_avancado'' AS btn_avancado,',
'    CASE',
'        WHEN SPT.SITUACAO = 1 THEN ''Aberto''',
'        WHEN SPT.SITUACAO = 2 THEN ''Pausado''',
unistr('        WHEN SPT.SITUACAO = 3 THEN ''Conclu\00EDdo'''),
'        WHEN SPT.SITUACAO = 4 THEN ''Cancelado''',
'        WHEN SPT.SITUACAO = 5 THEN ''Atrasado''',
'        ELSE ''Invalido''',
'    END AS DS_SITUACAO,',
'    TA.NOME AS TIPO_ATIVIDADE,',
'    TT.NOME AS TIPO_TAREFA',
'FROM ',
'    SRV_PROJETOS_TAREFAS SPT',
'    LEFT JOIN SRV_ATIVIDADE_TAREFAS TA ON SPT.TIPO_ATIVIDADE = TA.ID',
'    LEFT JOIN SRV_TIPO_TAREFAS TT ON SPT.TIPO_TAREFA = TT.ID',
'WHERE ',
'    SPT.ID_PROJETO = :P189_ID;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P189_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Colunas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(27342512433770546)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nenhum documento cadastrado neste projeto!'
,p_show_search_bar=>'N'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'ANTHONI'
,p_internal_uid=>27342512433770546
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15402288494520611)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'O'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15406114929520650)
,p_db_column_name=>'ID_PROJETO'
,p_display_order=>20
,p_column_identifier=>'P'
,p_column_label=>'Id Projeto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15304643717054505)
,p_db_column_name=>'NOME_TAREFA'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Tarefa'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15081572723653745)
,p_db_column_name=>'DESCRICAO'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>unistr('Descri\00E7\00E3o')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15081658873653746)
,p_db_column_name=>'DATA_INICIO'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>unistr('Data de in\00EDcio')
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15081769489653747)
,p_db_column_name=>'DATA_TERMINO'
,p_display_order=>60
,p_column_identifier=>'I'
,p_column_label=>'Data Final'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15081832583653748)
,p_db_column_name=>'TOTAL_HORAS'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Total de horas'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15304748123054506)
,p_db_column_name=>'SITUACAO'
,p_display_order=>90
,p_column_identifier=>'M'
,p_column_label=>unistr('Situa\00E7\00E3o')
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15534291210865901)
,p_db_column_name=>'DS_SITUACAO'
,p_display_order=>100
,p_column_identifier=>'Q'
,p_column_label=>unistr('Situa\00E7\00E3o')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15305129961054510)
,p_db_column_name=>'BTN_AVANCADO'
,p_display_order=>110
,p_column_identifier=>'N'
,p_column_label=>unistr('A\00E7\00F5es')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_BOTOES_LISTAGEM_AVANCADO'
,p_heading_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16481830071714923)
,p_db_column_name=>'TIPO_ATIVIDADE'
,p_display_order=>120
,p_column_identifier=>'R'
,p_column_label=>'Tipo Atividade'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16481922309714924)
,p_db_column_name=>'TIPO_TAREFA'
,p_display_order=>130
,p_column_identifier=>'S'
,p_column_label=>'Tipo Tarefa'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(28287919673277326)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'130029'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOME_TAREFA:DESCRICAO:DS_SITUACAO:TIPO_ATIVIDADE:TIPO_TAREFA:DATA_TERMINO:DATA_INICIO:TOTAL_HORAS:BTN_AVANCADO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28278245917224030)
,p_plug_name=>'form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306367078990923765)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    p.ID,',
'    p.ID_OS,',
'    p.ID_RESPONSAVEL,',
'    u.NOME AS NOME_RESPONSAVEL,',
'    p.NOME_PROJETO,',
'    p.DESCRICAO,',
'    p.DATA_INICIO,',
'    p.DATA_TERMINO,',
'    p.TOTAL_HORAS,',
'    p.SITUACAO,',
'    p.ID_USUARIO_INCLUIU,',
'    p.DATA_INCLUSAO,',
'    p.ID_USUARIO_ALTEROU,',
'    p.DATA_ALTERACAO,',
'    CASE ',
'        WHEN p.SITUACAO = ''1'' THEN ''Aberto''',
'        WHEN p.SITUACAO = ''2'' THEN ''Pausado''',
unistr('        WHEN p.SITUACAO = ''3'' THEN ''Conclu\00EDdo'''),
'        WHEN p.SITUACAO = ''4'' THEN ''Cancelado''',
'        WHEN p.SITUACAO = ''5'' THEN ''Atrasado''',
unistr('        ELSE ''inv\00E1lido'''),
'    END AS DS_SITUACAO',
'FROM SRV_PROJETOS p',
'INNER JOIN mpd_usuario u ON p.ID_RESPONSAVEL = u.ID;',
'',
''))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15286053538929718)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(27341976179770540)
,p_button_name=>'EDIT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Editar'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:190:&SESSION.::&DEBUG.::P190_ID:&P189_ID.'
,p_icon_css_classes=>'ico-edit-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15308422143054543)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(15307504254054534)
,p_button_name=>'NEW_DOCUMENTO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--gapRight:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Novo documento'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:193:&SESSION.::&DEBUG.:193:P193_ID_PROJETO:&P189_ID.'
,p_icon_css_classes=>'ico-upload-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15308366309054542)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(27342265642770543)
,p_button_name=>'NEW_TAREFA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--gapRight:t-Button--padTop:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Nova tarefa'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:192:&SESSION.::&DEBUG.:192:P192_ID_PROJETO:&P189_ID.'
,p_icon_css_classes=>'ico-upload-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15285643333929717)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(27341976179770540)
,p_button_name=>'EXCLUIR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Excluir'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:191:&SESSION.::&DEBUG.::P191_ID:&P189_ID.'
,p_icon_css_classes=>'ico-trash-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15079708740653727)
,p_name=>'P189_ID_OS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'ID_OS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15079865829653728)
,p_name=>'P189_ID_RESPONSAVEL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'ID_RESPONSAVEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15079978494653729)
,p_name=>'P189_NOME_PROJETO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'NOME_PROJETO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15080095289653730)
,p_name=>'P189_DESCRICAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'DESCRICAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15080172198653731)
,p_name=>'P189_DATA_INICIO'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'DATA_INICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15080279182653732)
,p_name=>'P189_DATA_TERMINO'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'DATA_TERMINO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15080302069653733)
,p_name=>'P189_TOTAL_HORAS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'TOTAL_HORAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15080409974653734)
,p_name=>'P189_SITUACAO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'SITUACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15080569596653735)
,p_name=>'P189_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15080663605653736)
,p_name=>'P189_DATA_INCLUSAO'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15080773382653737)
,p_name=>'P189_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15080811968653738)
,p_name=>'P189_DATA_ALTERACAO'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15080903064653739)
,p_name=>'P189_NOME_RESPONSAVEL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'NOME_RESPONSAVEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15081026799653740)
,p_name=>'P189_DS_SITUACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'DS_SITUACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16512943259110008)
,p_name=>'P189_RECALCULAR_HORAS'
,p_item_sequence=>20
,p_item_default=>'0'
,p_item_default_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16514836836110027)
,p_name=>'P189_MSG'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28280242837224041)
,p_name=>'P189_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_item_source_plug_id=>wwv_flow_imp.id(28278245917224030)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15866829686775017)
,p_name=>'onCloseColunas'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(27342424215770545)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15866969823775018)
,p_event_id=>wwv_flow_imp.id(15866829686775017)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(27342424215770545)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16514192678110020)
,p_event_id=>wwv_flow_imp.id(15866829686775017)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Deseja recalcular as horas do projeto?'
,p_attribute_02=>'Recalcular horas'
,p_attribute_03=>'information'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16514307467110022)
,p_event_id=>wwv_flow_imp.id(15866829686775017)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15867443042775023)
,p_name=>'onCloseDocumentos'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(15305589507054514)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15867563013775024)
,p_event_id=>wwv_flow_imp.id(15867443042775023)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(15305589507054514)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15867028891775019)
,p_name=>'onCloseNEW_TAREFA'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15308366309054542)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15867179692775020)
,p_event_id=>wwv_flow_imp.id(15867028891775019)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(27342424215770545)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16515785366110036)
,p_event_id=>wwv_flow_imp.id(15867028891775019)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Deseja recalcular as horas do projeto?'
,p_attribute_02=>'Recalcular horas'
,p_attribute_03=>'information'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16515892699110037)
,p_event_id=>wwv_flow_imp.id(15867028891775019)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15867257846775021)
,p_name=>'onCloseNEW_DOCUMENTO'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15308422143054543)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15867368732775022)
,p_event_id=>wwv_flow_imp.id(15867257846775021)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(15305589507054514)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16514901541110028)
,p_name=>'onPageLoad'
,p_event_sequence=>60
,p_condition_element=>'P189_MSG'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16515040247110029)
,p_event_id=>wwv_flow_imp.id(16514901541110028)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var valorItem = apex.item("P189_MSG").getValue();',
'apex.message.showPageSuccess(valorItem, null, {',
'    duration: 50000 // 5000 milissegundos = 5 segundos',
'});'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16515130425110030)
,p_event_id=>wwv_flow_imp.id(16514901541110028)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P189_MSG'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16513354090110012)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'RECALCULAR_DATAS'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_PROJETOS_TAREFAS'
,p_attribute_04=>'RECALCULA_DATAS_PROJETO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>16513354090110012
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(16513456372110013)
,p_page_process_id=>wwv_flow_imp.id(16513354090110012)
,p_page_id=>189
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P189_MSG'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(16513543121110014)
,p_page_process_id=>wwv_flow_imp.id(16513354090110012)
,p_page_id=>189
,p_name=>'id_projeto'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P189_ID'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15290559543929735)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(28278245917224030)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Entidade - Mais detalhes da entidade'
,p_internal_uid=>15290559543929735
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(15305205331054511)
,p_ir_column_id=>wwv_flow_imp.id(15305129961054510)
,p_position_id=>wwv_flow_imp.id(219650775531049839)
,p_display_sequence=>30
,p_label=>'Alterar tarefa'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:194:&SESSION.::&DEBUG.:194:P194_ID:#ID#'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(15305390160054512)
,p_ir_column_id=>wwv_flow_imp.id(15305129961054510)
,p_position_id=>wwv_flow_imp.id(219650999904050597)
,p_display_sequence=>60
,p_label=>'Excluir tarefa'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:195:&SESSION.::&DEBUG.:195:P195_ID:#ID#'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(15305484657054513)
,p_ir_column_id=>wwv_flow_imp.id(15305129961054510)
,p_position_id=>wwv_flow_imp.id(224103727162980004)
,p_display_sequence=>40
,p_label=>'Copiar tarefa'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:192:&SESSION.::&DEBUG.:192:P192_ID:#ID#'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(15307218549054531)
,p_ir_column_id=>wwv_flow_imp.id(15307144595054530)
,p_position_id=>wwv_flow_imp.id(219650775531049839)
,p_display_sequence=>10
,p_label=>'Alterar documento'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:197:&SESSION.::&DEBUG.::P197_ID:#ID#'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(15307448957054533)
,p_ir_column_id=>wwv_flow_imp.id(15307144595054530)
,p_position_id=>wwv_flow_imp.id(219650999904050597)
,p_display_sequence=>20
,p_label=>'Excluir documento'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:196:&SESSION.::&DEBUG.:196:P196_ID:#ID#'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(15406016168520649)
,p_ir_column_id=>wwv_flow_imp.id(15305129961054510)
,p_position_id=>wwv_flow_imp.id(219740073065324523)
,p_display_sequence=>10
,p_label=>unistr('Usu\00E1rios')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:199:&SESSION.::&DEBUG.::P199ID_TAREFA,P199_ID_PROJETO:#ID#,#ID_PROJETO#'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(15536685822865925)
,p_ir_column_id=>wwv_flow_imp.id(15305129961054510)
,p_position_id=>wwv_flow_imp.id(219740073065324523)
,p_display_sequence=>20
,p_label=>'Documentos'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:213:&SESSION.::&DEBUG.::P213ID_TAREFA,P213_ID_PROJETO:#ID#,#ID_PROJETO#'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp.component_end;
end;
/
