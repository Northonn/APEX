prompt --application/pages/page_00182
begin
--   Manifest
--     PAGE: 00182
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>182
,p_name=>unistr('Idioma - Op\00E7\00F5es')
,p_alias=>unistr('IDIOMA-OP\00C7\00D5ES')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Op\00E7\00F5es')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240325194818'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26700499360899522)
,p_plug_name=>unistr('Op\00E7\00F5es entidade')
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69891207810637331)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(26700499360899522)
,p_button_name=>'BTN_EDITAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EDITAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:181:&SESSION.::&DEBUG.:181:P181_ID:&P182_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69891388747637332)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(26700499360899522)
,p_button_name=>'BTN_DUPLICAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_DUPLICAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:181:&SESSION.::&DEBUG.:181:P181_COPIA:&P182_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69891465128637333)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(26700499360899522)
,p_button_name=>'BTN_EXCLUIR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EXCLUIR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:184:&SESSION.::&DEBUG.:184:P184_ID:&P182_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-trash '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26701423391899529)
,p_name=>'P182_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(26700499360899522)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
