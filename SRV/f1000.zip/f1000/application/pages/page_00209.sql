prompt --application/pages/page_00209
begin
--   Manifest
--     PAGE: 00209
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>209
,p_name=>'Tipo de Tarefa - Alterar tipo de tarefa'
,p_alias=>'TIPO-DE-TAREFA-ALTERAR-TIPO-DE-TAREFA'
,p_page_mode=>'MODAL'
,p_step_title=>'Tipo de Tarefa - Alterar tipo de tarefa'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
't-Region-bodyWrap{',
'    background-color: white;',
'    //border-radius: 10px !IMPORTANT;',
'}',
'',
'.st-radius-100{',
'    border-radius: 100%!IMPORTANT;',
'}',
'',
'.t-Form-labelContainer--hiddenLabel{',
'    display: none;',
'}',
'',
'.apex-item-text {',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group--popup-lov{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-popup-lov{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;    ',
'}',
'',
'.a-Button {',
'         border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'.a-Button--popupLOV{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'',
'.ap-password-eye{',
'    box-shadow: none!IMPORTANT;',
'}',
'',
'.st-item-center{   ',
'    display: block !IMPORTANT;',
'    text-align: center !IMPORTANT;',
'}',
'',
'.a-bloco{',
'    padding: 10px;',
'}',
'',
'.apex-item-filedrop{',
'    border: none;',
'}',
'',
'.apex-item-filedrop-progress{',
'    border: none;',
'}',
'',
'.apex-item-filedrop{',
'    color: var(--ut-body-text-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(306325325666923741)
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240209192957'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129189937799822342582)
,p_plug_name=>'Alterar tipo de tarefa'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'SRV_TIPO_TAREFAS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15954390888949415)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(129189937799822342582)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar'
,p_button_position=>'NEXT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15953907243949414)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(129189937799822342582)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_image_alt=>'&D_BTN_CANCELAR.'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(15965194350949440)
,p_branch_name=>'Go to 207'
,p_branch_action=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:207::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31489714363815324)
,p_name=>'P209_NOME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(129189937799822342582)
,p_item_source_plug_id=>wwv_flow_imp.id(129189937799822342582)
,p_prompt=>'Nome do tipo de tarefa'
,p_placeholder=>'Informe o nome da atividade tarefa'
,p_source=>'NOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_cattributes_element=>'style="text-align: start;"'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(306464112839923826)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_help_text=>'Nome da atividade tarefa inclusa no banco de dados'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31489823824815325)
,p_name=>'P209_DESCRICAO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(129189937799822342582)
,p_item_source_plug_id=>wwv_flow_imp.id(129189937799822342582)
,p_prompt=>unistr('Descri\00E7\00E3o do tipo de  tarefa')
,p_placeholder=>unistr('Informe a descri\00E7\00E3o da atividade tarefa')
,p_source=>'DESCRICAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_cattributes_element=>'style="text-align: start;"'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(306464112839923826)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_help_text=>unistr('Descri\00E7\00E3o da atividade tarefa inclusa no banco de dados')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31489919983815326)
,p_name=>'P209_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(129189937799822342582)
,p_item_source_plug_id=>wwv_flow_imp.id(129189937799822342582)
,p_prompt=>'Status'
,p_placeholder=>'Informe o status da atividade tarefa'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'STATIC:Ativado;1,Desativado;2'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cattributes_element=>'style="text-align: start;"'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(306464112839923826)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>'Status da atividade tarefa inclusa no banco de dados'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45017297227209692)
,p_name=>'P209_RESULT'
,p_item_sequence=>350
,p_display_as=>'NATIVE_HIDDEN'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45017648712211645)
,p_name=>'P209_MENSAGEM'
,p_item_sequence=>360
,p_display_as=>'NATIVE_HIDDEN'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(429418255014854190)
,p_name=>'P209_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(129189937799822342582)
,p_item_source_plug_id=>wwv_flow_imp.id(129189937799822342582)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15963227641949436)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15953907243949414)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15963769401949437)
,p_event_id=>wwv_flow_imp.id(15963227641949436)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15964176387949438)
,p_name=>'Load page'
,p_event_sequence=>80
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15964660382949439)
,p_event_id=>wwv_flow_imp.id(15964176387949438)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'selectItemList(''LIST_ABA'',apex.item( "P209_ABA" ).getValue())'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15959814654949429)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'UPDATE_ROW'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_SRV_TIPO_TAREFAS'
,p_attribute_04=>'UPDATE_ROW'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>15959814654949429
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15960358184949430)
,p_page_process_id=>wwv_flow_imp.id(15959814654949429)
,p_page_id=>209
,p_name=>'p_nome'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>160
,p_value_type=>'ITEM'
,p_value=>'P209_NOME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15960810710949431)
,p_page_process_id=>wwv_flow_imp.id(15959814654949429)
,p_page_id=>209
,p_name=>'p_descricao'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>170
,p_value_type=>'ITEM'
,p_value=>'P209_DESCRICAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15961393719949433)
,p_page_process_id=>wwv_flow_imp.id(15959814654949429)
,p_page_id=>209
,p_name=>'p_status'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>180
,p_value_type=>'ITEM'
,p_value=>'P209_STATUS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15961852205949434)
,p_page_process_id=>wwv_flow_imp.id(15959814654949429)
,p_page_id=>209
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P209_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15962393670949434)
,p_page_process_id=>wwv_flow_imp.id(15959814654949429)
,p_page_id=>209
,p_name=>'p_result'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>140
,p_value_type=>'ITEM'
,p_value=>'P209_RESULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15962848906949435)
,p_page_process_id=>wwv_flow_imp.id(15959814654949429)
,p_page_id=>209
,p_name=>'p_mensagem'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>150
,p_value_type=>'ITEM'
,p_value=>'P209_MENSAGEM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15958711786949426)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(129189937799822342582)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Incluir conte\00FAdo')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>15958711786949426
);
wwv_flow_imp.component_end;
end;
/
