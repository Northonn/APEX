prompt --application/pages/page_00199
begin
--   Manifest
--     PAGE: 00199
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>199
,p_name=>unistr('Tarefas Projetos - Lista usu\00E1rios')
,p_alias=>unistr('TAREFAS-PROJETOS-LISTA-USU\00C1RIOS')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Lista usu\00E1rios')
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_dialog_height=>'auto'
,p_dialog_width=>'50%'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'ANTHONI'
,p_last_upd_yyyymmddhh24miss=>'20240228115712'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54446631733149380)
,p_plug_name=>'Artefatos Grid'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark:t-Form--large'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ptu.ID,',
'       ptu.ID_PROJETO,',
'       ptu.ID_USUARIO,',
'       ptu.ID_TAREFA,',
'       u.NOME AS NOME_RESPONSAVEL,',
'       ''btn_avancado'' AS btn_avancado',
'  from SRV_PROJETOS_TAREFAS_USUARIOS ptu',
'  INNER JOIN mpd_usuario u ON ptu.ID_USUARIO = u.ID',
'  WHERE :P199ID_TAREFA = ID_TAREFA;',
'',
'',
'',
' '))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_attribute_02=>'NOME_RESPONSAVEL'
,p_attribute_08=>'ID_USUARIO'
,p_attribute_16=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::P200_ID:&ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15486309616762493)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(54446631733149380)
,p_button_name=>'Novo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_redirect_url=>'f?p=&APP_ID.:198:&SESSION.::&DEBUG.::P198_ID_PROJETO,P198_ID_TAREFA:&P199_ID_PROJETO.,&P199ID_TAREFA.'
,p_button_css_classes=>'u-pullRight'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15405541138520644)
,p_name=>'P199_ID_PROJETO'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15405674892520645)
,p_name=>'P199ID_TAREFA'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15865394448775002)
,p_name=>'onCloseNOVO'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15486309616762493)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15865896841775007)
,p_event_id=>wwv_flow_imp.id(15865394448775002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54446631733149380)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15865601258775005)
,p_name=>'onCloseTarefas_projetos Grid'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(54446631733149380)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15865760392775006)
,p_event_id=>wwv_flow_imp.id(15865601258775005)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54446631733149380)
);
wwv_flow_imp.component_end;
end;
/
