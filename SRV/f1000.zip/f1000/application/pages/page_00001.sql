prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'NG-SRV'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function notificacaoLidaJS(pID_NOTIFICAO) {    ',
'    apex.server.process ( "NOTIFICAO_LIDA",',
'    {f01:pID_NOTIFICAO},',
'    {',
'      ',
'',
'      success: function (data) {',
'            var region = apex.region("notification-menu");',
'            region.refresh();',
'            apex.message.clearErrors();',
unistr('            //apex.message.showPageSuccess("Publica\00E7\00E3o realizada com sucesso!");'),
'        },',
'        error: function (jqXHR, textStatus, errorThrown) {',
'            apex.message.clearErrors();',
'',
'            apex.message.showErrors([',
'                {',
'                    type: apex.message.TYPE.ERROR,',
'                    location: ["page"],',
unistr('                    message: "Erro ao marcar notifica\00E7\00E3o como lida: " + errorThrown,'),
'                    unsafe: false',
'                }',
'            ]);',
'        }  ',
'    }',
'  );',
'}',
'',
'function notificacaoExcluirJS(pID_NOTIFICAO) {',
'    apex.server.process ( "NOTIFICAO_EXCLUIR",',
'    {f01:pID_NOTIFICAO},',
'    {',
'      success: function (data) {',
'            var region = apex.region("notification-menu");',
'            region.refresh();',
'            apex.message.clearErrors();',
unistr('            //apex.message.showPageSuccess("Publica\00E7\00E3o realizada com sucesso!");'),
'        },',
'        error: function (jqXHR, textStatus, errorThrown) {',
'            apex.message.clearErrors();',
'',
'            apex.message.showErrors([',
'                {',
'                    type: apex.message.TYPE.ERROR,',
'                    location: ["page"],',
unistr('                    message: "Erro ao excluir notifica\00E7\00E3o: " + errorThrown,'),
'                    unsafe: false',
'                }',
'            ]);',
'        }  ',
'    }',
'  );',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(174693463219426295)
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240227111316'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53959170431923305)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--4cols:t-Cards--hideBody:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_list_id=>wwv_flow_imp.id(177682434093405200)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(306442605139923810)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(306500340746923892)
,p_plug_name=>'SRV'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--iconsCircle'
,p_plug_template=>wwv_flow_imp.id(306403529652923783)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(275694287232595941)
,p_name=>unistr('Notifica\00E7\00F5es')
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(275694385722595942)
,p_event_id=>wwv_flow_imp.id(275694287232595941)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.NOTIFICATION'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "refresh": 0,',
'    "mainIcon": "fa-bell",',
'    "mainIconColor": "white",',
'    "mainIconBackgroundColor": "rgba(70,70,70,0.9)",',
'    "mainIconBlinking": false,',
'    "counterBackgroundColor": "rgb(232, 55, 55 )",',
'    "counterFontColor": "white",',
'    "linkTargetBlank": false,',
'    "showAlways": false,',
'    "browserNotifications": {',
'        "enabled": true,',
'        "cutBodyTextAfter": 100,',
'        "link": false',
'    },',
'    "accept": {',
'        "color": "#44e55c",',
'        "icon": "fa-check"',
'    },',
'    "decline": {',
'        "color": "#b73a21",',
'        "icon": "fa-close"',
'    },',
'    "hideOnRefresh": true',
'}'))
,p_attribute_02=>'notification-menu'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''fa-tasks'' AS NOTE_ICON, ',
'    ''var(--a-palette-success)'' AS NOTE_ICON_COLOR,     ',
unistr('    ''Movimenta\00E7\00E3o no chamado'' AS NOTE_HEADER,'),
'    CASE WHEN SUBSTR(A.DESCRICAO, 23) = C.NOME||'' ''||C.SOBRENOME THEN',
unistr('    ''Voc\00EA foi direcionado como analista no chamado ''||A.ID_CHAMADO'),
'    WHEN SUBSTR(A.DESCRICAO, 24) = C.NOME||'' ''||C.SOBRENOME THEN',
unistr('    ''Voc\00EA foi direcionado como atendente no chamado ''||A.ID_CHAMADO   '),
'    WHEN A.DESCRICAO LIKE ''CHAMADO CANCELADO%'' THEN',
'    ''Chamado ''||A.ID_CHAMADO||'' cancelado''     ',
'    END AS NOTE_TEXT, ',
'    APEX_UTIL.PREPARE_URL(',
'          p_url => ''f?p='' || :APP_ALIAS || '':178:'' || :APP_SESSION ||''::NO::P178_ID:'' || A.ID,',
'          p_checksum_type => ''SESSION'', p_triggering_element => ''apex.jQuery(''''#notification-menu'''')'') AS NOTE_LINK, ',
'    ''var(--a-palette-success)'' AS NOTE_COLOR,',
'    ''javascript:notificacaoLidaJS(''||A.id||'');'' AS NOTE_ACCEPT,',
'    ''javascript:notificacaoExcluirJS(''||A.id||'');'' AS NOTE_DECLINE,',
'    0 AS NO_BROWSER_NOTIFICATION',
'FROM',
'    ADM_CHAMADO_MOVIMENTACAO A',
'    JOIN ADM_CHAMADO B ON B.ID = A.ID_CHAMADO ',
'    JOIN ADM_USUARIO C ON C.ID = B.ID_ANALISTA OR C.ID = B.ID_ATENDENTE',
'WHERE ',
'NVL(A.NOTIFICACAO,''N'') = ''N''',
'AND',
'(UPPER( SUBSTR(A.DESCRICAO, 23)) IN (SELECT UPPER(NOME||'' ''||SOBRENOME) FROM ADM_USUARIO WHERE UPPER(USERNAME) = UPPER(V(''APP_USER'')))',
'OR ',
'UPPER( SUBSTR(A.DESCRICAO, 24)) IN (SELECT UPPER(NOME||'' ''||SOBRENOME) FROM ADM_USUARIO WHERE UPPER(USERNAME) = UPPER(V(''APP_USER'')))',
'OR',
'A.DESCRICAO IN (SELECT A.DESCRICAO FROM ADM_CHAMADO_MOVIMENTACAO A',
'JOIN ADM_CHAMADO B ON B.ID = A.ID_CHAMADO',
'JOIN ADM_USUARIO C ON C.ID = B.ID_ANALISTA OR C.ID = B.ID_ATENDENTE ',
'WHERE UPPER(C.USERNAME) = UPPER(V(''APP_USER'')) ',
'AND A.DESCRICAO LIKE ''CHAMADO CANCELADO%'')',
')',
'AND (A.DESCRICAO LIKE ''Direcionado%'' OR A.DESCRICAO LIKE ''CHAMADO CANCELADO%'')',
'ORDER BY A.ID_CHAMADO',
''))
,p_attribute_05=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(275694416572595943)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'NOTIFICAO_LIDA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'      ',
'      update ADM_CHAMADO_MOVIMENTACAO',
'         set NOTIFICACAO = ''S''',
'       where id = to_number(apex_application.g_f01(1));',
'',
'    htp.prn(''{"result":"success"}'');',
'',
'    apex_json.open_object;  ',
'    apex_json.write(''success'', true);  ',
'    apex_json.close_object;',
'',
'exception',
'  when OTHERS then',
'    apex_json.open_object;',
'    apex_json.write(''success'', false);',
'    apex_json.write(''message'', sqlerrm);',
'    apex_json.close_object;',
'    htp.prn(''{"result":"ERROR"}'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>101025071034240825
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(275694569446595944)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'NOTIFICAO_EXCLUIR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'      ',
'      update ADM_CHAMADO_MOVIMENTACAO',
'         set NOTIFICACAO = ''S''',
'       where id = to_number(apex_application.g_f01(1));',
'',
'    htp.prn(''{"result":"success"}'');',
'',
'    apex_json.open_object;  ',
'    apex_json.write(''success'', true);  ',
'    apex_json.close_object;',
'',
'exception',
'  when OTHERS then',
'    apex_json.open_object;',
'    apex_json.write(''success'', false);',
'    apex_json.write(''message'', sqlerrm);',
'    apex_json.close_object;',
'    htp.prn(''{"result":"ERROR"}'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>101025223908240826
);
wwv_flow_imp.component_end;
end;
/
