prompt --application/pages/page_00149
begin
--   Manifest
--     PAGE: 00149
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>149
,p_name=>'Artefatos'
,p_alias=>'ARTEFATOS'
,p_step_title=>'Artefatos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$("h1").append($("#icon_info"));'
,p_step_template=>wwv_flow_imp.id(306300532099923727)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240412201014'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11777016206310805)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11777701109310815)
,p_plug_name=>'Lista grade'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'   ar.id,',
'   ar.id_tenant,',
'   ar.id_aplicacao,',
'   ar.titulo_artefato,',
'   ar.descricao_artefato,',
'   ar.ajuda,',
'   ar.codigo_artefato,',
'   ar.linguagem,',
'   ar.tipo_artefato,',
'   ar.id_analista,',
'   ar.id_desenvolvedor,',
'   ap.nome_aplicacao,',
'    pkg_componentes.html_card_colunas(',
'        ''srv_artefato.tipo_artefato_l'',',
'        pkg_util.dominio_retorna_tag(''srv_artefato'',''tipo_artefato'',tipo_artefato)',
'    ) as atributo1,',
'    pkg_componentes.html_card_colunas(',
'        ''srv_artefato.linguagem_l'',',
'        pkg_util.dominio_retorna_tag(''srv_artefato'',''linguagem'',linguagem)',
'    ) as atributo2,',
'    pkg_componentes.html_card_colunas(',
'        ''srv_artefato.id_aplicacao_l'',',
'        ap.nome_aplicacao',
'    ) as atributo3',
'from srv_artefato ar',
'left join srv_aplicacao ap on id_aplicacao = ap.id',
'order by codigo_artefato;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(11779806370310828)
,p_region_id=>wwv_flow_imp.id(11777701109310815)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITULO_ARTEFATO'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DESCRICAO_ARTEFATO'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.',
'    &ATRIBUTO3!RAW.',
'</div>',
'',
'',
'',
'',
'',
'',
'',
''))
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'CODIGO_ARTEFATO'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(11789304961382105)
,p_card_id=>wwv_flow_imp.id(11779806370310828)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:150:&SESSION.::&DEBUG.:150:P150_ID,P150_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(11789428056382106)
,p_card_id=>wwv_flow_imp.id(11779806370310828)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.::P151_ID,P151_ID_TENANT:&ID.,&ID_TENANT.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(78689915900497950)
,p_card_id=>wwv_flow_imp.id(11779806370310828)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_ID,P9000_PAGINA:&ID.,149'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11777892971310815)
,p_plug_name=>'Pesquisa grade'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-left-sm'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(11777701109310815)
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11789521642382107)
,p_plug_name=>'Lista linha'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'   ar.id,',
'   ar.id_tenant,',
'   ar.id_aplicacao,',
'   ar.titulo_artefato,',
'   ar.descricao_artefato,',
'   ar.ajuda,',
'   ar.codigo_artefato,',
'   ar.linguagem,',
'   ar.tipo_artefato,',
'   ar.id_analista,',
'   ar.id_desenvolvedor,',
'   ap.nome_aplicacao,',
'    pkg_componentes.html_card_colunas(',
'        ''srv_artefato.tipo_artefato_l'',',
'        pkg_util.dominio_retorna_tag(''srv_artefato'',''tipo_artefato'',tipo_artefato)',
'    ) as atributo1,',
'    pkg_componentes.html_card_colunas(',
'        ''srv_artefato.linguagem_l'',',
'        pkg_util.dominio_retorna_tag(''srv_artefato'',''linguagem'',linguagem)',
'    ) as atributo2,',
'    pkg_componentes.html_card_colunas(',
'        ''srv_artefato.id_aplicacao_l'',',
'        ap.nome_aplicacao',
'    ) as atributo3',
'from srv_artefato ar',
'left join srv_aplicacao ap on id_aplicacao = ap.id',
'order by codigo_artefato;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(11789605038382108)
,p_region_id=>wwv_flow_imp.id(11789521642382107)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITULO_ARTEFATO'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.',
'    &ATRIBUTO3!RAW.',
'</div>'))
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'CODIGO_ARTEFATO'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(11789793684382109)
,p_card_id=>wwv_flow_imp.id(11789605038382108)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:150:&SESSION.::&DEBUG.:150:P150_ID,P150_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(11789810218382110)
,p_card_id=>wwv_flow_imp.id(11789605038382108)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.::P151_ID,P151_ID_TENANT:&ID.,&ID_TENANT.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16814860590112406)
,p_plug_name=>'Search linha'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-left-sm'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(11789521642382107)
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79870944174626628)
,p_plug_name=>'Button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79871055880626629)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(79870944174626628)
,p_button_name=>'EscondePesquisa'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_ESCONDE_FILTRO'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-filter-list-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79871108971626630)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(79870944174626628)
,p_button_name=>'MostraPesquisa'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_MOSTRA_FILTRO'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-filter-list-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79871217863626631)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(79870944174626628)
,p_button_name=>'MostraLinhas'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_MOSTRA_LINHA'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-card-line-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79871346369626632)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(79870944174626628)
,p_button_name=>'MostraGrid'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_MOSTRA_GRADE'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-card-grid-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79871459836626633)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(79870944174626628)
,p_button_name=>'Novo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:150:&SESSION.::&DEBUG.:150::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11778378305310819)
,p_name=>'P149_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11777892971310815)
,p_placeholder=>'Pesquise por srv_artefato.codigo_artefato_l ou srv_artefato.titulo_artefato_l'
,p_source=>'TITULO_ARTEFATO,CODIGO_ARTEFATO,DESCRICAO_ARTEFATO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11788933198382101)
,p_name=>'P149_LINGUAGEM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(11777892971310815)
,p_prompt=>'srv_artefato.linguagem_l'
,p_source=>'LINGUAGEM'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_SRV_ARTEFATO.LINGUAGEM'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''srv_artefato'',''linguagem'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11789099914382102)
,p_name=>'P149_TIPO_ARTEFATO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11777892971310815)
,p_prompt=>'srv_artefato.tipo_artefato_l'
,p_source=>'TIPO_ARTEFATO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_SRV_ARTEFATO.TIPO_ARTEFATO'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''srv_artefato'',''tipo_artefato'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11789134420382103)
,p_name=>'P149_ANALISTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(11777892971310815)
,p_prompt=>'srv_artefato.id_analista_l'
,p_source=>'ID_ANALISTA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT U.NOME d, A.ID_ANALISTA r FROM SRV_ARTEFATO A JOIN MPD_USUARIO U ON A.ID_ANALISTA = U.ID',
''))
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>true
,p_fc_initial_toggled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11789234636382104)
,p_name=>'P149_DESENVOLVEDOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(11777892971310815)
,p_prompt=>'srv_artefato.id_desenvolvedor_l'
,p_source=>'ID_DESENVOLVEDOR'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'SELECT DISTINCT U.NOME d, A.ID_DESENVOLVEDOR r FROM SRV_ARTEFATO A JOIN MPD_USUARIO U ON A.ID_DESENVOLVEDOR= U.ID'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>true
,p_fc_initial_toggled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16814924446112407)
,p_name=>'P149_SEARCH_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16814860590112406)
,p_placeholder=>'Pesquise por srv_artefato.codigo_artefato_l ou srv_artefato.titulo_artefato_l'
,p_source=>'TITULO_ARTEFATO,DESCRICAO_ARTEFATO,DESCRICAO_ARTEFATO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16815057790112408)
,p_name=>'P149_APLICACAO_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(16814860590112406)
,p_prompt=>unistr('Aplica\00E7\00E3o')
,p_source=>'ID_APLICACAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOME_APLICACAO d, id r ',
'FROM SRV_APLICACAO'))
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16815115414112409)
,p_name=>'P149_LINGUAGEM_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(16814860590112406)
,p_prompt=>'Linguagem'
,p_source=>'LINGUAGEM'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'CASE',
'    WHEN LINGUAGEM = ''PL'' THEN ''PL/SQL''',
'    WHEN LINGUAGEM = ''AP'' THEN ''APEX''',
'    WHEN LINGUAGEM = ''JS'' THEN ''Java Script''',
'    WHEN LINGUAGEM = ''JA'' THEN ''Java''',
'    WHEN LINGUAGEM = ''PY'' THEN ''Phyton''',
'END AS "DS_LINGUAGEM_d",',
'    LINGUAGEM AS "R"',
'FROM SRV_ARTEFATO;'))
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16815289955112410)
,p_name=>'P149_TIPO_ARTEFATO_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(16814860590112406)
,p_prompt=>'Tipo de artefato'
,p_source=>'TIPO_ARTEFATO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT ',
'    CASE',
'        WHEN TIPO_ARTEFATO = ''TE'' THEN ''Tela''',
'        WHEN TIPO_ARTEFATO = ''TA'' THEN ''Tabela''',
unistr('        WHEN TIPO_ARTEFATO = ''FU'' THEN ''Fun\00E7\00E3o'''),
'        WHEN TIPO_ARTEFATO = ''PR'' THEN ''Procedure''',
unistr('        WHEN TIPO_ARTEFATO = ''AP'' THEN ''Aplica\00E7\00E3o'''),
unistr('        WHEN TIPO_ARTEFATO = ''OB'' THEN ''Objeto de neg\00F3cio'''),
'        WHEN TIPO_ARTEFATO = ''PA'' THEN ''Pacote''',
'        ELSE ''Invalido''',
'    END AS "DS_TIPO_ARTEFATO_d",',
'    TIPO_ARTEFATO AS "R"',
'FROM SRV_ARTEFATO;',
''))
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16815303074112411)
,p_name=>'P149_ANALISTA_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(16814860590112406)
,p_prompt=>'Analista'
,p_source=>'ID_ANALISTA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT U.NOME d, A.ID_ANALISTA r FROM SRV_ARTEFATO A JOIN MPD_USUARIO U ON A.ID_ANALISTA = U.ID',
''))
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>true
,p_fc_initial_toggled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16815458963112412)
,p_name=>'P149_DESENVOLVEDOR_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(16814860590112406)
,p_prompt=>'Desenvolvedor'
,p_source=>'ID_ANALISTA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'SELECT DISTINCT U.NOME d, A.ID_DESENVOLVEDOR r FROM SRV_ARTEFATO A JOIN MPD_USUARIO U ON A.ID_DESENVOLVEDOR= U.ID'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>true
,p_fc_initial_toggled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79873159542626650)
,p_name=>'P149_APLICACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(11777892971310815)
,p_prompt=>'srv_artefato.id_aplicacao_l'
,p_source=>'ID_APLICACAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOME_APLICACAO d, id r ',
'FROM SRV_APLICACAO'))
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79871504797626634)
,p_name=>'onClickEscondePesquisa'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(79871055880626629)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79871600965626635)
,p_event_id=>wwv_flow_imp.id(79871504797626634)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). hide();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79871752832626636)
,p_event_id=>wwv_flow_imp.id(79871504797626634)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(79871108971626630)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79871835716626637)
,p_event_id=>wwv_flow_imp.id(79871504797626634)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(79871055880626629)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79871910939626638)
,p_name=>'onClickMostraPesquisa'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(79871108971626630)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79872018528626639)
,p_event_id=>wwv_flow_imp.id(79871910939626638)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). show();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79872159030626640)
,p_event_id=>wwv_flow_imp.id(79871910939626638)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(79871055880626629)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79872213743626641)
,p_event_id=>wwv_flow_imp.id(79871910939626638)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(79871108971626630)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79872350848626642)
,p_name=>'onClickMostraLinhas'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(79871217863626631)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79872517442626644)
,p_event_id=>wwv_flow_imp.id(79872350848626642)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(79871346369626632)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11789911134382111)
,p_event_id=>wwv_flow_imp.id(79872350848626642)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11789521642382107)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16816173114112419)
,p_event_id=>wwv_flow_imp.id(79872350848626642)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16814860590112406)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79872633310626645)
,p_event_id=>wwv_flow_imp.id(79872350848626642)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(79871217863626631)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11790063581382112)
,p_event_id=>wwv_flow_imp.id(79872350848626642)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11777701109310815)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16816296218112420)
,p_event_id=>wwv_flow_imp.id(79872350848626642)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11777892971310815)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79872781071626646)
,p_name=>'onClickMostraGrid'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(79871346369626632)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79872940701626648)
,p_event_id=>wwv_flow_imp.id(79872781071626646)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(79871217863626631)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11790117952382113)
,p_event_id=>wwv_flow_imp.id(79872781071626646)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11777701109310815)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16816313308112421)
,p_event_id=>wwv_flow_imp.id(79872781071626646)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11777892971310815)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79873083320626649)
,p_event_id=>wwv_flow_imp.id(79872781071626646)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(79871346369626632)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11790225381382114)
,p_event_id=>wwv_flow_imp.id(79872781071626646)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11789521642382107)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16816409127112422)
,p_event_id=>wwv_flow_imp.id(79872781071626646)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16814860590112406)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53959423210923308)
,p_name=>'onCloseArtefatoGrid'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(11777701109310815)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53959542679923309)
,p_event_id=>wwv_flow_imp.id(53959423210923308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11777701109310815)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54495464664014542)
,p_event_id=>wwv_flow_imp.id(53959423210923308)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11789521642382107)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54495592560014543)
,p_event_id=>wwv_flow_imp.id(53959423210923308)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11777892971310815)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54495607777014544)
,p_event_id=>wwv_flow_imp.id(53959423210923308)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16814860590112406)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53959672975923310)
,p_name=>'onCloseArtefatoRow'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(11789521642382107)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54495788798014545)
,p_event_id=>wwv_flow_imp.id(53959672975923310)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11777701109310815)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54495807739014546)
,p_event_id=>wwv_flow_imp.id(53959672975923310)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11777892971310815)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54495954863014547)
,p_event_id=>wwv_flow_imp.id(53959672975923310)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16814860590112406)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53959773937923311)
,p_event_id=>wwv_flow_imp.id(53959672975923310)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11789521642382107)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53959829291923312)
,p_name=>'onCloseNovo'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(79871459836626633)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53959903817923313)
,p_event_id=>wwv_flow_imp.id(53959829291923312)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11777701109310815)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53960026201923314)
,p_event_id=>wwv_flow_imp.id(53959829291923312)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11789521642382107)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54496011306014548)
,p_event_id=>wwv_flow_imp.id(53959829291923312)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16814860590112406)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54496177356014549)
,p_event_id=>wwv_flow_imp.id(53959829291923312)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11777892971310815)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(65734088714180094)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>80
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(65734424102180096)
,p_event_id=>wwv_flow_imp.id(65734088714180094)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp.component_end;
end;
/
