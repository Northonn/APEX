prompt --application/pages/page_00186
begin
--   Manifest
--     PAGE: 00186
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>186
,p_name=>'Projetos'
,p_alias=>'PROJETOS'
,p_step_title=>'Projetos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$("h1").append($("#icon_info"));'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-actions{',
'    display: none;',
'}',
'',
'.a-CardView-header{',
'    background-color: aliceblue;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'}',
'',
'.t-ButtonRegion-buttons',
'{',
' display: flex;',
' justify-content: flex-end;',
' align-items: center;',
'}',
'',
'.t-Region',
'{',
'    border: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(306300532099923727)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'ANTHONI'
,p_last_upd_yyyymmddhh24miss=>'20240304172228'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26997178068062387)
,p_plug_name=>'Entidades'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38968004619386912)
,p_plug_name=>'Projetos Grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select ID,',
'       ID_OS,',
'       ID_RESPONSAVEL,',
'       NOME_PROJETO,',
'       DESCRICAO,',
'       DATA_INICIO,',
'       DATA_TERMINO,',
'       TOTAL_HORAS,',
'       SITUACAO,',
'       ID_USUARIO_INCLUIU,',
'       DATA_INCLUSAO,',
'       ID_USUARIO_ALTEROU,',
'       DATA_ALTERACAO,',
'       pkg_util.dominio_retorna_tag(''SRV_PROJETO'',''SITUACAO'',SITUACAO) AS DS_SITUACAO,',
'        pkg_componentes.html_card_colunas(',
'            ''SRV_PROJETOS.DESCRICAO_l'',',
'            DESCRICAO',
'        ) as atributo1,',
'        pkg_componentes.html_card_colunas(',
'            ''SRV_PROJETOS.DATA_INICIO_l'',',
'            DATA_INICIO',
'        ) as atributo2,',
'        pkg_componentes.html_card_colunas(',
'            ''SRV_PROJETOS.DATA_TERMINO_l'',',
'            DATA_TERMINO',
'        ) as atributo3,',
'        pkg_componentes.html_card_colunas(',
'            ''SRV_PROJETOS.DS_SITUACAO_l'',',
'            SITUACAO',
'        ) as atributo4',
'  from SRV_PROJETOS'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(14946501358221615)
,p_region_id=>wwv_flow_imp.id(38968004619386912)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME_PROJETO'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.',
'    &ATRIBUTO3!RAW.',
'    &ATRIBUTO4!RAW.',
'</div>',
''))
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'NOME_PROJETO'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(14947023199221619)
,p_card_id=>wwv_flow_imp.id(14946501358221615)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:189:&SESSION.::&DEBUG.:189:P189_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(14947653158221621)
,p_card_id=>wwv_flow_imp.id(14946501358221615)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:188:&SESSION.::&DEBUG.::P188_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38968196481386912)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-sm:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(38968004619386912)
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38979825152458204)
,p_plug_name=>'Projetos Row'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       ID_OS,',
'       ID_RESPONSAVEL,',
'       NOME_PROJETO,',
'       DESCRICAO,',
'       DATA_INICIO,',
'       DATA_TERMINO,',
'       TOTAL_HORAS,',
'       SITUACAO,',
'       ID_USUARIO_INCLUIU,',
'       DATA_INCLUSAO,',
'       ID_USUARIO_ALTEROU,',
'       DATA_ALTERACAO,',
'       pkg_util.dominio_retorna_tag(''SRV_PROJETO'',''SITUACAO'',SITUACAO) AS DS_SITUACAO',
'  from SRV_PROJETOS'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(14950505506221632)
,p_region_id=>wwv_flow_imp.id(38979825152458204)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME_PROJETO'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row">',
'    <div class="col col-5 padding-left-md padding-top-md">',
'        <div class="a-CardView-headerBody">',
unistr('            <div class="ng-estilo-titulo-mi">Descri\00E7\00E3o</div>'),
'            <div class="row">',
'                <div class="col col-12 apex-col-auto col-start">',
'                    <h5 class="margin-top-none">&DESCRICAO.</h5>',
'                </div>',
'            </div>',
'        </div>',
'    </div>  ',
'',
'    <div class="col col-2 padding-left-md padding-top-md">',
'        <div class="a-CardView-headerBody">',
unistr('            <div class="ng-estilo-titulo-mi">Data de in\00EDcio</div>'),
'            <div class="row">',
'                <div class="col col-12 apex-col-auto col-start">',
'                    <h5 class="margin-top-none">&DATA_INICIO.</h5>',
'                </div>',
'            </div>',
'        </div>',
'    </div>  ',
'',
'    <div class="col col-2 padding-left-md padding-top-md">',
'        <div class="a-CardView-headerBody">',
'            <div class="ng-estilo-titulo-mi">Data Final</div>',
'            <div class="row">',
'                <div class="col col-12 apex-col-auto col-start">',
'                    <h5 class="margin-top-none">&DATA_TERMINO.</h5>',
'                </div>',
'            </div>',
'        </div>',
'    </div>  ',
'    <div class="col col-2 padding-left-md padding-top-md">',
'        <div class="a-CardView-headerBody">',
unistr('            <div class="ng-estilo-titulo-mi">Situa\00E7\00E3o</div>'),
'            <div class="row">',
'                <div class="col col-12 apex-col-auto col-start">',
'                    <h5 class="margin-top-none">&DS_SITUACAO.</h5>',
'                </div>',
'            </div>',
'        </div>',
'    </div> ',
'</div>'))
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'NOME_PROJETO'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(14951012116221633)
,p_card_id=>wwv_flow_imp.id(14950505506221632)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:189:&SESSION.::&DEBUG.::P189_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(14951676806221635)
,p_card_id=>wwv_flow_imp.id(14950505506221632)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:188:&SESSION.::&DEBUG.::P188_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54494594641014533)
,p_plug_name=>'Search row'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-sm:margin-left-md'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(38979825152458204)
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107061247684702725)
,p_plug_name=>'Button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14953000866221638)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(107061247684702725)
,p_button_name=>'SHOW_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Esconder filtro'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter '
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14953469558221639)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(107061247684702725)
,p_button_name=>'HIDE_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Mostrar filtro'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter fam-x fam-is-danger'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14953846500221640)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(107061247684702725)
,p_button_name=>'SHOW_ROW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Visualizar em linhas'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-media-list'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14954236397221640)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(107061247684702725)
,p_button_name=>'SHOW_GRID'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'Visualizar em grade'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-cards'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14954644239221641)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(107061247684702725)
,p_button_name=>'Novo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:187:&SESSION.::&DEBUG.:139::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27836525606605330)
,p_name=>'P186_FIL_SITUACAO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(38968196481386912)
,p_prompt=>'SRV_PROJETOS.SITUACAO_L'
,p_source=>'SITUACAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Aberto;1,Pausado;2,Concluido;3,Cancelado;4,Atrasado;5'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38977639381386968)
,p_name=>'P186_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38968196481386912)
,p_prompt=>'Pesquise por SRV_PROJETOS.NOME_PROJETO_L ou SRV_PROJETOS.DESCRICAO_L '
,p_placeholder=>unistr('Pesquise por nome ou c\00F3digo')
,p_source=>'NOME_PROJETO, id'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54494681471014534)
,p_name=>'P186_SEARCH_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(54494594641014533)
,p_prompt=>'Pesquise por SRV_PROJETOS.NOME_PROJETO_L ou SRV_PROJETOS.DESCRICAO_L '
,p_placeholder=>unistr('Pesquise por nome ou c\00F3digo')
,p_source=>'NOME_PROJETO, id'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54494735319014535)
,p_name=>'P186_FIL_SITUACAO_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54494594641014533)
,p_prompt=>'SRV_PROJETOS.SITUACAO_L'
,p_source=>'SITUACAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Aberto;1,Pausado;2,Concluido;3,Cancelado;4,Atrasado;5'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14957344352221655)
,p_name=>'onClickEscondePesquisa'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(14953000866221638)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14957833749221656)
,p_event_id=>wwv_flow_imp.id(14957344352221655)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). hide();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14958398665221657)
,p_event_id=>wwv_flow_imp.id(14957344352221655)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(14953469558221639)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14958865251221658)
,p_event_id=>wwv_flow_imp.id(14957344352221655)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(14953000866221638)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14959238729221659)
,p_name=>'onClickMostraPesquisa'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(14953469558221639)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14959767884221660)
,p_event_id=>wwv_flow_imp.id(14959238729221659)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). show();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14960240102221661)
,p_event_id=>wwv_flow_imp.id(14959238729221659)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(14953000866221638)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14960794415221662)
,p_event_id=>wwv_flow_imp.id(14959238729221659)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(14953469558221639)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14961133009221663)
,p_name=>'onClickMostraLinhas'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(14953846500221640)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14961675854221664)
,p_event_id=>wwv_flow_imp.id(14961133009221663)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(14954236397221640)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14962157960221665)
,p_event_id=>wwv_flow_imp.id(14961133009221663)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(14953846500221640)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14962674173221666)
,p_event_id=>wwv_flow_imp.id(14961133009221663)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38979825152458204)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54495083410014538)
,p_event_id=>wwv_flow_imp.id(14961133009221663)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54494594641014533)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14963121044221667)
,p_event_id=>wwv_flow_imp.id(14961133009221663)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38968004619386912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54495120883014539)
,p_event_id=>wwv_flow_imp.id(14961133009221663)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38968196481386912)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14963566663221669)
,p_name=>'onClickMostraGrid'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(14954236397221640)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14964053408221670)
,p_event_id=>wwv_flow_imp.id(14963566663221669)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(14953846500221640)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14965096078221672)
,p_event_id=>wwv_flow_imp.id(14963566663221669)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38968004619386912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54495262021014540)
,p_event_id=>wwv_flow_imp.id(14963566663221669)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38968196481386912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14964541780221671)
,p_event_id=>wwv_flow_imp.id(14963566663221669)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(14954236397221640)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54495317032014541)
,p_event_id=>wwv_flow_imp.id(14963566663221669)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54494594641014533)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14965588452221673)
,p_event_id=>wwv_flow_imp.id(14963566663221669)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38979825152458204)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14956497387221653)
,p_name=>'onCloseProjetosGrid'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(38968004619386912)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14956970340221654)
,p_event_id=>wwv_flow_imp.id(14956497387221653)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38968004619386912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54520741048090901)
,p_event_id=>wwv_flow_imp.id(14956497387221653)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38979825152458204)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54520875462090902)
,p_event_id=>wwv_flow_imp.id(14956497387221653)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38968196481386912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54520936548090903)
,p_event_id=>wwv_flow_imp.id(14956497387221653)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54494594641014533)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54521021880090904)
,p_name=>'onCloseProjetosRow'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(38979825152458204)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54521166673090905)
,p_event_id=>wwv_flow_imp.id(54521021880090904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38968004619386912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54521225738090906)
,p_event_id=>wwv_flow_imp.id(54521021880090904)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38979825152458204)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54521366605090907)
,p_event_id=>wwv_flow_imp.id(54521021880090904)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38968196481386912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54521408714090908)
,p_event_id=>wwv_flow_imp.id(54521021880090904)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54494594641014533)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54494022095014528)
,p_name=>'onCloseNovo'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(14954644239221641)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54494110346014529)
,p_event_id=>wwv_flow_imp.id(54494022095014528)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38968004619386912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54494355246014531)
,p_event_id=>wwv_flow_imp.id(54494022095014528)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38979825152458204)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54494408402014532)
,p_event_id=>wwv_flow_imp.id(54494022095014528)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38968196481386912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54496279224014550)
,p_event_id=>wwv_flow_imp.id(54494022095014528)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54494594641014533)
);
wwv_flow_imp.component_end;
end;
/
