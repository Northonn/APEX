prompt --application/pages/page_00160
begin
--   Manifest
--     PAGE: 00160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>160
,p_name=>'Mensagens - Tela Principal'
,p_alias=>'MENSAGENS-TELA-PRINCIPAL'
,p_step_title=>'Mensagens'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("h1").append($("#icon_info"));',
''))
,p_step_template=>wwv_flow_imp.id(306300532099923727)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'22'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240408185631'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77182914442880705)
,p_plug_name=>'Pesquisa grade'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody:margin-left-sm'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(77183467928880710)
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77183467928880710)
,p_plug_name=>'Lista grade'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>29
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TO_CHAR(ID) AS CHAR_ID,',
'       ID_TENANT,',
'       TIPO_MENSAGEM,       ',
'       CODIGO_MENSAGEM,',
'       MENSAGEM,',
'       AJUDA,',
'       SITUACAO,',
'       CASE TIPO_MENSAGEM',
'            WHEN ''1'' THEN ''Erro'' ',
'            WHEN ''2'' THEN ''Alerta''',
unistr('            WHEN ''3'' THEN ''Informa\00E7\00E3o'''),
'            WHEN ''4'' THEN ''Questionamento''',
'       ELSE NULL END AS C_TIPO_MENSAGEM,',
'       CASE SITUACAO',
'            WHEN ''A'' THEN ''Ativatudo''',
'            WHEN ''D'' THEN ''Descontinuada''',
'       ELSE NULL END AS C_SITUACAO,',
'       PKG_COMPONENTES.html_card_colunas(',
'           ''srv_aplicacao_mensagem.mensagem'',',
'           MENSAGEM',
'       ) as atributo1,',
'       PKG_COMPONENTES.html_card_colunas(',
'           ''srv_aplicacao_mensagem.ajuda'',',
'           AJUDA',
'       ) as atributo2,',
'       PKG_COMPONENTES.html_card_colunas(',
'           ''srv_aplicacao_mensagem.tipo_mensagem'',',
'           pkg_util.dominio_retorna_tag(''srv_aplicacao_mensagem'',''tipo_mensagem'',tipo_mensagem)',
'       ) as atributo3,',
'       PKG_COMPONENTES.html_card_colunas(',
'           ''srv_aplicacao_mensagem.situacao'',           ',
'           pkg_util.dominio_retorna_tag(''srv_aplicacao_mensagem'',''situacao'',situacao)           ',
'       ) as atributo4         ',
'  from SRV_APLICACAO_MENSAGEM'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(77183548780880711)
,p_region_id=>wwv_flow_imp.id(77183467928880710)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CODIGO_MENSAGEM'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.    ',
'    &ATRIBUTO3!RAW.    ',
'    &ATRIBUTO4!RAW.    ',
'</div>'))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(77183696110880712)
,p_card_id=>wwv_flow_imp.id(77183548780880711)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:167:&SESSION.::&DEBUG.:167:P167_ID,P167_ID_TENANT:&ID.,&ID_TENANT.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(77183741116880713)
,p_card_id=>wwv_flow_imp.id(77183548780880711)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:163:&SESSION.::&DEBUG.:163:P163_ID,P163_ID_TENANT:&ID.,&ID_TENANT.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(79784180803757209)
,p_card_id=>wwv_flow_imp.id(77183548780880711)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_ID,P9000_PAGINA:&ID.,&APP_PAGE_ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(208163414163087930)
,p_plug_name=>'Pesquisa linha'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody:margin-left-sm'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(335165634706556174)
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(335165634706556174)
,p_plug_name=>'Lista linha'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TO_CHAR(ID) AS CHAR_ID,',
'       ID_TENANT,',
'       TIPO_MENSAGEM,       ',
'       CODIGO_MENSAGEM,',
'       MENSAGEM,',
'       AJUDA,',
'       SITUACAO,',
'       CASE TIPO_MENSAGEM',
'            WHEN ''1'' THEN ''Erro'' ',
'            WHEN ''2'' THEN ''Alerta''',
unistr('            WHEN ''3'' THEN ''Informa\00E7\00E3o'''),
'            WHEN ''4'' THEN ''Questionamento''',
'       ELSE NULL END AS C_TIPO_MENSAGEM,',
'       CASE SITUACAO',
'            WHEN ''A'' THEN ''Ativatudo''',
'            WHEN ''D'' THEN ''Descontinuada''',
'       ELSE NULL END AS C_SITUACAO,',
'       PKG_COMPONENTES.html_card_colunas(',
'           ''srv_aplicacao_mensagem.mensagem'',',
'           MENSAGEM',
'       ) as atributo1,',
'       PKG_COMPONENTES.html_card_colunas(',
'           ''srv_aplicacao_mensagem.ajuda'',',
'           AJUDA',
'       ) as atributo2,',
'       PKG_COMPONENTES.html_card_colunas(',
'           ''srv_aplicacao_mensagem.tipo_mensagem'',',
'           pkg_util.dominio_retorna_tag(''srv_aplicacao_mensagem'',''tipo_mensagem'',tipo_mensagem)',
'       ) as atributo3,',
'       PKG_COMPONENTES.html_card_colunas(',
'           ''srv_aplicacao_mensagem.situacao'',           ',
'           pkg_util.dominio_retorna_tag(''srv_aplicacao_mensagem'',''situacao'',situacao)           ',
'       ) as atributo4         ',
'  from SRV_APLICACAO_MENSAGEM'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(77688740419208812)
,p_region_id=>wwv_flow_imp.id(335165634706556174)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'CODIGO_MENSAGEM'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.    ',
'    &ATRIBUTO3!RAW.    ',
'    &ATRIBUTO4!RAW.    ',
'</div>'))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(77689220909208814)
,p_card_id=>wwv_flow_imp.id(77688740419208812)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:167:&SESSION.::&DEBUG.:167:P167_ID,P167_ID_TENANT:&ID.,&ID_TENANT.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(77689884613208815)
,p_card_id=>wwv_flow_imp.id(77688740419208812)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>50
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:163:&SESSION.::&DEBUG.:163:P163_ID,P163_ID_TENANT:&ID.,&ID_TENANT.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78225204357254021557)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80924791739076361783)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76960532530828439)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(78225204357254021557)
,p_button_name=>'EscondePesquisa'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_ESCONDE_FILTRO'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-filter-list-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76961026399828444)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(78225204357254021557)
,p_button_name=>'MostraPesquisa'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_MOSTRA_FILTRO'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-filter-list-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76961554426828449)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(78225204357254021557)
,p_button_name=>'MostraLinhas'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_MOSTRA_LINHA'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-card-line-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77182640256880702)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(78225204357254021557)
,p_button_name=>'MostraGrid'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_MOSTRA_GRADE'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa ico-card-grid-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77694756187208828)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(78225204357254021557)
,p_button_name=>'NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:161:&SESSION.::&DEBUG.:161::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(80928213239742738)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(78225204357254021557)
,p_button_name=>'TESTE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Testar mensagens'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:7643:&SESSION.::&DEBUG.:7643::'
,p_icon_css_classes=>'fa-flask'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77183029266880706)
,p_name=>'P160_PESQUISA_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(77182914442880705)
,p_prompt=>'Id, mensagem e ajuda'
,p_placeholder=>'Buscar por SRV_APLICACAO_MENSAGEM.ID, SRV_APLICACAO_MENSAGEM.MENSAGEM ou SRV_APLICACAO_MENSAGEM.AJUDA_L'
,p_source=>'CODIGO_MENSAGEM,MENSAGEM,AJUDA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77183173334880707)
,p_name=>'P160_TIPO_MENSAGEM_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(77182914442880705)
,p_prompt=>'SRV_APLICACAO_MENSAGEM.TIPO_MENSAGEM'
,p_source=>'TIPO_MENSAGEM'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_SRV_APLICACAO_MENSAGEM.TIPO_MENSAGEM'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''srv_aplicacao_mensagem'',''tipo_mensagem'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77183214928880708)
,p_name=>'P160_PESQUISA_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(77182914442880705)
,p_prompt=>'Id, mensagem e ajuda'
,p_placeholder=>'Buscar por SRV_APLICACAO_MENSAGEM.ID, SRV_APLICACAO_MENSAGEM.MENSAGEM ou SRV_APLICACAO_MENSAGEM.AJUDA_L'
,p_source=>'CODIGO_MENSAGEM,MENSAGEM,AJUDA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77183320889880709)
,p_name=>'P160_TIPO_MENSAGEM_2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(77182914442880705)
,p_prompt=>'SRV_APLICACAO_MENSAGEM.TIPO_MENSAGEM'
,p_source=>'TIPO_MENSAGEM'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_SRV_APLICACAO_MENSAGEM.TIPO_MENSAGEM'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''srv_aplicacao_mensagem'',''tipo_mensagem'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208171959375087960)
,p_name=>'P160_TIPO_MENSAGEM_'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(208163414163087930)
,p_prompt=>'SRV_APLICACAO_MENSAGEM.TIPO_MENSAGEM'
,p_source=>'TIPO_MENSAGEM'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_SRV_APLICACAO_MENSAGEM.TIPO_MENSAGEM'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''srv_aplicacao_mensagem'',''tipo_mensagem'')'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208172257126087963)
,p_name=>'P160_PESQUISA_'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(208163414163087930)
,p_prompt=>'Id, mensagem e ajuda'
,p_placeholder=>'Buscar por SRV_APLICACAO_MENSAGEM.ID, SRV_APLICACAO_MENSAGEM.MENSAGEM ou SRV_APLICACAO_MENSAGEM.AJUDA_L'
,p_source=>'CODIGO_MENSAGEM,MENSAGEM,AJUDA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77186988908880745)
,p_name=>'onClosedListaGrade'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(77183467928880710)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77187015658880746)
,p_event_id=>wwv_flow_imp.id(77186988908880745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77183467928880710)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77187144450880747)
,p_event_id=>wwv_flow_imp.id(77186988908880745)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(335165634706556174)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77187279912880748)
,p_event_id=>wwv_flow_imp.id(77186988908880745)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77182914442880705)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77187394264880749)
,p_event_id=>wwv_flow_imp.id(77186988908880745)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(208163414163087930)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77697433157208834)
,p_name=>'onClosedListaLinha'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(335165634706556174)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77697901187208835)
,p_event_id=>wwv_flow_imp.id(77697433157208834)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(335165634706556174)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77213955160050802)
,p_event_id=>wwv_flow_imp.id(77697433157208834)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77183467928880710)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77698461330208836)
,p_event_id=>wwv_flow_imp.id(77697433157208834)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(208163414163087930)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77214091288050803)
,p_event_id=>wwv_flow_imp.id(77697433157208834)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77182914442880705)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77698887315208837)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>110
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77699353825208838)
,p_event_id=>wwv_flow_imp.id(77698887315208837)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77715712479208871)
,p_name=>'onClosedNOVO'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(77694756187208828)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77716226998208872)
,p_event_id=>wwv_flow_imp.id(77715712479208871)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(335165634706556174)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77187423957880750)
,p_event_id=>wwv_flow_imp.id(77715712479208871)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77182914442880705)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77716798230208873)
,p_event_id=>wwv_flow_imp.id(77715712479208871)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(208163414163087930)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77213811398050801)
,p_event_id=>wwv_flow_imp.id(77715712479208871)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77182914442880705)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76960691235828440)
,p_name=>'onClickEscondePesquisa'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(76960532530828439)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76960776842828441)
,p_event_id=>wwv_flow_imp.id(76960691235828440)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). hide();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76960821936828442)
,p_event_id=>wwv_flow_imp.id(76960691235828440)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(76961026399828444)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76960939168828443)
,p_event_id=>wwv_flow_imp.id(76960691235828440)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(76960532530828439)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76961164963828445)
,p_name=>'onClickMostraPesquisa'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(76961026399828444)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76961201800828446)
,p_event_id=>wwv_flow_imp.id(76961164963828445)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). show();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76961322081828447)
,p_event_id=>wwv_flow_imp.id(76961164963828445)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(76960532530828439)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76961422874828448)
,p_event_id=>wwv_flow_imp.id(76961164963828445)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(76961026399828444)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76961695235828450)
,p_name=>'onClickMostraLinhas'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(76961554426828449)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77182526109880701)
,p_event_id=>wwv_flow_imp.id(76961695235828450)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(77182640256880702)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77182785242880703)
,p_event_id=>wwv_flow_imp.id(76961695235828450)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(335165634706556174)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77182892234880704)
,p_event_id=>wwv_flow_imp.id(76961695235828450)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(208163414163087930)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77183885352880714)
,p_event_id=>wwv_flow_imp.id(76961695235828450)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(76961554426828449)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77183954409880715)
,p_event_id=>wwv_flow_imp.id(76961695235828450)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77183467928880710)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77184045713880716)
,p_event_id=>wwv_flow_imp.id(76961695235828450)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77182914442880705)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77184190923880717)
,p_name=>'onClickMostraGrid'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(77182640256880702)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77184271790880718)
,p_event_id=>wwv_flow_imp.id(77184190923880717)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(76961554426828449)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77184330781880719)
,p_event_id=>wwv_flow_imp.id(77184190923880717)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77183467928880710)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77184446353880720)
,p_event_id=>wwv_flow_imp.id(77184190923880717)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77182914442880705)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77184546643880721)
,p_event_id=>wwv_flow_imp.id(77184190923880717)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(77182640256880702)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77184647677880722)
,p_event_id=>wwv_flow_imp.id(77184190923880717)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(335165634706556174)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77184767625880723)
,p_event_id=>wwv_flow_imp.id(77184190923880717)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(208163414163087930)
);
wwv_flow_imp.component_end;
end;
/
