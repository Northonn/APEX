prompt --application/pages/page_00117
begin
--   Manifest
--     PAGE: 00117
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>117
,p_name=>'Sistema - Sistemas'
,p_alias=>'SISTEMA-SISTEMAS'
,p_step_title=>'Sistemas'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("h1").append($("#icon_info"));',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'24'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240426182814'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(180778011098890233)
,p_plug_name=>'Pesquisa'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-sm'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>5
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(307780231642358477)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(307780231642358477)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    A.ID,',
'    A.ID_TENANT,',
'    A.CODIGO_SISTEMA,',
'    A.NOME_SISTEMA,',
'    ( select l1."SITUACAO" from "SRV_SISTEMA_VERSIONADO" l1 where l1."ID_SISTEMA" = A."ID" AND l1."SITUACAO" = ''S'') "ID_L$1",  ',
'    CASE ',
'        WHEN B.VERSAO IS NULL THEN ''N/A''        ',
'        ELSE B.VERSAO',
'    END AS VERSAO,',
'    pkg_util.dominio_retorna_tag(''srv_sistema_versionado'',''situacao'', situacao)  AS SITUACAO,',
'    A.ID_USUARIO_INCLUIU,',
'    A.DATA_INCLUSAO,',
'    A.ID_USUARIO_ALTEROU,',
'    A.DATA_ALTERACAO,',
'    PKG_COMPONENTES.html_card_colunas(',
'        ''srv_sistema.codigo_sistema'',',
'        A.CODIGO_SISTEMA',
'    ) as atributo1, ',
'    PKG_COMPONENTES.html_card_colunas(',
'        ''srv_sistema_versionado.situacao'',',
'         pkg_util.dominio_retorna_tag(''srv_sistema_versionado'',''situacao'', situacao)',
'    ) AS atributo2                ',
'FROM SRV_SISTEMA A',
'LEFT JOIN SRV_SISTEMA_VERSIONADO B ON',
'B.ID_SISTEMA = A.ID',
'WHERE b.data_inclusao = (select max(data_inclusao) from SRV_SISTEMA_VERSIONADO where id_sistema = a.id) OR b.situacao IS null',
'ORDER BY A.DATA_INCLUSAO DESC',
'',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(50299823434011104)
,p_region_id=>wwv_flow_imp.id(307780231642358477)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME_SISTEMA'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.    ',
'</div>'))
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'VERSAO'
,p_badge_label=>unistr('Vers\00E3o:')
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(50300941260011109)
,p_card_id=>wwv_flow_imp.id(50299823434011104)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.:119:P119_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(50300353209011106)
,p_card_id=>wwv_flow_imp.id(50299823434011104)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>50
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:118:&SESSION.::&DEBUG.:118:P118_ID,P118_ID_TENANT:&ID.,&ID_TENANT.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78197818954189823860)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80897406336012164086)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306381711276923773)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(306296793768923707)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(306468478539923831)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(50307715614011134)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(78197818954189823860)
,p_button_name=>'BTN_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:120::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79812092004511009)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(78197818954189823860)
,p_button_name=>'APAGAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'APAGAR'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:279:&SESSION.::&DEBUG.:279:P279_ID:89'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53238005703005934)
,p_name=>'P117_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(180778011098890233)
,p_prompt=>'Search'
,p_placeholder=>'Busca por SRV_SISTEMA.CODIGO_SISTEMA_L ou SRV_SISTEMA.NOME_SISTEMA_L'
,p_source=>'CODIGO_SISTEMA,NOME_SISTEMA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(50312024716011147)
,p_name=>'onDialogClosedRefreshLista'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(307780231642358477)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50312559428011148)
,p_event_id=>wwv_flow_imp.id(50312024716011147)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(307780231642358477)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50313054010011149)
,p_event_id=>wwv_flow_imp.id(50312024716011147)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(180778011098890233)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(50330886756011193)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>100
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50331325676011195)
,p_event_id=>wwv_flow_imp.id(50330886756011193)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(50313413237011150)
,p_name=>'onClosedNOVO'
,p_event_sequence=>330
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(50307715614011134)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50313937143011151)
,p_event_id=>wwv_flow_imp.id(50313413237011150)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(307780231642358477)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50314489051011153)
,p_event_id=>wwv_flow_imp.id(50313413237011150)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(180778011098890233)
);
wwv_flow_imp.component_end;
end;
/
