prompt --application/pages/page_00118
begin
--   Manifest
--     PAGE: 00118
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>118
,p_name=>unistr('Sistemas - Op\00E7\00F5es')
,p_alias=>unistr('SISTEMAS-OP\00C7\00D5ES')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Op\00E7\00F5es')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240325195850'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(90208866207212068796)
,p_plug_name=>unistr('Op\00E7\00F5es do sistema')
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(306328314432923743)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(254408201081120478)
,p_plug_name=>unistr('Op\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(90208866207212068796)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(50355126106196204)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(74610762990968672)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53236948817005923)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(90208866207212068796)
,p_button_name=>'BTN_EDITAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EDITAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:122:P122_ID,P122_CHAVE:&P118_ID.,117'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53237009342005924)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(90208866207212068796)
,p_button_name=>'BTN_DUPLICAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_DUPLICAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:120:P120_ID:&P118_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53237125427005925)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(90208866207212068796)
,p_button_name=>'BTN_EXCLUIR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(306466091541923828)
,p_button_image_alt=>'BTN_EXCLUIR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:121:P121_ID:&P118_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-trash'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75311451023760348)
,p_name=>'P118_ID_TENANT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(90208866207212068796)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(254150807145168944)
,p_name=>'P118_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(90208866207212068796)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(254408603984120483)
,p_name=>'P118_BLOQUEADO_POR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(90208866207212068796)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(50350981588176724)
,p_name=>'onPageLoad'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50351392457176726)
,p_event_id=>wwv_flow_imp.id(50350981588176724)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(window).width() < 480) {',
'    $( "ul.t-Cards" ).removeClass( "t-Cards--spanHorizontally" );',
'    $( "ul.t-Cards" ).addClass( "t-Cards--float" );',
'}',
'else {',
'    $( "ul.t-Cards" ).addClass( "t-Cards--spanHorizontally" );',
'    $( "ul.t-Cards" ).removeClass( "t-Cards--float" );',
'}'))
);
wwv_flow_imp.component_end;
end;
/
