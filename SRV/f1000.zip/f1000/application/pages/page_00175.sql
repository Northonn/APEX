prompt --application/pages/page_00175
begin
--   Manifest
--     PAGE: 00175
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>175
,p_name=>'Aplicacao - Lista versao'
,p_alias=>'APLICACAO-LISTA-VERSAO'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Vers\00F5es da aplica\00E7\00E3o')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-CardView-actions{',
'    padding: 0px;',
'}',
'',
'.a-CardView-items{',
'    grid-gap: 5px;',
'}'))
,p_step_template=>wwv_flow_imp.id(306297592078923714)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'24'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240417122651'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(150040264925203516)
,p_plug_name=>'Pesquisa'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(306369115795923766)
,p_plug_display_sequence=>40
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(292385732777606176)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(292385732777606176)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(306340637422923751)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id,',
'       a.id_tenant,',
'       a.id_aplicacao,',
'       a.id_sistema_versionado,',
'       b.versao,',
'       a.situacao,',
'       pkg_util.dominio_retorna_tag(''srv_aplicacao_versionada'',''situacao'',a.situacao) as des_situacao,',
'       a.data_descontinuidade',
'  from srv_aplicacao_versionada a',
'  join SRV_SISTEMA_VERSIONADO b on b.id = a.ID_SISTEMA_VERSIONADO',
'  where id_aplicacao = :P175_ID_APLICACAO'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P175_ID_APLICACAO'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(75335952809973680)
,p_region_id=>wwv_flow_imp.id(292385732777606176)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'VERSAO'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DATA_DESCONTINUIDADE'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'DES_SITUACAO'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(75336404374973682)
,p_card_id=>wwv_flow_imp.id(75335952809973680)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:176:&SESSION.::&DEBUG.:156:P176_ID,P176_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(75337095500973684)
,p_card_id=>wwv_flow_imp.id(75335952809973680)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_EDITAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:176:&SESSION.::&DEBUG.:176:P176_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(85957659355727003)
,p_card_id=>wwv_flow_imp.id(75335952809973680)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>40
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_ID,P9000_PAGINA:&ID.,&APP_PAGE_ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(75337643338973685)
,p_card_id=>wwv_flow_imp.id(75335952809973680)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>50
,p_label=>'BTN_EXCLUIR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.:130:P130_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link u-danger-text'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452953325901707513)
,p_plug_name=>'button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(306336319192923749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>'<div id="active_facets"></div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75338681407973688)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(150040264925203516)
,p_button_name=>'BTN_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(306466836923923829)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'ORDER_BY_ITEM'
,p_button_redirect_url=>'f?p=&APP_ID.:176:&SESSION.::&DEBUG.:176:P176_ID_APLICACAO,P176_ID_TENANT:&P175_ID_APLICACAO.,&P175_ID_TENANT.'
,p_button_css_classes=>'u-pullRight'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75411022787820209)
,p_name=>'P175_ID_TENANT'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150044373894203534)
,p_name=>'P175_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(150040264925203516)
,p_prompt=>'Search'
,p_placeholder=>'Buscar por srv_sistema_versao.versao_l'
,p_source=>'VERSAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150658036696876626)
,p_name=>'P175_NOME_APLICACAO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(150040264925203516)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_prompt=>'srv_aplicacao.nome_aplicacao_l'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(50629371471893217)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292394457785606249)
,p_name=>'P175_ID_APLICACAO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(75340273024973697)
,p_computation_sequence=>10
,p_computation_item=>'P175_NOME_APLICACAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select ''(''||codigo_aplicacao||'') ''|| nome_aplicacao from srv_aplicacao where id = :P175_ID_APLICACAO'
,p_compute_when=>'P175_ID_APLICACAO'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75340552238973698)
,p_name=>'onClosedLista'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(292385732777606176)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75341062876973700)
,p_event_id=>wwv_flow_imp.id(75340552238973698)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(292385732777606176)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75341426725973701)
,p_name=>'onClosedBTN_NOVO'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(75338681407973688)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75307287111760306)
,p_event_id=>wwv_flow_imp.id(75341426725973701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(292385732777606176)
);
wwv_flow_imp.component_end;
end;
/
