prompt --application/deployment/install/install_index
begin
--   Manifest
--     INSTALL: INSTALL-index
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(83917703507680798)
,p_install_id=>wwv_flow_imp.id(182102787801617209)
,p_name=>'index'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  CREATE UNIQUE INDEX "ADM_IDIOMA_ID_PK" ON "SRV_IDIOMA" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_CADASTRO_COMPARTILHADO_ENTIDADE_PK" ON "MPD_CADASTRO_COMPARTILHADO_ENTIDADE" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_CADASTRO_COMPARTILHADO_PK" ON "MPD_CADASTRO_COMPARTILHADO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_FUNCIONALIDADE_BOTAO_ACAO_PK" ON "MPD_FUNCIONALIDADE_BOTAO_ACAO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_FUNCIONALIDADE_CRUD_DINAMICO_PK" ON "MPD_FUNCIONALIDADE_CRUD_DINAMICO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_FUNCIONALIDADE_DINAMICA_PK" ON "MPD_FUNCIONALIDADE_DINAMICA" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_FUNCIONALIDADE_PK" ON "MPD_FUNCIONALIDADE" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_FUNCIONALIDADE_REGRA_EXECUCAO_PK" ON "MPD_FUNCIONALIDADE_REGRA_EXECUCAO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_FUNCIONALIDADE_TITULO_PK" ON "MPD_FUNCIONALIDADE_TITULO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_GRUPO_FUNCIONALIDADE_FUNCIONALIDADE_PK" ON "MPD_GRUPO_FUNCIONALIDADE_FUNCIONALIDADE" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_GRUPO_FUNCIONALIDADE_PK" ON "MPD_GRUPO_FUNCIONALIDADE" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_MENU_ACAO_PK" ON "MPD_MENU_ACAO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_MENU_PK" ON "MPD_MENU" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_PAPEL_USUARIO_FUNCIONALIDADE_PK" ON "MPD_PAPEL_FUNCIONALIDADE" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_PAPEL_USUARIO_PK" ON "MPD_PAPEL" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_PARAMETROS_NOME_UN" ON "MPD_PARAMETROS" ("NOME") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_PARAMETROS_PK" ON "MPD_PARAMETROS" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_TENANT_CADASTRO_COMPARTILHADO_PK" ON "MPD_TENANT_CADASTRO_COMPARTILHADO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_USUARIO_FUNCIONALIDADE_PK" ON "MPD_USUARIO_FUNCIONALIDADE" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_USUARIO_ID_PK" ON "MPD_USUARIO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_USUARIO_PAPEL_PK" ON "MPD_USUARIO_PAPEL" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_USUARIO_TENANT_AUTORIZADO_PK" ON "MPD_USUARIO_TENANT" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_USUARIO_TOKEN_LOGIN_UN" ON "MPD_USUARIO_TOKEN" ("LOGIN") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_USUARIO_TOKEN_PK" ON "MPD_USUARIO_TOKEN" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_USUARIO_TOKEN_TOKEN_UN" ON "MPD_USUARIO_TOKEN" ("TOKEN") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "MPD_USUARIO_UN1" ON "MPD_USUARIO" ("LOGIN") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_APLICACAO_MENSAGEM_CODIGO_MENSAGEM_UNQ" ON "SRV_APLICACAO_MENSAGEM" ("CODIGO_MENSAGEM") ',
'  ;',
'',
'  CREATE INDEX "SRV_APLICACAO_MENS_I1" ON "SRV_APLICACAO_MENSAGEM" ("ID_TENANT") ',
'  ;',
'',
'  CREATE INDEX "SRV_APLICACAO_MENS_I51" ON "SRV_APLICACAO_MENSAGEM_TRADUZIDA" ("ID_APLICACAO_MENSAGEM") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_APLICACAO_MENS_ID_PK" ON "SRV_APLICACAO_MENSAGEM" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_APLICACAO_MENS_ID_PK3" ON "SRV_APLICACAO_MENSAGEM_TRADUZIDA" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_APLICACAO_TEXTO_ID_PK" ON "SRV_APLICACAO_TEXTO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_APLICACAO_TEXTO_TRADUZIDO_ID_PK" ON "SRV_APLICACAO_TEXTO_TRADUZIDO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ARTEFATO_ACAO_DINAMICA_PK" ON "SRV_ARTEFATO_ACAO_DINAMICA" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ARTEFATO_BOTAO_ACAO_PK" ON "SRV_ARTEFATO_BOTAO_ACAO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ARTEFATO_CRUD_DINAMICO_PK" ON "SRV_ARTEFATO_CRUD_DINAMICO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ARTEFATO_REGRA_EXECUCAO_PK" ON "SRV_ARTEFATO_REGRA_EXECUCAO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ARTEFATO_RELEASE_PK" ON "SRV_ARTEFATO_RELEASE" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ARTEFATO_SEQUENCIA_PK" ON "SRV_ARTEFATO_SEQUENCIA" ("SEQUENCIA") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ARTEFATO_TITULO_PK" ON "SRV_ARTEFATO_TITULO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ARTEFATO_VERSIONADO_PK" ON "SRV_ARTEFATO_VERSIONADO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ATIVIDADE_TAREFAS_1_PK" ON "SRV_ATIVIDADE_TAREFAS" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_DOMINIO_ID_PK" ON "SRV_DOMINIO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_DOMINIO_VALOR_ID_PK" ON "SRV_DOMINIO_VALOR" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ENTIDADE_COLUNA_ID_PK" ON "SRV_ENTIDADE_COLUNA" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_ENTIDADE_ID_PK" ON "SRV_ENTIDADE" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_GRUPO_FUNCIONALIDADE_ARTEFATO_PK" ON "SRV_GRUPO_FUNCIONALIDADE_ARTEFATO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_GRUPO_FUNCIONALIDADE_PK" ON "SRV_GRUPO_FUNCIONALIDADE" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_MENU_ACAO_ID_PK" ON "SRV_MENU_ACAO" ("ID") ',
'  ;',
'',
'  CREATE INDEX "SRV_MENU_ACAO_IX1" ON "SRV_MENU_ACAO" ("ID_TENANT") ',
'  ;',
'',
'  CREATE INDEX "SRV_MENU_ACAO_IX2" ON "SRV_MENU_ACAO" ("ID_MENU") ',
'  ;',
'',
'  CREATE INDEX "SRV_MENU_ACAO_IX3" ON "SRV_MENU_ACAO" ("ID_USUARIO_INCLUIU") ',
'  ;',
'',
'  CREATE INDEX "SRV_MENU_ACAO_IX4" ON "SRV_MENU_ACAO" ("ID_USUARIO_ALTEROU") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_MENU_ID_PK" ON "SRV_MENU" ("ID") ',
'  ;',
'',
'  CREATE INDEX "SRV_MENU_IX1" ON "SRV_MENU" ("ID_TENANT") ',
'  ;',
'',
'  CREATE INDEX "SRV_MENU_IX2" ON "SRV_MENU" ("ID_MENU_PAI") ',
'  ;',
'',
'  CREATE INDEX "SRV_MENU_IX3" ON "SRV_MENU" ("ID_SISTEMA_VERSIONADO") ',
'  ;',
'',
'  CREATE INDEX "SRV_MENU_IX4" ON "SRV_MENU" ("ID_USUARIO_INCLUIU") ',
'  ;',
'',
'  CREATE INDEX "SRV_MENU_IX5" ON "SRV_MENU" ("ID_USUARIO_ALTEROU") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_PROJETOS_DOCUMENTOS_PK" ON "SRV_PROJETOS_DOCUMENTOS" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_PROJETOS_PK" ON "SRV_PROJETOS" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_PROJETOS_TAREFAS_DOCUMENTOS_PK" ON "SRV_PROJETOS_TAREFAS_DOCUMENTOS" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_PROJETOS_TAREFAS_PK" ON "SRV_PROJETOS_TAREFAS" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_PROJETOS_TAREFAS_USUARIOS_PK" ON "SRV_PROJETOS_TAREFAS_USUARIOS" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_SISTEMA_PK" ON "SRV_SISTEMA" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_SISTEMA_VERSIONADO_PK" ON "SRV_SISTEMA_VERSIONADO" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "SRV_TIPO_TAREFAS_PK" ON "SRV_TIPO_TAREFAS" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "UNIQUE_CODIGO_APLICACAO" ON "SRV_APLICACAO" ("CODIGO_APLICACAO") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "UNIQUE_CODIGO_ARTEFATO" ON "SRV_ARTEFATO" ("CODIGO_ARTEFATO") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "UNIQUE_INCRICAO_FEDERAL" ON "MPD_TENANT" ("INSCRICAO_FEDERAL") ',
'  ; '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83917800675680803)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'ADM_IDIOMA_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83918006438680803)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_CADASTRO_COMPARTILHADO_ENTIDADE_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83918266271680804)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_CADASTRO_COMPARTILHADO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83918498830680804)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_FUNCIONALIDADE_BOTAO_ACAO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83918669492680805)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_FUNCIONALIDADE_CRUD_DINAMICO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83918814519680805)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_FUNCIONALIDADE_DINAMICA_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83919031361680805)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_FUNCIONALIDADE_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83919273677680806)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_FUNCIONALIDADE_REGRA_EXECUCAO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83919400799680806)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_FUNCIONALIDADE_TITULO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83919645732680807)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_GRUPO_FUNCIONALIDADE_FUNCIONALIDADE_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83919865948680807)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_GRUPO_FUNCIONALIDADE_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83920032758680808)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_MENU_ACAO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83920289464680808)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_MENU_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83920440217680808)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_PAPEL_USUARIO_FUNCIONALIDADE_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83920640468680809)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_PAPEL_USUARIO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83920848634680809)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_PARAMETROS_NOME_UN'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83921001857680810)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_PARAMETROS_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83921269745680810)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_TENANT_CADASTRO_COMPARTILHADO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83921403681680810)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_USUARIO_FUNCIONALIDADE_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83921667176680811)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_USUARIO_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83921805080680811)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_USUARIO_PAPEL_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83922036974680812)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_USUARIO_TENANT_AUTORIZADO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83922295829680812)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_USUARIO_TOKEN_LOGIN_UN'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83922418707680813)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_USUARIO_TOKEN_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83922600183680813)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_USUARIO_TOKEN_TOKEN_UN'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83922899267680813)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'MPD_USUARIO_UN1'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83923077191680814)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_APLICACAO_MENSAGEM_CODIGO_MENSAGEM_UNQ'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83923270724680814)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_APLICACAO_MENS_I1'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83923411249680815)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_APLICACAO_MENS_I51'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83923641018680815)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_APLICACAO_MENS_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83923878430680815)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_APLICACAO_MENS_ID_PK3'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83924057527680816)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_APLICACAO_TEXTO_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83924252037680816)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_APLICACAO_TEXTO_TRADUZIDO_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83924410075680817)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ARTEFATO_ACAO_DINAMICA_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83924659157680817)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ARTEFATO_BOTAO_ACAO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83924822311680818)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ARTEFATO_CRUD_DINAMICO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83925092570680818)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ARTEFATO_REGRA_EXECUCAO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83925262873680818)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ARTEFATO_RELEASE_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83925427893680819)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ARTEFATO_SEQUENCIA_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83925608087680819)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ARTEFATO_TITULO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83925883028680819)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ARTEFATO_VERSIONADO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83926043509680820)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ATIVIDADE_TAREFAS_1_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83926245604680820)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_DOMINIO_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83926471933680821)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_DOMINIO_VALOR_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83926688246680821)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ENTIDADE_COLUNA_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83926846788680821)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_ENTIDADE_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83927088206680822)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_GRUPO_FUNCIONALIDADE_ARTEFATO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83927295192680822)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_GRUPO_FUNCIONALIDADE_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83927493307680823)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_ACAO_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83927604227680823)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_ACAO_IX1'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83927849011680823)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_ACAO_IX2'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83928080901680824)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_ACAO_IX3'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83928257093680824)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_ACAO_IX4'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83928479483680824)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_ID_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83928650516680825)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_IX1'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83928805392680825)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_IX2'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83929005067680826)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_IX3'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83929256068680826)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_IX4'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83929476296680826)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_MENU_IX5'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83929657610680827)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_PROJETOS_DOCUMENTOS_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83929838401680827)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_PROJETOS_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83930046524680828)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_PROJETOS_TAREFAS_DOCUMENTOS_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83930274673680828)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_PROJETOS_TAREFAS_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83930477802680828)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_PROJETOS_TAREFAS_USUARIOS_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83930625020680829)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_SISTEMA_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83930825631680829)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_SISTEMA_VERSIONADO_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83931062282680830)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'SRV_TIPO_TAREFAS_PK'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83931276226680830)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'UNIQUE_CODIGO_APLICACAO'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83931459272680830)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'UNIQUE_CODIGO_ARTEFATO'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83931667530680831)
,p_script_id=>wwv_flow_imp.id(83917703507680798)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'UNIQUE_INCRICAO_FEDERAL'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122041','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
