prompt --application/deployment/install/install_type
begin
--   Manifest
--     INSTALL: INSTALL-type
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>1000
,p_default_id_offset=>77580607418923166
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(83956268931684829)
,p_install_id=>wwv_flow_imp.id(182102787801617209)
,p_name=>'type'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace type "TEXTARRAY" as',
'table of varchar2(8000)',
'/',
' '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(83956308752684830)
,p_script_id=>wwv_flow_imp.id(83956268931684829)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TYPE'
,p_object_name=>'TEXTARRAY'
,p_last_updated_by=>'NTO'
,p_last_updated_on=>to_date('20240410122121','YYYYMMDDHH24MISS')
,p_created_by=>'NTO'
,p_created_on=>to_date('20240410122121','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
