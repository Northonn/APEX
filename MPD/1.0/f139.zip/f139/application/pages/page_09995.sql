prompt --application/pages/page_09995
begin
--   Manifest
--     PAGE: 09995
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9995
,p_name=>'Recupera Senha'
,p_alias=>'RECUPERA-SENHA'
,p_step_title=>'Recupera Senha'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(280719082211191960)
,p_step_template=>wwv_flow_imp.id(399342888283126040)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'SRV-LAB'
,p_last_upd_yyyymmddhh24miss=>'20230722211248'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(557790977619709723)
,p_plug_name=>'MBP'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(399431308717126088)
,p_plug_display_sequence=>10
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="#APP_FILES#logo.png" style="height: 30px;" alt="Minha Figura"></img>',
'<div class="st-titulo-app">&APP_NAME.</div>',
'',
'',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452475233910198304)
,p_plug_name=>'Senha temporaria'
,p_parent_plug_id=>wwv_flow_imp.id(557790977619709723)
,p_region_css_classes=>'st-back-transp'
,p_icon_css_classes=>'fa-clock-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(399348451263126044)
,p_plug_display_sequence=>10
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
unistr('<div class="st-titulo-login">Informe a senha tempor\00E1ria</div>'),
'<div class="st-detalhe-login">enviada para o e-mail &P9995_EMAIL.</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(329733956376677463)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(452475233910198304)
,p_button_name=>'REDEFINIR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Redefinir'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(329739479264677467)
,p_branch_name=>'Go to 9999'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(329733956376677463)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329734336225677464)
,p_name=>'P9995_USERNAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(452475233910198304)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329734716779677464)
,p_name=>'P9995_SENHA_TEMPORARIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(452475233910198304)
,p_prompt=>unistr('Senha tempor\00E1ria')
,p_placeholder=>unistr('Senha tempor\00E1ria')
,p_display_as=>'PLUGIN_COM.FOS.ADVANCED_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(399484158225126126)
,p_item_icon_css_classes=>'fa-clock-o'
,p_item_template_options=>'#DEFAULT#:margin-top-md'
,p_attribute_01=>'enabled-toggle'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329735106718677464)
,p_name=>'P9995_PASSWORD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(452475233910198304)
,p_prompt=>'Senha'
,p_placeholder=>'Nova senha'
,p_display_as=>'PLUGIN_COM.FOS.ADVANCED_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(399484158225126126)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'enabled-toggle'
,p_attribute_02=>'collapsible'
,p_attribute_03=>'Excelente'
,p_attribute_04=>'require-min-length:require-number:require-spec-char:require-capital-letter:show-pwd-strength-bar:show-caps-lock-on:enable-inline-icons'
,p_attribute_05=>'7'
,p_attribute_06=>'Deve conter pelo menos #MIN_LENGTH# caracteres.'
,p_attribute_07=>'1'
,p_attribute_08=>unistr('Pelo menos #MIN_NUMS# n\00FAmeros.')
,p_attribute_09=>unistr('?><,./|}[]~\00A7@#$%')
,p_attribute_10=>'2'
,p_attribute_11=>'Pelo menos #MIN_SPEC_CHARS# da lista: #SPEC_CHARS_LIST#'
,p_attribute_12=>'1'
,p_attribute_13=>unistr('Deve conter pelo menos #MIN_CAPS# letras mai\00FAsculas')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329735528002677464)
,p_name=>'P9995_C_PASSWORD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(452475233910198304)
,p_prompt=>'Senha'
,p_placeholder=>'Confirme a senha'
,p_display_as=>'PLUGIN_COM.FOS.ADVANCED_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(399484158225126126)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'enabled-toggle'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329735893980677465)
,p_name=>'P9995_EMAIL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(452475233910198304)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(329737657464677466)
,p_validation_name=>'P9995_SENHA_TEMPORARIA-Valid auth2'
,p_validation_sequence=>10
,p_validation=>'return PKG_API_SEGURANCA.valid_username_and_password(:P9995_USERNAME,:P9995_SENHA_TEMPORARIA);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(329734716779677464)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(329736425913677466)
,p_validation_name=>'P9995_C_PASSWORD-Valid'
,p_validation_sequence=>30
,p_validation=>'P9995_C_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Senhas n\00E3o conferem')
,p_associated_item=>wwv_flow_imp.id(329735528002677464)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(329736866022677466)
,p_validation_name=>'P9995_C_PASSWORD-Valid_1'
,p_validation_sequence=>40
,p_validation=>':P9995_PASSWORD = :P9995_C_PASSWORD'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Senhas n\00E3o conferem')
,p_associated_item=>wwv_flow_imp.id(329735528002677464)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(329737207459677466)
,p_validation_name=>'P9995_PASSWORD-Valid not null'
,p_validation_sequence=>50
,p_validation=>'P9995_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Nova senha deve ser informada'
,p_associated_item=>wwv_flow_imp.id(329735106718677464)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(329737939187677466)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Grava senha'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'SAVE_PASSWORD'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Senha redefinida com sucesso'
,p_internal_uid=>62048456819120047
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(329738432571677467)
,p_page_process_id=>wwv_flow_imp.id(329737939187677466)
,p_page_id=>9995
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9995_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(329738944646677467)
,p_page_process_id=>wwv_flow_imp.id(329737939187677466)
,p_page_id=>9995
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9995_PASSWORD'
);
wwv_flow_imp.component_end;
end;
/
