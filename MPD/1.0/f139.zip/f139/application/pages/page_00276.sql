prompt --application/pages/page_00276
begin
--   Manifest
--     PAGE: 00276
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>276
,p_name=>unistr('Usu\00E1rios - Funcionalidades do usu\00E1rio')
,p_alias=>unistr('USU\00C1RIOS-FUNCIONALIDADES-DO-USU\00C1RIO')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Usu\00E1rios - Funcionalidades do usu\00E1rio')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function goto_modal(p1)',
'{',
' var url = "f?p=&APP_ID.:455:&SESSION.";',
' var url1 = ''::NO::P455_METADATA_ENTIDADE_ID:''+p1',
' var l = ("javascript:apex.navigation.dialog(''f?p=&APP_ID.:455:&SESSION.").length;',
' var f = url.slice(0,l) + url.slice(l) + url1 ;',
' f = f.replace(":::::",":");',
' console.log(f);',
' window.location.href = f;',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("h1").append($("#icon_info"));',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-actions{',
'    display: none;',
'}',
'',
'.a-CardView-header{',
'    background-color: aliceblue;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'}',
'',
'.a-CardView-actions{',
'    padding: 0px;',
'}',
'',
'.a-CardView-items{',
'    grid-gap: 5px;',
'}'))
,p_step_template=>wwv_flow_imp.id(399317728909126015)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_page_component_map=>'24'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240325190157'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(330721999525315180)
,p_plug_name=>'Pesquisa'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>60
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(330722063925315181)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(330722063925315181)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399360774253126052)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     ',
'       A.ID,',
'       A.ID_TENANT,',
'       A.ID_USUARIO,',
'       TO_CHAR(A.ID_FUNCIONALIDADE) AS FUNCIONALIDADE,',
'       B.NOME AS NOME',
'  from MPD_USUARIO_FUNCIONALIDADE A',
'  join MPD_USUARIO B',
'  on B.ID = A.ID_USUARIO',
'  where A.ID_USUARIO = :P276_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P276_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(173360924734059700)
,p_region_id=>wwv_flow_imp.id(330722063925315181)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'FUNCIONALIDADE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(173361410126059701)
,p_card_id=>wwv_flow_imp.id(173360924734059700)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:277:&SESSION.::&DEBUG.:277:P277_ID,P277_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(173361970937059703)
,p_card_id=>wwv_flow_imp.id(173360924734059700)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'BTN_EDITAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:277:&SESSION.::&DEBUG.:277:P277_ID,P277_EDITAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(173362609751059705)
,p_card_id=>wwv_flow_imp.id(173360924734059700)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'BTN_EXCLUIR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:278:&SESSION.::&DEBUG.:278:P278_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link u-danger-text'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(173363629431059710)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(330721999525315180)
,p_button_name=>'BTN_NOVO'
,p_button_static_id=>'REL_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--gapLeft:t-Button--padRight:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'ORDER_BY_ITEM'
,p_button_redirect_url=>'f?p=&APP_ID.:277:&SESSION.::&DEBUG.:277:P277_ID_USUARIO:&P276_ID.'
,p_button_css_classes=>'u-pullRight'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(173535107177178996)
,p_branch_name=>'Go to 277'
,p_branch_action=>'f?p=&APP_ID.:277:&SESSION.::&DEBUG.:277:P277_ID_USUARIO:&P276_ID.'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'NOT_EXISTS'
,p_branch_condition=>'select 1 from mpd_usuario_funcionalidade where id_usuario = :P276_ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(330729675501315243)
,p_name=>'P276_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(330721999525315180)
,p_prompt=>'Search'
,p_placeholder=>'Busca por mpd_usuario_funcionalidade.id_funcionalidade_l'
,p_source=>'FUNCIONALIDADE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(330730100641315247)
,p_name=>'P276_NOME_MENU'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(330721999525315180)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_prompt=>'mpd_usuario.nome_l'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(583321728308711201)
,p_name=>'P276_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(173369013003059731)
,p_computation_sequence=>20
,p_computation_item=>'P276_NOME_MENU'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select ''(''||LOGIN||'') ''|| NOME from mpd_usuario a where id = :P276_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(173376607844059750)
,p_name=>'INFO-Mouse enter'
,p_event_sequence=>100
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(173377151268059752)
,p_event_id=>wwv_flow_imp.id(173376607844059750)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(173374313756059745)
,p_name=>'onDialogClosedBTN_NOVO'
,p_event_sequence=>350
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(173363629431059710)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(173375276042059747)
,p_event_id=>wwv_flow_imp.id(173374313756059745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(330722063925315181)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(173536599045179011)
,p_name=>'onDialogClosedLISTA'
,p_event_sequence=>360
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(330722063925315181)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(173536667254179012)
,p_event_id=>wwv_flow_imp.id(173536599045179011)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(330722063925315181)
);
wwv_flow_imp.component_end;
end;
/
