prompt --application/pages/page_00267
begin
--   Manifest
--     PAGE: 00267
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>267
,p_name=>unistr('Usu\00E1rios - Incluir um novo papel')
,p_alias=>unistr('USU\00C1RIOS-INCLUIR-UM-NOVO-PAPEL')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Usu\00E1rios - Incluir um novo papel')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("body").on("click", "#" + ''LIST_ABA'' + " " + ''.t-MediaList-itemWrap'', function (e) {',
'    e.preventDefault();',
'            var selectedID = $(this).data("id");',
'            AtribuirValorItem(''P51_ABA'',selectedID);',
'})'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region-bodyWrap{',
'    background-color: white;',
'    //border-radius: 10px !IMPORTANT;',
'}',
'',
'.st-radius-100{',
'    border-radius: 100%!IMPORTANT;',
'}',
'',
'.t-Form-labelContainer--hiddenLabel{',
'    display: none;',
'}',
'',
'.apex-item-text {',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group--popup-lov{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-popup-lov{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;    ',
'}',
'',
'.a-Button {',
'         border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'.a-Button--popupLOV{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'',
'.ap-password-eye{',
'    box-shadow: none!IMPORTANT;',
'}',
'',
'.st-item-center{   ',
'    display: block !IMPORTANT;',
'    text-align: center !IMPORTANT;',
'}',
'',
'.a-bloco{',
'    padding: 10px;',
'}',
'',
'.apex-item-filedrop{',
'    border: none;',
'}',
'',
'.apex-item-filedrop-progress{',
'    border: none;',
'}',
'',
'.apex-item-filedrop{',
'    color: var(--ut-body-text-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(399317728909126015)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when=>'P267_VISUALIZAR'
,p_page_component_map=>'17'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240403180045'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129289481278511468124)
,p_plug_name=>'Incluir um novo papel'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading js-removeLandmark:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(399348451263126044)
,p_plug_display_sequence=>33
,p_query_type=>'TABLE'
,p_query_table=>'MPD_PAPEL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172773850021114636)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_GRAVAR'
,p_button_position=>'CREATE'
,p_button_condition=>':P267_EDITAR IS NULL AND :P267_VISUALIZAR IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172773440341114635)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_GRAVAR'
,p_button_position=>'CREATE'
,p_button_condition=>':P267_ID IS NOT NULL AND :P267_VISUALIZAR IS NULL AND :P267_DUPLICAR IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172750040291034779)
,p_name=>'P267_NOME_PAPEL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_item_source_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_prompt=>'mpd_papel.nome_papel_l'
,p_placeholder=>'mpd_papel.nome_papel_i'
,p_source=>'NOME_PAPEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>128
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'mpd_papel.nome_papel_h'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(249516249993099884)
,p_name=>'P267_VISUALIZAR'
,p_item_sequence=>1
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(249516347241099885)
,p_name=>'P267_DUPLICAR'
,p_item_sequence=>2
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(249517641065099898)
,p_name=>'P267_EDITAR'
,p_item_sequence=>3
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(299952834833334777)
,p_name=>'P267_ID_TENANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_item_source_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_source=>'ID_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'SRV_SISTEMA.ID_TENANT_H'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(299953134312334780)
,p_name=>'P267_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_item_source_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(299953307532334781)
,p_name=>'P267_DATA_INCLUSAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_item_source_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(299953398777334782)
,p_name=>'P267_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_item_source_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(299953476605334783)
,p_name=>'P267_DATA_ALTERACAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_item_source_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326070224278699291)
,p_name=>'P267_RESULTADO'
,p_item_sequence=>4
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326070396290699292)
,p_name=>'P267_RESULTADO_MENSAGEM'
,p_item_sequence=>5
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(528956266229979712)
,p_name=>'P267_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_item_source_plug_id=>wwv_flow_imp.id(129289481278511468124)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(172840627766735972)
,p_computation_sequence=>10
,p_computation_item=>'P267_ID_TENANT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_id_usuario number := pkg_util.retorna_id_usuario_logado;',
'    v_id_tenant number;',
'begin',
'    select id_tenant into v_id_tenant from mpd_usuario where id = v_id_usuario;',
'    return v_id_tenant;',
'end;    '))
,p_compute_when=>'P267_EDITAR'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(172751347703034792)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'INCLUI_REGISTRO'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_MPD_PAPEL'
,p_attribute_04=>'INCLUI_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(172773850021114636)
,p_process_success_message=>'&P267_RESULTADO_MENSAGEM.'
,p_internal_uid=>79029989058366822
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172751379625034793)
,p_page_process_id=>wwv_flow_imp.id(172751347703034792)
,p_page_id=>267
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P267_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172751460515034794)
,p_page_process_id=>wwv_flow_imp.id(172751347703034792)
,p_page_id=>267
,p_name=>'p_nome_papel'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P267_NOME_PAPEL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172751618919034795)
,p_page_process_id=>wwv_flow_imp.id(172751347703034792)
,p_page_id=>267
,p_name=>'p_id'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P267_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172751706932034796)
,p_page_process_id=>wwv_flow_imp.id(172751347703034792)
,p_page_id=>267
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172751828267034797)
,p_page_process_id=>wwv_flow_imp.id(172751347703034792)
,p_page_id=>267
,p_name=>'p_resultado'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P267_RESULTADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172751931138034798)
,p_page_process_id=>wwv_flow_imp.id(172751347703034792)
,p_page_id=>267
,p_name=>'p_resultado_mensagem'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P267_RESULTADO_MENSAGEM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(172783154609114663)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'ALTERA_REGISTRO'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_MPD_PAPEL'
,p_attribute_04=>'ALTERA_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(172773440341114635)
,p_process_success_message=>'&P267_RESULTADO_MENSAGEM.'
,p_internal_uid=>79061795964446693
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172750162603034781)
,p_page_process_id=>wwv_flow_imp.id(172783154609114663)
,p_page_id=>267
,p_name=>'p_nome_papel'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>90
,p_value_type=>'ITEM'
,p_value=>'P267_NOME_PAPEL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172750306147034782)
,p_page_process_id=>wwv_flow_imp.id(172783154609114663)
,p_page_id=>267
,p_name=>'p_data_alteracao'
,p_direction=>'IN'
,p_data_type=>'TIMESTAMP'
,p_has_default=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P267_DATA_ALTERACAO'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172783574268114664)
,p_page_process_id=>wwv_flow_imp.id(172783154609114663)
,p_page_id=>267
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P267_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172785608230114668)
,p_page_process_id=>wwv_flow_imp.id(172783154609114663)
,p_page_id=>267
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P267_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172786077544114670)
,p_page_process_id=>wwv_flow_imp.id(172783154609114663)
,p_page_id=>267
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172786571783114671)
,p_page_process_id=>wwv_flow_imp.id(172783154609114663)
,p_page_id=>267
,p_name=>'p_resultado'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P267_RESULTADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(172787117511114672)
,p_page_process_id=>wwv_flow_imp.id(172783154609114663)
,p_page_id=>267
,p_name=>'p_resultado_mensagem'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P267_RESULTADO_MENSAGEM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(172791932011114682)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_01=>'P267_RESULTADO_MENSAGEM'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>79070573366446712
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(172781706560114658)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(129289481278511468124)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Incluir conte\00FAdo')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>79060347915446688
);
wwv_flow_imp.component_end;
end;
/
