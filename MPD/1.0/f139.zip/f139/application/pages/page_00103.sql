prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>103
,p_name=>'T103 - "Alterar tenant"'
,p_alias=>'T103-ALTERAR-TENANT'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Alterar Informa\00E7\00F5es')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("body").on("click", "#" + ''LIST_ABA'' + " " + ''.t-MediaList-itemWrap'', function (e) {',
'    e.preventDefault();',
'            var selectedID = $(this).data("id");',
'            AtribuirValorItem(''P51_ABA'',selectedID);',
'})'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region-bodyWrap{',
'    background-color: white;',
'    //border-radius: 10px !IMPORTANT;',
'}',
'',
'.st-radius-100{',
'    border-radius: 100%!IMPORTANT;',
'}',
'',
'.t-Form-labelContainer--hiddenLabel{',
'    display: none;',
'}',
'',
'.apex-item-text {',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group--popup-lov{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-popup-lov{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;    ',
'}',
'',
'.a-Button {',
'         border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'.a-Button--popupLOV{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'',
'.ap-password-eye{',
'    box-shadow: none!IMPORTANT;',
'}',
'',
'.st-item-center{   ',
'    display: block !IMPORTANT;',
'    text-align: center !IMPORTANT;',
'}',
'',
'.a-bloco{',
'    padding: 10px;',
'}',
'',
'.apex-item-filedrop{',
'    border: none;',
'}',
'',
'.apex-item-filedrop-progress{',
'    border: none;',
'}',
'',
'.apex-item-filedrop{',
'    color: var(--ut-body-text-color);',
'}'))
,p_step_template=>wwv_flow_imp.id(399317728909126015)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240315175310'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129314971842195458041)
,p_plug_name=>unistr('Incluir um novo usu\00E1rio')
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading js-removeLandmark:t-Form--noPadding:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(399348451263126044)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'MPD_TENANT'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(171143099273164200)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar'
,p_button_position=>'NEXT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173590996307294585)
,p_name=>'P103_RESULTADO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173591090025294586)
,p_name=>'P103_RESULTADO_MENSAGEM'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(248205847123075532)
,p_name=>'P103_RAZAO_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_prompt=>unistr('Raz\00E3o Social')
,p_placeholder=>unistr('Informe a raz\00E3o social')
,p_source=>'RAZAO_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Raz\00E3o social '),
'',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(248205902959075533)
,p_name=>'P103_INSCRICAO_FEDERAL'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_prompt=>unistr('Inscri\00E7\00E3o Federal')
,p_placeholder=>unistr('Informe o n\00FAmero do CNPJ ou CPF')
,p_source=>'INSCRICAO_FEDERAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('N\00FAmero do CPF ou CNPJ do licenciado'),
''))
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(248206073929075534)
,p_name=>'P103_AUTENTICACAO_MFA_ATIVA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_prompt=>unistr('Autentica\00E7\00E3o MFA')
,p_placeholder=>unistr('Informe se a autentica\00E7\00E3o multi fator deve ser ativada')
,p_source=>'AUTENTICACAO_MFA_ATIVA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>unistr('STATIC2:Sim;S,N\00E3o;N')
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Quando a autentica\00E7\00E3o multi fatores \00E9 ativada, o processo de autentica\00E7\00E3o do usu\00E1rio  necessitar\00E1 do token, al\00E9m do login e senha'),
''))
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(248206089247075535)
,p_name=>'P103_NUMERO_LICENCA_USO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_prompt=>unistr('Licen\00E7a de uso')
,p_placeholder=>unistr('Informe o n\00FAmero da licen\00E7a de uso')
,p_source=>'NUMERO_LICENCA_USO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(248206253809075536)
,p_name=>'P103_QTD_MAXIMA_TENTATIVA_LOGIN'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_prompt=>unistr('Quantidade m\00E1xima de tentativa de login')
,p_placeholder=>unistr('Informe a quantidade m\00E1xima de tentativa de login antes de ser bloqueado')
,p_source=>'QTD_MAXIMA_TENTATIVA_LOGIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Informa o n\00FAmero m\00E1ximo de tentativas de login, antes do usu\00E1rio ser bloqueado'),
''))
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(248206360221075537)
,p_name=>'P103_SITUACAO_TENANT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_prompt=>unistr('Situa\00E7\00E3o')
,p_placeholder=>unistr('Informe a situa\00E7\00E3o do Tenant')
,p_source=>'SITUACAO_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'STATIC:Ativo;A,Bloqueado;B,Cancelado;C'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Informa a situa\00E7\00E3o do Tenant'),
'',
''))
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323292535959872176)
,p_name=>'P103_FORMA_AUTENTICACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_prompt=>unistr('Formas de Autentica\00E7\00E3o')
,p_source=>'FORMA_AUTENTICACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>'STATIC:APP;1,EMAIL;2,SMS;3,WHATSAPP;4'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'ALL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(325499622618461633)
,p_name=>'P103_DATA_INCLUSAO'
,p_source_data_type=>'DATE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(325499727038461634)
,p_name=>'P103_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(325499819240461635)
,p_name=>'P103_DATA_ALTERACAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(325499926787461636)
,p_name=>'P103_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(554447083530969623)
,p_name=>'P103_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_item_source_plug_id=>wwv_flow_imp.id(129314971842195458041)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(171202520307044289)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'altera_registro'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_MPD_TENANT'
,p_attribute_04=>'ALTERA_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'&P103_RESULTADO_MENSAGEM.'
,p_internal_uid=>77481161662376319
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171202641973044290)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_razao_social'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P103_RAZAO_SOCIAL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171202730253044291)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_inscricao_federal'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P103_INSCRICAO_FEDERAL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171202831149044292)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_autenticacao_mfa_ativa'
,p_direction=>'IN'
,p_data_type=>'CHAR'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P103_AUTENTICACAO_MFA_ATIVA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171202941264044293)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_numero_licenca_uso'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P103_NUMERO_LICENCA_USO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171202995667044294)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_qtd_maxima_tentativa_login'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P103_QTD_MAXIMA_TENTATIVA_LOGIN'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171203141932044295)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_situacao_tenant'
,p_direction=>'IN'
,p_data_type=>'CHAR'
,p_has_default=>false
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P103_SITUACAO_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171203190233044296)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P103_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171203290165044297)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_data_alteracao'
,p_direction=>'IN'
,p_data_type=>'TIMESTAMP'
,p_has_default=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P103_DATA_ALTERACAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171203445264044298)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>90
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171203539537044299)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_resultado'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P103_RESULTADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171203601853044300)
,p_page_process_id=>wwv_flow_imp.id(171202520307044289)
,p_page_id=>103
,p_name=>'p_resultado_mensagem'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>110
,p_value_type=>'ITEM'
,p_value=>'P103_RESULTADO_MENSAGEM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(147681712296591287)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'closed'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>53960353651923317
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(171153768433164229)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(129314971842195458041)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Incluir conte\00FAdo')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>77432409788496259
);
wwv_flow_imp.component_end;
end;
/
