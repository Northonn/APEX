prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(399515229406126170)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(270961052044155437)
,p_group_name=>'Agendamentos'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(270644310415466658)
,p_group_name=>'Artefatos'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(284619358680050370)
,p_group_name=>'Cadastro auxiliar'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(267713856540630698)
,p_group_name=>'Chamados'
,p_group_desc=>unistr('Grupo de p\00E1ginas do projeto de chamados.')
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(281482182937612730)
,p_group_name=>'Controle de acesso'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(269636445369068646)
,p_group_name=>'Convites'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(286012715165407970)
,p_group_name=>'Importar dados'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(280719082211191960)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(286836205132460940)
,p_group_name=>'Tabela'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(280719150273192946)
,p_group_name=>'Template'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(269874556633722322)
,p_group_name=>'Tutorial'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(270864541777777963)
,p_group_name=>'Usuarios'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(270981403587770889)
,p_group_name=>'Webservices'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(269250617964153199)
,p_group_name=>'Workspace'
);
wwv_flow_imp.component_end;
end;
/
