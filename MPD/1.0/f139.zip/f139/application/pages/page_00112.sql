prompt --application/pages/page_00112
begin
--   Manifest
--     PAGE: 00112
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>112
,p_name=>unistr('Usu\00E1rios - Op\00E7\00F5es')
,p_alias=>unistr('USU\00C1RIOS-OP\00C7\00D5ES')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Op\00E7\00F5es')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(399317728909126015)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240320171139'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(90329377263690658819)
,p_plug_name=>unistr('Op\00E7\00F5es do usu\00E1rio')
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(399348451263126044)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(374919257559710501)
,p_plug_name=>unistr('Op\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(90329377263690658819)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(170869853165803913)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(168234608284393608)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(148295588904962290)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(90329377263690658819)
,p_button_name=>'BTN_DUPLICAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_image_alt=>'BTN_DUPLICAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.:107:P107_ID:&P112_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(148296138082962891)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(90329377263690658819)
,p_button_name=>'BTN_EXCLUIR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_EXCLUIR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:104:P108_ID:&P112_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-trash '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(374661868304758966)
,p_name=>'P112_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(90329377263690658819)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172845180909736018)
,p_name=>unistr('onDialogClosedOp\00E7\00F5es')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(90329377263690658819)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172845324030736019)
,p_event_id=>wwv_flow_imp.id(172845180909736018)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'document.location.reload(true);'
);
wwv_flow_imp.component_end;
end;
/
