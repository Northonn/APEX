prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_step_title=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240503132322'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(273055754957231113)
,p_name=>unistr('Menu perfil de usu\00E1rio')
,p_region_name=>'exitpopup_bg'
,p_template=>wwv_flow_imp.id(273628528383419081)
,p_display_sequence=>10
,p_region_template_options=>'js-modal:js-draggable:js-dialog-size600x400'
,p_component_template_options=>'#DEFAULT#'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID AS USER_ID,',
'       LOGIN AS USER_NAME,',
'       NOME,',
'       APELIDO,',
'       SITUACAO_CADASTRAL,',
'       DATA_INCLUSAO,',
'       ID_USUARIO_INCLUIU,',
'       DATA_ALTERACAO,',
'       ID_USUARIO_ALTEROU,',
'       EMAIL AS EMAIL,',
'       SENHA,       ',
'       TELEFONE,',
'       ''Editar perfil'' AS EDIT_PROFIL,',
'       /*',
'       CASE',
'           WHEN TIPO = ''ADMIN:CREATE:DATA_LOADER:EDIT:HELP:MONITOR:SQL'' THEN ''Administrador''',
'           WHEN TIPO = ''CREATE:DATA_LOADER:EDIT:HELP:MONITOR:SQL'' THEN ''Desenvolvedor''',
unistr('           ELSE ''Usu\00E1rio final'''),
'       END AS ROLE,',
'       */',
'       ''f?p=&APP_ID.:0:&APP_SESSION.:APPLICATION_PROCESS=GET_IMAGE_USER:::IMAGE_USER_ID:&APP_USER.'' AS URL_IMAGE ,',
'       APEX_UTIL.PREPARE_URL(P_URL => ''f?p='' || :APP_ALIAS || '':106:'' || :APP_SESSION ||''::NO::P106_ID:'' || ID, P_CHECKSUM_TYPE => ''SESSION'') AS URL_EDITAR,',
'  (SELECT WORKSPACE',
'   FROM APEX_WORKSPACES A',
'   WHERE WORKSPACE_ID = :WORKSPACE_ID) AS WORKSPACE',
'FROM MPD_USUARIO',
'WHERE UPPER(LOGIN) = UPPER(:APP_USER)'))
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(272907418971898129)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(273055921889231114)
,p_query_column_id=>1
,p_column_alias=>'USER_ID'
,p_column_display_sequence=>10
,p_column_heading=>'User Id'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(273056081988231116)
,p_query_column_id=>2
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>40
,p_column_heading=>'User Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(171039927413982092)
,p_query_column_id=>3
,p_column_alias=>'NOME'
,p_column_display_sequence=>290
,p_column_heading=>'Nome'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(171039997001982093)
,p_query_column_id=>4
,p_column_alias=>'APELIDO'
,p_column_display_sequence=>300
,p_column_heading=>'Apelido'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(245501739775546477)
,p_query_column_id=>5
,p_column_alias=>'SITUACAO_CADASTRAL'
,p_column_display_sequence=>240
,p_column_heading=>'Situacao Cadastral'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(245501799434546478)
,p_query_column_id=>6
,p_column_alias=>'DATA_INCLUSAO'
,p_column_display_sequence=>250
,p_column_heading=>'Data Inclusao'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(245501892408546479)
,p_query_column_id=>7
,p_column_alias=>'ID_USUARIO_INCLUIU'
,p_column_display_sequence=>260
,p_column_heading=>'Id Usuario Incluiu'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(245501956933546480)
,p_query_column_id=>8
,p_column_alias=>'DATA_ALTERACAO'
,p_column_display_sequence=>270
,p_column_heading=>'Data Alteracao'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(245502087038546481)
,p_query_column_id=>9
,p_column_alias=>'ID_USUARIO_ALTEROU'
,p_column_display_sequence=>280
,p_column_heading=>'Id Usuario Alterou'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(273056875793231124)
,p_query_column_id=>10
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>120
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(273057025183231125)
,p_query_column_id=>11
,p_column_alias=>'SENHA'
,p_column_display_sequence=>130
,p_column_heading=>'Senha'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(273057394817231129)
,p_query_column_id=>12
,p_column_alias=>'TELEFONE'
,p_column_display_sequence=>170
,p_column_heading=>'Telefone'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(273057512977231130)
,p_query_column_id=>13
,p_column_alias=>'EDIT_PROFIL'
,p_column_display_sequence=>180
,p_column_heading=>'Edit Profil'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(273512225595662400)
,p_query_column_id=>14
,p_column_alias=>'URL_IMAGE'
,p_column_display_sequence=>210
,p_column_heading=>'Url Image'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(273514859186662427)
,p_query_column_id=>15
,p_column_alias=>'URL_EDITAR'
,p_column_display_sequence=>220
,p_column_heading=>'Url Editar'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(273057719118231132)
,p_query_column_id=>16
,p_column_alias=>'WORKSPACE'
,p_column_display_sequence=>200
,p_column_heading=>'Workspace'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(273058353265231139)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(273055754957231113)
,p_button_name=>'LOGOOUT'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--warning:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(399487122573126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Sair'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'&LOGOUT_URL.'
,p_icon_css_classes=>'fa-sign-out'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(273058263410231138)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(273055754957231113)
,p_button_name=>'CHANGE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(399487122573126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Mais informa\00E7\00F5es')
,p_button_position=>'DELETE'
,p_button_redirect_url=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:106:P106_ID:&ID_USUARIO_LOGADO.'
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(368062775292665219)
,p_name=>unistr('Refresh notifica\00E7\00F5es')
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#notification-menu'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(368062894531665220)
,p_event_id=>wwv_flow_imp.id(368062775292665219)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#notification-menu'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(273057869617231134)
,p_name=>unistr('Abrir menu perfil de usu\00E1rio')
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.image_icon.st'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(273057968254231135)
,p_event_id=>wwv_flow_imp.id(273057869617231134)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'openModal("exitpopup_bg");',
'$(''.image_icon'').removeClass(''st'');',
'$(''.image_icon'').addClass(''et'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(273058120603231136)
,p_name=>unistr('Fechar menu perfil de usu\00E1rio')
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.image_icon.et'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(273058168438231137)
,p_event_id=>wwv_flow_imp.id(273058120603231136)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'closeModal("exitpopup_bg");',
'$(''.image_icon'').removeClass(''et'');',
'$(''.image_icon'').addClass(''st'');'))
);
wwv_flow_imp.component_end;
end;
/
