prompt --application/pages/page_00110
begin
--   Manifest
--     PAGE: 00110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>110
,p_name=>unistr('Usu\00E1rios - Edi\00E7\00E3o dados de acesso')
,p_alias=>unistr('USU\00C1RIOS-EDI\00C7\00C3O-DADOS-DE-ACESSO')
,p_page_mode=>'MODAL'
,p_step_title=>'Alterar dados de acesso'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("body").on("click", "#" + ''LIST_ABA'' + " " + ''.t-MediaList-itemWrap'', function (e) {',
'    e.preventDefault();',
'            var selectedID = $(this).data("id");',
'            AtribuirValorItem(''P52_ABA'',selectedID);',
'})'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region-bodyWrap{',
'    background-color: white;',
'    //border-radius: 10px !IMPORTANT;',
'}',
'',
'.st-radius-100{',
'    border-radius: 100%!IMPORTANT;',
'}',
'',
'.t-Form-labelContainer--hiddenLabel{',
'    display: none;',
'}',
'',
'.apex-item-text {',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group--popup-lov{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-popup-lov{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;    ',
'}',
'',
'.a-Button {',
'         border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'.a-Button--popupLOV{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'',
'.ap-password-eye{',
'    box-shadow: none!IMPORTANT;',
'}',
'',
'.st-item-center{   ',
'    display: block !IMPORTANT;',
'    text-align: center !IMPORTANT;',
'}',
'',
'.a-bloco{',
'    padding: 10px;',
'}',
'',
'.t-Region-bodyWrap{',
'    background-color: white;',
'    //border-radius: 10px !IMPORTANT;',
'}',
'',
'.st-radius-100{',
'    border-radius: 100%!IMPORTANT;',
'}',
'',
'.t-Form-labelContainer--hiddenLabel{',
'    display: none;',
'}',
'',
'.apex-item-text {',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-group--popup-lov{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT; ',
'}',
'',
'.apex-item-popup-lov{',
'     border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;    ',
'}',
'',
'.a-Button {',
'         border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'.a-Button--popupLOV{',
'    border-top: none!IMPORTANT;',
'    border-left: none!IMPORTANT;',
'    border-right: none!IMPORTANT;  ',
'}',
'',
'.ap-password-eye{',
'    box-shadow: none!IMPORTANT;',
'}',
'',
'.st-item-center{   ',
'    display: block !IMPORTANT;',
'    text-align: center !IMPORTANT;',
'}',
'',
'.a-bloco{',
'    padding: 10px;',
'}',
'',
'.apex-item-filedrop{',
'    border: none;',
'}',
'',
'.apex-item-filedrop-progress{',
'    border: none;',
'}',
'',
'.apex-item-filedrop{',
'    color: var(--ut-body-text-color);',
'}',
'',
'.t-Form-fieldContainer--floatingLabel .t-Form-itemWrapper {',
'    flex-wrap: nowrap;',
'}'))
,p_step_template=>wwv_flow_imp.id(399317728909126015)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240325181710'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129160280583228921141)
,p_plug_name=>'Alterar senha'
,p_region_css_classes=>'a-bloco'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading js-removeLandmark:t-Form--slimPadding:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(399348451263126044)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'MPD_USUARIO'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(334570990416521297)
,p_plug_name=>'Avatar'
,p_parent_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>360
,p_plug_grid_column_span=>3
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(335154646126453892)
,p_plug_name=>'Campos Pessoal'
,p_parent_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>380
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(171013501432981216)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_GRAVAR'
,p_button_position=>'NEXT'
,p_button_condition=>'P110_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170836657984678509)
,p_name=>'P110_ID_TENANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'ID_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170836738514678510)
,p_name=>'P110_APELIDO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'APELIDO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170836806670678511)
,p_name=>'P110_FOTO'
,p_source_data_type=>'BLOB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(334570990416521297)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'FOTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_css_classes=>'st-radius-100  st-item-center'
,p_tag_attributes=>'style="width: 100px;     height: 100px; display: block!IMPORTANT;"'
,p_grid_row_css_classes=>'st-item-center'
,p_grid_column_css_classes=>'st-item-center'
,p_field_template=>wwv_flow_imp.id(399484433048126127)
,p_item_css_classes=>'st-item-center'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-left-sm'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_04=>'FOTO_NAME'
,p_attribute_07=>'FOTO_MIMETYPE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170836923088678512)
,p_name=>'P110_LOGIN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(335154646126453892)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_prompt=>'mpd_usuario.login_l'
,p_placeholder=>'mpd_usuario.login_i'
,p_source=>'LOGIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'mpd_usuario.login_h'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170836981343678513)
,p_name=>'P110_FORMA_AUTENTICACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'FORMA_AUTENTICACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170837061979678514)
,p_name=>'P110_SITUACAO_CADASTRAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'SITUACAO_CADASTRAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170837245949678515)
,p_name=>'P110_SITUACAO_OPERACIONAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'SITUACAO_OPERACIONAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170837300569678516)
,p_name=>'P110_DATA_ULTIMO_ACESSO'
,p_source_data_type=>'DATE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'DATA_ULTIMO_ACESSO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170837410846678517)
,p_name=>'P110_FUSO_HORARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'FUSO_HORARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170837514971678518)
,p_name=>'P110_ID_IDIOMA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'ID_IDIOMA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170837596150678519)
,p_name=>'P110_ID_TENANT_LOGADO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'ID_TENANT_LOGADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170837745639678520)
,p_name=>'P110_DATA_INCLUSAO'
,p_source_data_type=>'DATE'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171037767249982071)
,p_name=>'P110_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171037955914982072)
,p_name=>'P110_DATA_ALTERACAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171038026341982073)
,p_name=>'P110_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(304953692168729498)
,p_name=>'P110_NOME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'NOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(304953941474729501)
,p_name=>'P110_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(304977539924729543)
,p_name=>'P110_SENHA_CONFIRMAR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(335154646126453892)
,p_prompt=>'Confirmar senha'
,p_display_as=>'PLUGIN_COM.FOS.ADVANCED_PASSWORD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'disabled'
,p_attribute_02=>'collapsible'
,p_attribute_03=>'Excelente senha'
,p_attribute_04=>'require-min-length:require-number:require-spec-char:require-capital-letter:show-pwd-strength-bar:show-caps-lock-on:enable-inline-icons:new-password'
,p_attribute_05=>'7'
,p_attribute_06=>'Deve conter pelo menos #MIN_LENGTH# caracteres.'
,p_attribute_07=>'1'
,p_attribute_08=>unistr('Pelo menos #MIN_NUMS# n\00FAmeros.')
,p_attribute_09=>unistr('?><,./|}[]~\00A7@#$%')
,p_attribute_10=>'2'
,p_attribute_11=>'Pelo menos #MIN_SPEC_CHARS# da lista: #SPEC_CHARS_LIST#'
,p_attribute_12=>'1'
,p_attribute_13=>unistr('Deve conter pelo menos #MIN_CAPS# letras mai\00FAsculas')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(304977604033729544)
,p_name=>'P110_SENHA_ATUAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(335154646126453892)
,p_prompt=>'mpd_usuario.senha_l'
,p_placeholder=>'mpd_usuario.senha_i'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'mpd_usuario.senha_h'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305541085593051953)
,p_name=>'P110_TELEFONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'TELEFONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305541197366051954)
,p_name=>'P110_SENHA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'SENHA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(335204158223454009)
,p_name=>'P110_SENHA_NOVA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(335154646126453892)
,p_prompt=>'Nova senha'
,p_display_as=>'PLUGIN_COM.FOS.ADVANCED_PASSWORD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(148194653122611434)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'disabled'
,p_attribute_02=>'collapsible'
,p_attribute_03=>'Excelente senha'
,p_attribute_04=>'require-min-length:require-number:require-spec-char:require-capital-letter:show-pwd-strength-bar:show-caps-lock-on:enable-inline-icons:new-password'
,p_attribute_05=>'7'
,p_attribute_06=>'Deve conter pelo menos #MIN_LENGTH# caracteres.'
,p_attribute_07=>'1'
,p_attribute_08=>unistr('Pelo menos #MIN_NUMS# n\00FAmeros.')
,p_attribute_09=>unistr('?><,./|}[]~\00A7@#$%')
,p_attribute_10=>'2'
,p_attribute_11=>'Pelo menos #MIN_SPEC_CHARS# da lista: #SPEC_CHARS_LIST#'
,p_attribute_12=>'1'
,p_attribute_13=>unistr('Deve conter pelo menos #MIN_CAPS# letras mai\00FAsculas')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(399752644319432716)
,p_name=>'P110_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_item_source_plug_id=>wwv_flow_imp.id(129160280583228921141)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(171028715359981262)
,p_validation_name=>'P110_SENHA_ATUAL-Valid'
,p_validation_sequence=>10
,p_validation=>'return PKG_API_SEGURANCA.valid_username_and_password(:P110_LOGIN,:P110_SENHA_ATUAL);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_associated_item=>wwv_flow_imp.id(304977604033729544)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(171029154878981263)
,p_validation_name=>'P110_SENHA_CONFIRMAR-Valid not null'
,p_validation_sequence=>20
,p_validation=>'P110_SENHA_CONFIRMAR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Senhas n\00E3o conferem')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(304977539924729543)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(171029521258981264)
,p_validation_name=>'P110_SENHA_CONFIRMAR-Valid match'
,p_validation_sequence=>30
,p_validation=>':P110_SENHA_NOVA = :P110_SENHA_CONFIRMAR'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Senhas n\00E3o conferem')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(304977539924729543)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(171029870321981264)
,p_validation_name=>'P110_SENHA_NOVA-Valid not null'
,p_validation_sequence=>40
,p_validation=>'P110_SENHA_NOVA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Nova senha deve ser informada'
,p_associated_item=>wwv_flow_imp.id(335204158223454009)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(171030621059981266)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Grava senha'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'SAVE_PASSWORD'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(171013501432981216)
,p_internal_uid=>77309262415313296
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171031077067981268)
,p_page_process_id=>wwv_flow_imp.id(171030621059981266)
,p_page_id=>110
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P110_LOGIN'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(171031617397981269)
,p_page_process_id=>wwv_flow_imp.id(171030621059981266)
,p_page_id=>110
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P110_SENHA_NOVA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(171030176729981265)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(171013501432981216)
,p_internal_uid=>77308818085313295
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(171025169218981251)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(129160280583228921141)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Incluir conte\00FAdo')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>77303810574313281
);
wwv_flow_imp.component_end;
end;
/
