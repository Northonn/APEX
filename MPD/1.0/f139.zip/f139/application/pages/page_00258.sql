prompt --application/pages/page_00258
begin
--   Manifest
--     PAGE: 00258
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>258
,p_name=>'Menu - menu'
,p_alias=>'MENU-MENU'
,p_step_title=>'Menu - menu'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>'<script src="#APP_FILES#treeViewOptions#MIN#.js	"></script>'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("h1").append($("#icon_info"));',
'$(document).ready(function() {',
unistr('        // Chama o processo Ajax para adicionar o atributo data-id nos itens da \00E1rvore! '),
'        apex.server.process(',
'        "GET_DATA_ID",',
'        {',
'            //x01: $v(pId) ',
'        },',
'        {',
'            dataType: ''json'', ',
'            success: function(data) {            ',
'                if (data && data.length > 0) {                ',
'                    data.forEach(function(item) {',
'                        var id = item.ID;',
'                        var titulo = item.TITULO;',
'                        var id_nivel_pai = item.ID_NIVEL_PAI; ',
'                        var ordenacao = item.ORDENACAO;                                    ',
'                        ',
'                    // Encontra o elemento HTML correspondente com base no nome do item!',
'                        var elementos = document.querySelectorAll(''.a-TreeView-label'');',
'                        elementos.forEach(function(elemento) {',
'                            if (elemento.textContent.trim() === titulo) {',
'                                elemento.setAttribute(''data-id'', id);',
'                                elemento.setAttribute(''data-id-menu-pai'', id_nivel_pai);',
'                                elemento.setAttribute(''data-ordenacao'', ordenacao);',
'                            }',
'                        });             ',
'                    });',
'                }',
'            },',
'            error: function(xhr, status, error) {            ',
'                //console.error("Erro ao obter dados: " + error);',
'                alert(error);               ',
'                console.log(error);',
'            }',
'        }',
'    );',
'',
unistr('        // Adiciona a classe "PASTA_COM" aos itens e pastas, utilizada para a manipula\00E7\00E3o dos eventos!'),
'        $("#myTree_tree li").addClass("PASTA_COM");',
'        //$(".a-TreeView-node--leaf").addClass("PASTA_COM");              ',
'',
unistr('        // Loop utilizado para adicionar um item vazio indicando que a pasta est\00E1 vazia!'),
'        $(".PASTA_COM").each(function() {',
'            var $folder = $(this);',
'            var $folderContent = $folder.find(".a-TreeView-content");',
'            //if ($folderContent.length > 0 && $folderContent.find(".icon-tree-folder").length > 0) {',
'            var $folderLabel = $folderContent.find(".a-TreeView-label").attr(''data-id-menu-pai'');',
'            if ($folderLabel == null) {',
'                if ($folder.children("ul").length === 0) {',
'                    $(this).children(".a-TreeView-row").after("<span class=''a-TreeView-toggle''></span>");   ',
'                    $(this).append("<ul role=''group'' class=''ui-sortable''><li id=''itemVazio'' role=''none'' class=''noDrag a-TreeView-node a-TreeView-node--leaf  ui-sortable-handle'' style=''font-style: italic; color: lightgray; display: flex; align-items: '
||'center; font-size: var(--a-treeview-node-font-size,12px);''><div role=''none'' class=''noDrag''><span tabindex=''-1'' role=''treeitem'' class=''noDrag a-TreeView-label'' aria-level=''3'' aria-selected=''false''>Pasta vazia</span></div></li></ul>");',
'                    $(this).removeClass("a-TreeView-node--leaf");       ',
'                    $(this).addClass("is-collapsible"); ',
'                }    ',
'            }',
'            /*if ($folderContent.length > 0 && $folderContent.find(".a-TreeView-label").length > 0) {',
'                if ($folder.children("ul").length === 0) {',
'                    $(this).children(".a-TreeView-row").after("<span class=''a-TreeView-toggle''></span>");   ',
'                    $(this).append("<ul role=''group'' class=''ui-sortable''><li id=''itemVazio'' role=''none'' class=''noDrag a-TreeView-node a-TreeView-node--leaf  ui-sortable-handle'' style=''font-style: italic; color: lightgray; display: flex; align-items: '
||'center; font-size: var(--a-treeview-node-font-size,12px);''><div role=''none'' class=''noDrag''><span tabindex=''-1'' role=''treeitem'' class=''noDrag a-TreeView-label'' aria-level=''3'' aria-selected=''false''>Pasta vazia</span></div></li></ul>");',
'                    $(this).removeClass("a-TreeView-node--leaf");       ',
'                    $(this).addClass("is-collapsible"); ',
'                }',
'            }*/',
'        });',
'',
unistr('        // M\00E9todo .sortable() utilizado para tornar os itens e pastas arrast\00E1veis e controlar op\00E7\00F5es de comportamento ao arrast\00E1-los!'),
'        $(".PASTA_COM > ul").sortable({',
'            cursor: "move",',
'            opacity: "0.5",',
'            scroll: "scrollSensitivity",',
'            delay: "150",',
'            cancel: ".noDrag",',
'            connectWith: ".PASTA_COM ul",',
'            receive: function(event, ui) {            ',
'                var draggableItem = ui.item;',
'                draggableItem.removeClass("ITEM_COM ui-draggable ui-draggable-dragging");               ',
'            },',
'            start: function(event, ui) {',
'                ',
unistr('                // Verifica se o item arrastado \00E9 o \00FAltimo filho!'),
'                var temIrmaos = ui.item.siblings().length > 1;',
'                    if (!temIrmaos) {                    ',
unistr('                        // Adiciona o item "Pasta Vazia" se n\00E3o houver outros irm\00E3os!'),
'                        $(this).append("<li id=''itemVazio'' role=''none'' class=''noDrag a-TreeView-node a-TreeView-node--leaf ui-sortable-handle'' style=''font-style: italic; color: lightgray; display: flex; align-items: center; font-size: var(--a-treevie'
||'w-node-font-size,12px);'' draggable=''false''><div role=''none'' class=''noDrag'' draggable=''false''><span tabindex=''-1'' role=''treeitem'' class=''noDrag a-TreeView-label'' aria-level=''3'' aria-selected=''false'' draggable=''false''>Pasta vazia</span></div></li>");',
'                        $(this).removeClass("a-TreeView-node--leaf");',
'                        $(this).addClass("is-collapsible");',
'                    }',
'            },',
'            stop: function(event, ui) {    ',
'                ',
unistr('                // Verifica se o item foi solto em uma pasta vazia e remove marca\00E7\00E3o de pasta vazia!'),
'                var irmaos = ui.item.siblings(''#itemVazio'');',
'                    if (irmaos) {              ',
'                        irmaos.remove();',
'                    }                 ',
'',
unistr('                // Obt\00E9m o ID do item arrastado!'),
'                var itemID = ui.item.find(".a-TreeView-content .a-TreeView-label").attr("data-id");',
'                ',
unistr('                // Verifica se o item movido \00E9 uma pasta!'),
'                //var isPasta = ui.item.find(".a-TreeView-content ul").length > 0;         ',
'                var isPasta = ui.item.find("ul").length > 0;         ',
'                console.log(isPasta);               ',
'                var paiAtual = ui.item.find(".a-TreeView-content .a-TreeView-label").attr("data-id-menu-pai");',
'                console.log(''Pai atual:'' + paiAtual);                ',
unistr('                // Obt\00E9m o id do novo pai!'),
'                var novoPaiID;',
'                    if (isPasta) {',
'                        pastaMoved = ui.item.parent();                        ',
'                        paiPastaMoved = pastaMoved.parent();',
'                        novoPaiID = paiPastaMoved.closest("li:has(.a-TreeView-toggle)").find(".a-TreeView-label").not(this).attr("data-id");                   ',
'                            if (!novoPaiID) {',
'                                novoPaiID = $("#myTree_tree_0 .a-TreeView-content").find(".a-TreeView-label").attr("data-id");',
'                            }',
'                    } else {',
'                        novoPaiID = ui.item.closest("li:has(.a-TreeView-toggle)").find(".a-TreeView-label").attr("data-id");                    ',
'                            if (!novoPaiID) {',
'                                novoPaiID = $("#myTree_tree_0 .a-TreeView-content").find(".a-TreeView-label").attr("data-id");',
'                            }',
'                    }',
'                console.log(''Novo pai:'' + novoPaiID);',
'                //inicio',
'                var ordemAtual = ui.item.find(".a-TreeView-content .a-TreeView-label").attr("data-ordenacao");',
'                ',
'                var novaOrdem;',
unistr('                // Encontre o irm\00E3o mais pr\00F3ximo do elemento solto'),
'                var siblingItem = ui.item.prev();',
'',
unistr('                // Verifique se h\00E1 um irm\00E3o anterior'),
'                if (siblingItem.length > 0) {',
unistr('                    // Obtenha o valor do atributo data-ordenacao do irm\00E3o mais pr\00F3ximo'),
'                    var ordenacaoIrmao = siblingItem.find(''.a-TreeView-label'').attr(''data-ordenacao'');',
'',
unistr('                    // Fa\00E7a o que voc\00EA quiser com o valor obtido'),
unistr('                    console.log(''O valor de data-ordenacao do irm\00E3o mais pr\00F3ximo \00E9:'', ordenacaoIrmao);'),
'                    novaOrdem = ordenacaoIrmao;',
unistr('                    // Aqui voc\00EA pode chamar um processo para atualizar a ordena\00E7\00E3o no banco de dados, passando ordenacaoIrmao como par\00E2metro'),
'                } else {',
unistr('                    // Se n\00E3o houver irm\00E3o anterior, tentamos pegar o pr\00F3ximo irm\00E3o'),
'                    /*var nextSiblingItem = ui.item.next();',
'                    if (nextSiblingItem.length > 0) {*/',
unistr('                        // Obtenha o valor do atributo data-ordenacao do pr\00F3ximo irm\00E3o'),
'                        var ordenacaoIrmao = 0; //nextSiblingItem.find(''.a-TreeView-label'').attr(''data-ordenacao'');',
'',
unistr('                        // Fa\00E7a o que voc\00EA quiser com o valor obtido'),
unistr('                        console.log(''O valor de data-ordenacao do pr\00F3ximo irm\00E3o \00E9:'', ordenacaoIrmao);'),
'                        novaOrdem = ordenacaoIrmao;',
unistr('                        // Aqui voc\00EA pode chamar um processo para atualizar a ordena\00E7\00E3o no banco de dados, passando ordenacaoIrmao como par\00E2metro'),
'                    /*} else {',
unistr('                        console.log(''N\00E3o h\00E1 irm\00E3o anterior ou pr\00F3ximo para obter o valor de data-ordenacao.'');'),
'                        novaOrdem = 1;',
'                    }*/',
'                }',
'                //fim',
'',
'                ',
'                // Chama o processo Ajax para atualizar a coluna PASTA_PAI!',
'                apex.server.process(',
'                    "ATUALIZAR_PASTA_PAI", ',
'                    {',
'                        x01: itemID,',
'                        x02: paiAtual,',
'                        x03: novoPaiID,',
'                        x04: ordemAtual,',
'                        x05: novaOrdem',
'                    },',
'                    {',
'                        dataType: ''json'', ',
'                        success: function(data) {                            ',
'                            //apex.region("myTree").refresh();',
'                            location.reload();',
'                            apex.region("LISTA").refresh();',
unistr('                            //console.log("Rela\00E7\00E3o ''PASTA_PAI'' atualizada com sucesso.");'),
'                        },',
'                        error: function(xhr, status, error) {                            ',
unistr('                            //console.error("Erro ao atualizar a rela\00E7\00E3o ''PASTA_PAI'': " + error);'),
'                            alert("Erro ao atualizar hirarquia, tente novamente!");',
'                        }',
'                    }',
'                );       ',
'            }        ',
'        });',
'    });    '))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'24'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240503015444'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(242178282723398623)
,p_plug_name=>unistr('\00C1rvore')
,p_region_name=>'myTree'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>3
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       ID_NIVEL_PAI,',
'       TITULO,',
'       ORDENACAO,',
'       ID_USUARIO_INCLUIU,',
'       DATA_INCLUSAO,',
'       ID_USUARIO_ALTEROU,',
'       DATA_ALTERACAO,',
'       ICONE',
'  from MPD_MENU',
'  order by ORDENACAO'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_attribute_02=>'D'
,p_attribute_04=>'DB'
,p_attribute_08=>'a-Icon'
,p_attribute_09=>'icon-tree-folder'
,p_attribute_10=>'TITULO'
,p_attribute_12=>'ICONE'
,p_attribute_13=>'ID'
,p_attribute_14=>'ID_NIVEL_PAI'
,p_attribute_16=>'NULL'
,p_attribute_20=>'ID'
,p_attribute_21=>'f?p=&APP_ID.:258:&SESSION.::&DEBUG.:258:P258_SEARCH:&TITULO.'
,p_attribute_22=>'TITULO'
,p_attribute_23=>'SQL'
,p_attribute_25=>'ORDENACAO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(549865398529634802)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399360774253126052)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    A.ID,',
'    A.ID_NIVEL_PAI,',
'    A.TITULO,',
'    A.ORDENACAO,   ',
'    A.ID_USUARIO_INCLUIU,',
'    A.DATA_INCLUSAO,',
'    A.ID_USUARIO_ALTEROU,',
'    A.DATA_ALTERACAO,',
'    A.ICONE,    ',
'    CASE WHEN ID_NIVEL_PAI IN (SELECT ID FROM MPD_MENU WHERE ID = A.ID_NIVEL_PAI) THEN',
'        ''''||(select titulo from mpd_menu where id = A.ID_NIVEL_PAI)',
'    ELSE',
'        ''RAIZ''',
'    END AS SUBTITLE',
'    /*CASE WHEN B.ID_FUNCIONALIDADE IN (SELECT ID FROM MPD_FUNCIONALIDADE WHERE ID = B.ID_FUNCIONALIDADE) THEN',
'        PKG_COMPONENTES.html_card_colunas(',
'                ''srv_artefato.titulo_artefato'',',
'                ''''||(SELECT ART.TITULO_ARTEFATO FROM SRV_ARTEFATO ART WHERE ART.ID = B.ID_ARTEFATO_VERSIONADO)                    ',
'            ) ',
'    ELSE',
'        NULL',
'    END AS atributo1*/',
'FROM MPD_MENU A ',
'LEFT OUTER JOIN MPD_MENU_ACAO B',
'ON B.ID_MENU = A.ID',
'ORDER BY A.ID_NIVEL_PAI, TITULO',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(172008584114569755)
,p_region_id=>wwv_flow_imp.id(549865398529634802)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITULO'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'SUBTITLE'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.    ',
'</div>'))
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICONE'
,p_icon_position=>'START'
,p_badge_column_name=>'ORDENACAO'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(172009626950569761)
,p_card_id=>wwv_flow_imp.id(172008584114569755)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:264:&SESSION.::&DEBUG.:264:P264_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(172009052135569759)
,p_card_id=>wwv_flow_imp.id(172008584114569755)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>50
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:260:&SESSION.::&DEBUG.:260:P260_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(81139491502899440411)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399401848107126074)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(399316930599126008)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(399488615370126132)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(422863177986166558)
,p_plug_name=>'Pesquisa'
,p_parent_plug_id=>wwv_flow_imp.id(81139491502899440411)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SMART_FILTERS'
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(549865398529634802)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172011271255569769)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(81139491502899440411)
,p_button_name=>'BTN_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:259:&SESSION.::&DEBUG.:259::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(242377721794116601)
,p_name=>'P258_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(422863177986166558)
,p_prompt=>'Search'
,p_placeholder=>'Buscar por mpd_menu.titulo_l'
,p_source=>'TITULO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172014112823569786)
,p_name=>'onClosedLista'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(549865398529634802)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172014656645569789)
,p_event_id=>wwv_flow_imp.id(172014112823569786)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(549865398529634802)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172015098870569791)
,p_event_id=>wwv_flow_imp.id(172014112823569786)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(422863177986166558)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172015569186569792)
,p_event_id=>wwv_flow_imp.id(172014112823569786)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window.location.reload();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172018793181569799)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>100
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172019314466569801)
,p_event_id=>wwv_flow_imp.id(172018793181569799)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172016007444569793)
,p_name=>'onClosedNOVO'
,p_event_sequence=>330
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(172011271255569769)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172016495111569794)
,p_event_id=>wwv_flow_imp.id(172016007444569793)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(549865398529634802)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172017052513569795)
,p_event_id=>wwv_flow_imp.id(172016007444569793)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(422863177986166558)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172017552918569796)
,p_event_id=>wwv_flow_imp.id(172016007444569793)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.location.reload();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172017889464569797)
,p_name=>'onPageLoad'
,p_event_sequence=>340
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172018406074569798)
,p_event_id=>wwv_flow_imp.id(172017889464569797)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242178282723398623)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(172012895164569780)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA_ID'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json_data CLOB;',
'BEGIN',
'    SELECT JSON_ARRAYAGG(',
'               JSON_OBJECT(''ID'' VALUE ID, ''TITULO'' VALUE TITULO, ''ID_NIVEL_PAI'' VALUE ID_NIVEL_PAI, ''ORDENACAO'' VALUE ORDENACAO)',
'           )',
'    INTO l_json_data',
'    FROM MPD_MENU;',
'    --WHERE ID_MENU_PAI = apex_application.g_x01;',
'',
'    IF l_json_data IS NULL THEN',
unistr('        -- Se n\00E3o houver dados, retorne um JSON vazio'),
'        l_json_data := ''[]'';',
'    END IF;',
'',
'    -- Retorne o JSON contendo os valores',
'    htp.p(l_json_data);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>78291536519901810
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(172013746338569783)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ATUALIZAR_PASTA_PAI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare  ',
'    v_id            number := apex_application.g_x01;',
'    v_pai_atual     number := apex_application.g_x02;',
'    v_novo_pai      number := apex_application.g_x03;',
'    v_ordem_atual   number := apex_application.g_x04; ',
'    v_nova_ordem    number := apex_application.g_x05;',
'    v_count         number := 0;',
'begin ',
'    if v_novo_pai = v_pai_atual then',
'        ',
'        if v_nova_ordem = v_ordem_atual then',
'            NULL;',
'        ',
'        elsif v_nova_ordem = 0 then',
'            ',
'            update mpd_menu',
'            set ordenacao = 1,',
'                id_usuario_alterou = pkg_util.retorna_id_usuario_logado,',
'                data_alteracao = sysdate',
'            where id = v_id;',
'',
'            update mpd_menu',
'            set ordenacao = ordenacao + 1,',
'                id_usuario_alterou = pkg_util.retorna_id_usuario_logado,',
'                data_alteracao = sysdate',
'            where id_nivel_pai = v_novo_pai',
'            and ordenacao > v_nova_ordem',
'            and ordenacao <= v_ordem_atual',
'            and id <> v_id;',
'                ',
'        elsif v_nova_ordem <> 0 and v_nova_ordem < v_ordem_atual then',
'',
'            update mpd_menu',
'            set ordenacao = v_nova_ordem + 1,',
'                id_usuario_alterou = pkg_util.retorna_id_usuario_logado,',
'                data_alteracao = sysdate',
'            where id = v_id;',
'',
'            update mpd_menu',
'            set ordenacao = ordenacao + 1,',
'                id_usuario_alterou = pkg_util.retorna_id_usuario_logado,',
'                data_alteracao = sysdate',
'            where id_nivel_pai = v_novo_pai',
'            and ordenacao > v_nova_ordem',
'            and ordenacao <= v_ordem_atual ',
'            and id <> v_id;',
'                ',
'        elsif v_nova_ordem > v_ordem_atual then',
'',
'            update mpd_menu',
'            set ordenacao = v_nova_ordem, ',
'                id_usuario_alterou = pkg_util.retorna_id_usuario_logado,',
'                data_alteracao = sysdate',
'            where id = v_id;',
'',
'            update mpd_menu',
'            set ordenacao = ordenacao - 1',
'            where id_nivel_pai = v_novo_pai',
'            and ordenacao <= v_nova_ordem',
'            and ordenacao > v_ordem_atual ',
'            and id <> v_id;',
'',
'        end if;',
'',
'    elsif v_novo_pai <> v_pai_atual then',
'        update mpd_menu ',
'        set ordenacao = ordenacao - 1',
'        where id_nivel_pai = v_pai_atual',
'        and ordenacao > v_ordem_atual;',
'',
'        update mpd_menu ',
'        set ordenacao = v_nova_ordem + 1,',
'        id_nivel_pai = v_novo_pai',
'        where id = v_id;',
'',
'        update mpd_menu',
'        set ordenacao = ordenacao + 1',
'        where id_nivel_pai = v_novo_pai',
'        and ordenacao > v_nova_ordem',
'        and id <> v_id;',
'',
'    end if;',
'/*',
unistr('    -- Calcular a nova ordem com base na escolha do usu\00E1rio'),
'    IF v_nova_ordem < v_ordem_atual THEN',
'        -- Se a nova ordem for menor que a ordem atual, deslocar para cima',
'        UPDATE mpd_menu',
'        SET ordenacao = ordenacao + 1',
'        WHERE id_menu_pai = v_pai_atual',
'        AND ordenacao >= v_nova_ordem',
'        AND ordenacao < v_ordem_atual;',
'    ELSIF v_nova_ordem > v_ordem_atual THEN',
'        -- Se a nova ordem for maior que a ordem atual, deslocar para baixo',
'        UPDATE mpd_menu',
'        SET ordenacao = ordenacao - 1',
'        WHERE id_menu_pai = v_pai_atual',
'        AND ordenacao <= v_nova_ordem',
'        AND ordenacao > v_ordem_atual;',
'    END IF;',
'',
'    -- Atualizar a ordem e o novo pai do item movido',
'    UPDATE mpd_menu',
'    SET ordenacao = v_nova_ordem, id_menu_pai = v_novo_pai',
'    WHERE id = v_id;',
'',
unistr('    -- Atualizar os novos pais dos descendentes, se necess\00E1rio'),
'    IF v_novo_pai != v_pai_atual THEN',
'        UPDATE mpd_menu',
'        SET id_menu_pai = v_novo_pai',
'        WHERE id_menu_pai = v_pai_atual',
'        AND id = v_id;',
'    END IF;',
'    */',
'     -- Configurar a resposta JSON vazia',
'    htp.init;',
'    htp.p(''{}''); -- Resposta JSON vazia',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>78292387693901813
);
wwv_flow_imp.component_end;
end;
/
