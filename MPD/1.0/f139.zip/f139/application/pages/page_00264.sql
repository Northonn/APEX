prompt --application/pages/page_00264
begin
--   Manifest
--     PAGE: 00264
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>264
,p_name=>'Menu - Mais detalhes do menu'
,p_alias=>'MENU-MAIS-DETALHES-DO-MENU'
,p_step_title=>'Menu - Mais detalhes do menu'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'$("h1").append($("#icon_info"));',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'a {',
'    font-size: 16px;',
'    font-weight: 100;',
'}',
'',
'.t-Body-side{',
'    width: auto;',
'    box-shadow: none;',
'    max-width: 450px;',
'}',
'',
'.t-Region{',
'    border: none;',
'}',
'',
'h5{',
'    margin-top: 0px;',
'    margin-bottom: 0px;',
'    font-weight: bold;',
'}',
'',
'a {',
'    font-size: 12px;',
'    font-weight: normal;',
'}'))
,p_step_template=>wwv_flow_imp.id(399320668930126028)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'LEONARDO'
,p_last_upd_yyyymmddhh24miss=>'20240325184100'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(171574360031544888)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399401848107126074)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(399316930599126008)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(399488615370126132)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(460369264526837479)
,p_plug_name=>'Dados gerais'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody:margin-top-md:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399362722590126053)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin   ',
'    Htp.p(''<div class="a-bloco" id="BLOCO2">'');',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_MENU.TITULO_L'',''fa-hardware'',:P264_TITULO));',
'    --Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_MENU.ID_FUNCIONALIDADE_L'',''fa-code-fork'',:P264_ID_FUNCIONALIDADE));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_MENU.ID_NIVEL_PAI_L'',''fa-tree-org'',:P264_TITULO_MENU));    ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_MENU.ICONE_L'',:P264_ICONE,:P264_ICONE));    ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_MENU.ORDENACAO_L'',''fa-sort-amount-desc-alt'',:P264_ORDENACAO,'''',''S''));   ',
'    Htp.p(''</div>'');',
'End;',
'',
'       '))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(598756344485152679)
,p_plug_name=>unistr('A\00E7\00F5es')
,p_region_name=>'PAINEL3'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody:margin-top-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(399362722590126053)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_08'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54100467930517797996)
,p_plug_name=>unistr('A\00E7\00F5es')
,p_region_name=>'BTN_EDIT_ACOES'
,p_parent_plug_id=>wwv_flow_imp.id(598756344485152679)
,p_region_template_options=>'#DEFAULT#:margin-left-md:margin-right-md'
,p_plug_template=>wwv_flow_imp.id(399387215821126066)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,      ',
'       ID_MENU,',
'       ORDENACAO,',
'       ID_FUNCIONALIDADE',
'  from MPD_MENU_ACAO',
' where ID_MENU = :P264_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P264_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Rela\00E7\00E3o dos assuntos a serem apresentados no tutorial')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(643597694582483262)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'NORTHONN'
,p_internal_uid=>549876335937815292
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554026031922635056)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(242325988516828459)
,p_db_column_name=>'ID_MENU'
,p_display_order=>30
,p_column_identifier=>'AF'
,p_column_label=>'SRV_MENU_ACAO.ID_MENU_L'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171574257847544886)
,p_db_column_name=>'ID_FUNCIONALIDADE'
,p_display_order=>40
,p_column_identifier=>'AK'
,p_column_label=>'Id Funcionalidade'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(242326191165828461)
,p_db_column_name=>'ORDENACAO'
,p_display_order=>50
,p_column_identifier=>'AH'
,p_column_label=>'SRV_MENU_ACAO.ORDENACAO_L'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(643671808989053826)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'448217'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_MENU:ORDENACAO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54021795446956582841)
,p_plug_name=>'Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399387215821126066)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select A.ID,      ',
'       ID_NIVEL_PAI,',
'       TITULO,',
'       ORDENACAO,',
'       ICONE,',
'       CASE WHEN ID_NIVEL_PAI IN (SELECT ID FROM MPD_MENU WHERE ID = A.ID_NIVEL_PAI) THEN',
'            ''''||(select titulo from mpd_menu where id = A.ID_NIVEL_PAI)',
'        ELSE',
'            ''RAIZ''',
'        END AS TITULO_MENU',
'  from MPD_MENU A',
'  where ID = :P264_ID'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172163558492999563)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(598756344485152679)
,p_button_name=>'EDIT_ACOES'
,p_button_static_id=>'BTN_EDIT_ASSUNTO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--gapRight'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_EDITAR'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:261:&SESSION.::&DEBUG.:261:P261_ID:&P264_ID.'
,p_icon_css_classes=>'ico-edit-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172169106062999594)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(460369264526837479)
,p_button_name=>'EDIT'
,p_button_static_id=>'BTN_EDIT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_EDITAR'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:259:&SESSION.::&DEBUG.:259:P259_ID,P259_EDITAR:&P264_ID.,1'
,p_icon_css_classes=>'ico-edit-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172168312724999592)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(460369264526837479)
,p_button_name=>'COPY'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_COPIAR'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:259:&SESSION.::&DEBUG.:259:P259_ID,P259_DUPLICAR:&P264_ID.,1'
,p_icon_css_classes=>'ico-copy-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172168748162999593)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(460369264526837479)
,p_button_name=>'EXCLUIR'
,p_button_static_id=>'BTN_DELETE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_EXCLUIR'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:263:&SESSION.::&DEBUG.:263:P263_ID:&P264_ID.'
,p_icon_css_classes=>'ico-trash-sm'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171574261370544887)
,p_name=>'P264_ID_NIVEL_PAI'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_item_source_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_source=>'ID_NIVEL_PAI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(242327058693828467)
,p_name=>'P264_TITULO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_item_source_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_source=>'TITULO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(242327204903828468)
,p_name=>'P264_ORDENACAO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_item_source_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_source=>'ORDENACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(242327257719828469)
,p_name=>'P264_ICONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_item_source_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_source=>'ICONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(249368717554050343)
,p_name=>'P264_TITULO_MENU'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_item_source_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_source=>'TITULO_MENU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(554012716439635078)
,p_name=>'P264_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_item_source_plug_id=>wwv_flow_imp.id(54021795446956582841)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172172243277999601)
,p_name=>'onDialogClosedEDIT'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#BTN_EDIT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172172720999999602)
,p_event_id=>wwv_flow_imp.id(172172243277999601)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'document.location.reload(true);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172173121173999603)
,p_name=>'onDialogClosedDELETEExecute'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#BTN_DELETE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172173591817999605)
,p_event_id=>wwv_flow_imp.id(172173121173999603)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'history.back()'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172176206308999610)
,p_name=>'onDialogClosedEDIT_ACOES'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#BTN_EDIT_ACOES'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172176717882999611)
,p_event_id=>wwv_flow_imp.id(172176206308999610)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54100467930517797996)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172174457720999606)
,p_name=>'onCustomCloseDialog'
,p_event_sequence=>50
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'customDialogClose'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172174928458999608)
,p_event_id=>wwv_flow_imp.id(172174457720999606)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lSpinner$ = apex.util.showSpinner( $( "#HISTORICO" ) );',
'',
'setTimeout(',
'    function() {',
'      apex.region("HISTORICO").refresh();  ',
'      lSpinner$.remove();',
'    }, 500);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172175268857999608)
,p_name=>'onAfterRefreshVersoes'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(54100467930517797996)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172175776029999610)
,p_event_id=>wwv_flow_imp.id(172175268857999608)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#HISTORICO").appendTo("#PAINEL" );',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172170387825999597)
,p_name=>unistr('onDialogClosedA\00C7\00D5ES')
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(598756344485152679)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172170915130999598)
,p_event_id=>wwv_flow_imp.id(172170387825999597)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'document.location.reload(true);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(172171308574999599)
,p_name=>'onDialogClosedEDIT_ACOES_1'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(172163558492999563)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(172171828102999600)
,p_event_id=>wwv_flow_imp.id(172171308574999599)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'document.location.reload(true);'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(172162799981999561)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(54021795446956582841)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Mais detalhes do tutorial'
,p_internal_uid=>78441441337331591
);
wwv_flow_imp.component_end;
end;
/
