prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>unistr('T100 - \201CTenant\201D')
,p_alias=>'T100-TENANT'
,p_step_title=>'Tenant'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(399320668930126028)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'22'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240502235947'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(170665259014400070)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399401848107126074)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(399316930599126008)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(399488615370126132)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(170665930918400072)
,p_plug_name=>'Lista'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399360774253126052)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    id,',
'    razao_social,',
'    to_char(inscricao_federal) as inscricao_federaltc,',
'    autenticacao_mfa_ativa,',
'    numero_licenca_uso,',
'    qtd_maxima_tentativa_login,',
'    forma_autenticacao,',
'    situacao_tenant,',
'    pkg_util.dominio_retorna_tag(''mpd_tenant'',''situacao_tenant'',situacao_tenant) as ds_situacao,',
'    to_char(data_inclusao) as data_inclusaotc,',
'    pkg_componentes.html_card_colunas(',
'        ''mpd_tenant.numero_licenca_uso_l'',',
'        numero_licenca_uso',
'    ) as atributo1,    ',
'    pkg_componentes.html_card_colunas(',
'        ''mpd_tenant.autenticacao_mfa_ativa_l'',',
'        pkg_util.dominio_retorna_tag(''mpd_tenant'',''autenticacao_mfa_ativa'',autenticacao_mfa_ativa)',
'    ) as atributo2,  ',
'    pkg_componentes.html_card_colunas(',
'        ''mpd_tenant.data_inclusao_l'',',
'        data_inclusao',
'    ) as atributo3    ',
'from mpd_tenant;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(170666397049400075)
,p_region_id=>wwv_flow_imp.id(170665930918400072)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'RAZAO_SOCIAL'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'INSCRICAO_FEDERALTC'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.',
'    &ATRIBUTO3!RAW.',
'</div>'))
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'DS_SITUACAO'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(170346170834714420)
,p_card_id=>wwv_flow_imp.id(170666397049400075)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:102:P102_ID,P102_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(170780643479579271)
,p_card_id=>wwv_flow_imp.id(170666397049400075)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.::P101_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(171213111643043900)
,p_plug_name=>'Pesquisa facetada'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-left-sm'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(170665930918400072)
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(170781437622579279)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(170665259014400070)
,p_button_name=>'SHOW_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_image_alt=>'Mostrar filtro'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter  fam-x fam-is-danger'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(170781131209579276)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(170665259014400070)
,p_button_name=>'HIDE_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_image_alt=>'Esconder filtro'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(171210449035043873)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(170665259014400070)
,p_button_name=>'SHOW_GRID'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_image_alt=>'Visualizar em grade'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-cards'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(171210731695043876)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(170665259014400070)
,p_button_name=>'SHOW_ROW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_image_alt=>'Visualizar em linhas'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-media-list'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(170781040981579275)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(170665259014400070)
,p_button_name=>'BTN_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:102::'
,p_button_cattributes=>'style="display: inline-flex;"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171213202839043901)
,p_name=>'P100_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(171213111643043900)
,p_prompt=>'Search'
,p_placeholder=>unistr('Pesquise por raz\00E3o social, I.F ou Data de inclus\00E3o')
,p_source=>'RAZAO_SOCIAL,INSCRICAO_FEDERALTC,DATA_INCLUSAOTC'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171213337595043902)
,p_name=>'P100_NEW'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(171213111643043900)
,p_prompt=>unistr('Situa\00E7\00E3o')
,p_source=>'SITUACAO_TENANT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Ativo;A,Bloqueado;B,Cancelado;C'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(170781203210579277)
,p_name=>'onClickHIDE_SEARCH'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(170781131209579276)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170781708654579282)
,p_event_id=>wwv_flow_imp.id(170781203210579277)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side'').hide();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170781329634579278)
,p_event_id=>wwv_flow_imp.id(170781203210579277)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(170781437622579279)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170781820298579283)
,p_event_id=>wwv_flow_imp.id(170781203210579277)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(170781131209579276)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(170781555079579280)
,p_name=>'onClickSHOW_SEARCH'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(170781437622579279)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170781910045579284)
,p_event_id=>wwv_flow_imp.id(170781555079579280)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#t_Body_side''). show();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170782049216579285)
,p_event_id=>wwv_flow_imp.id(170781555079579280)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(170781131209579276)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170781612238579281)
,p_event_id=>wwv_flow_imp.id(170781555079579280)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(170781437622579279)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(171210541466043874)
,p_name=>'onClickSHOW_GRID'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(171210449035043873)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171210779922043877)
,p_event_id=>wwv_flow_imp.id(171210541466043874)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(171210731695043876)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171210889257043878)
,p_event_id=>wwv_flow_imp.id(171210541466043874)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(170665930918400072)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171211035471043879)
,p_event_id=>wwv_flow_imp.id(171210541466043874)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(171210449035043873)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171213768136043907)
,p_event_id=>wwv_flow_imp.id(171210541466043874)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(171213111643043900)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(171211091666043880)
,p_name=>'onClickSHOW_ROW'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(171210731695043876)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171211165513043881)
,p_event_id=>wwv_flow_imp.id(171211091666043880)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(171210449035043873)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171211286876043882)
,p_event_id=>wwv_flow_imp.id(171211091666043880)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(170665930918400072)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171213881535043908)
,p_event_id=>wwv_flow_imp.id(171211091666043880)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(171213111643043900)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171211497079043884)
,p_event_id=>wwv_flow_imp.id(171211091666043880)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(171210731695043876)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(173592059574294596)
,p_name=>'onDialogClosedLista'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(170665930918400072)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(173592169126294597)
,p_event_id=>wwv_flow_imp.id(173592059574294596)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(170665930918400072)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(171202264133044287)
,p_name=>'onDialogClosedBTN_NOVO'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(170781040981579275)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171202426431044288)
,p_event_id=>wwv_flow_imp.id(171202264133044287)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(170665930918400072)
);
wwv_flow_imp.component_end;
end;
/
