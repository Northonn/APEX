prompt --application/pages/page_00172
begin
--   Manifest
--     PAGE: 00172
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>172
,p_name=>unistr('Cadastro compartilhado - Op\00E7\00F5es')
,p_alias=>unistr('CADASTRO-COMPARTILHADO-OP\00C7\00D5ES')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Op\00E7\00F5es')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(399317728909126015)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240304135338'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234944713326976565)
,p_plug_name=>unistr('A\00E7\00F5es')
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(399348451263126044)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234944976932976567)
,p_plug_name=>unistr('Navega\00E7\00E3o')
,p_parent_plug_id=>wwv_flow_imp.id(234944713326976565)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(168677201150968084)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(168234608284393608)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(277001277525989057)
,p_plug_name=>unistr('A\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(234944713326976565)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(399468376163126114)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168672114142595259)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(234944713326976565)
,p_button_name=>'BTN_EDITAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_image_alt=>'BTN_EDITAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:159:&SESSION.::&DEBUG.:159:P159_ID:&P172_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168671690662595258)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(234944713326976565)
,p_button_name=>'BTN_DUPLICAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_image_alt=>'BTN_DUPLICAR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:159:&SESSION.::&DEBUG.:159:P159_COPIAR:&P172_ID.'
,p_button_css_classes=>'border-radius-100 is-disabled'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168671309533595255)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(234944713326976565)
,p_button_name=>'BTN_EXCLUIR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(399486228372126129)
,p_button_image_alt=>'BTN_EXCLUIR'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:173:&SESSION.::&DEBUG.:173:P173_ID:&P172_ID.'
,p_button_css_classes=>'border-radius-100'
,p_icon_css_classes=>'fa-trash '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234948454520976626)
,p_name=>'P172_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(234944713326976565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
