prompt --application/pages/page_00105
begin
--   Manifest
--     PAGE: 00105
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>105
,p_name=>unistr('Usu\00E1rios - Usu\00E1rios')
,p_alias=>unistr('USU\00C1RIOS-USU\00C1RIOS')
,p_step_title=>unistr('Usu\00E1rios')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("h1").append($("#icon_info"));',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'24'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240503125029'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(247670699527203368)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399401848107126074)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(399316930599126008)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(399488615370126132)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(301147178484286361)
,p_plug_name=>'Pesquisa'
,p_parent_plug_id=>wwv_flow_imp.id(247670699527203368)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-top-sm'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SMART_FILTERS'
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(428149399027754605)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(428149399027754605)
,p_plug_name=>unistr('Lista de usu\00E1rios')
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(399360774253126052)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       login,',
'       nome,',
'       email,       ',
'       situacao_cadastral,',
'       telefone,',
'       foto,       ',
'       pkg_util.dominio_retorna_tag(''mpd_usuario'',''situacao_cadastral'',situacao_cadastral) as situacaocadastral,',
'       pkg_componentes.html_card_colunas(',
'           ''mpd_usuario.nome_l'',',
'           nome',
'       ) as atributo1,',
'       pkg_componentes.html_card_colunas(',
'           ''mpd_usuario.telefone_l'',',
'           telefone',
'       ) as atributo2,',
'       pkg_componentes.html_card_colunas(',
'           ''mpd_usuario.email_l'',',
'           email',
'       ) as atributo3,',
'       case when id in (select id_usuario from mpd_usuario_papel) then',
'           pkg_componentes.html_card_colunas(',
'               ''mpd_papel.nome_papel_l'',',
'                (select listagg(nome_papel,'', '') from mpd_papel where id in (select id_papel_usuario from mpd_usuario_papel where id_usuario = a.id)) ',
'           )',
'       else ',
'            null ',
'       end as atributo4',
'from mpd_usuario a'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(170672618151407250)
,p_region_id=>wwv_flow_imp.id(428149399027754605)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'LOGIN'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'    &ATRIBUTO2!RAW.    ',
'    &ATRIBUTO3!RAW.    ',
'    &ATRIBUTO4!RAW.    ',
'</div>'))
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'BLOB'
,p_icon_blob_column_name=>'FOTO'
,p_icon_position=>'START'
,p_icon_description=>'&NOME_SISTEMA.'
,p_badge_column_name=>'SITUACAOCADASTRAL'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(170673134074407252)
,p_card_id=>wwv_flow_imp.id(170672618151407250)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'BTN_VISUALIZAR'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:106:P106_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(170673706960407253)
,p_card_id=>wwv_flow_imp.id(170672618151407250)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>50
,p_label=>'BTN_OPCAO'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:112:P112_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link t-Button--large padding-none'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(170678588262407269)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(247670699527203368)
,p_button_name=>'BTN_NOVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--padRight'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'BTN_NOVO'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.:107::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(164584736574021903)
,p_name=>'P105_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(301147178484286361)
,p_prompt=>'Search'
,p_placeholder=>'Busca por MPD_USUARIO.LOGIN_L, MPD_USUARIO.NOME_L  ou MPD_USUARIO.EMAIL_L'
,p_source=>'LOGIN,NOME,EMAIL'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(164584785861021904)
,p_name=>'P105_SITUACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(301147178484286361)
,p_prompt=>unistr('Situa\00E7\00E3o')
,p_source=>'SITUACAO_CADASTRAL'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'D_MPD_USUARIO_TENANT.SITUACAO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from pkg_util.dominio_retorna_lista(''mpd_usuario_tenant'',''situacao'')',
''))
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_toggleable=>false
,p_suggestions_type=>'DYNAMIC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(170681010764407279)
,p_name=>'onDialogClosedLISTA'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(428149399027754605)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170681443799407282)
,p_event_id=>wwv_flow_imp.id(170681010764407279)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(428149399027754605)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170681920344407283)
,p_event_id=>wwv_flow_imp.id(170681010764407279)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(301147178484286361)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(170682324706407283)
,p_name=>'onMouseEnter'
,p_event_sequence=>100
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170682790510407285)
,p_event_id=>wwv_flow_imp.id(170682324706407283)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(170699245035407318)
,p_name=>'onDialogClosedBTN_NOVO'
,p_event_sequence=>330
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(170678588262407269)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170699743342407319)
,p_event_id=>wwv_flow_imp.id(170699245035407318)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(428149399027754605)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170700198618407320)
,p_event_id=>wwv_flow_imp.id(170699245035407318)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(301147178484286361)
);
wwv_flow_imp.component_end;
end;
/
