prompt --application/pages/page_09994
begin
--   Manifest
--     PAGE: 09994
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9994
,p_name=>unistr('Confirma\00E7\00E3o de cadastro de usu\00E1rio')
,p_alias=>unistr('CONFIRMA\00C7\00C3O-DE-CADASTRO-DE-USU\00C1RIO')
,p_step_title=>unistr('Confirma\00E7\00E3o de cadastro de usu\00E1rio')
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(280719082211191960)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Login-logo{',
'    border-radius: 100px;',
'}',
'',
'',
''))
,p_step_template=>wwv_flow_imp.id(399342888283126040)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'SRV-LAB'
,p_last_upd_yyyymmddhh24miss=>'20230811201923'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(616795126052591891)
,p_plug_name=>'Cadastro confirmado'
,p_icon_css_classes=>'fa-check-circle'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(399431308717126088)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(512056659894200883)
,p_plug_name=>'Sucesso'
,p_parent_plug_id=>wwv_flow_imp.id(616795126052591891)
,p_region_css_classes=>'st-back-transp'
,p_icon_css_classes=>'fa-check-circle'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--success:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(399348451263126044)
,p_plug_display_sequence=>10
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9994_CONFIRMA_CADASTRO'
,p_plug_display_when_cond2=>'ok'
,p_plug_header=>unistr('<div class="st-titulo-login">Seja bem-vindo(a) \00E0 nossa plataforma! Estamos muito felizes em t\00EA-lo(a) como nosso novo usu\00E1rio.</div>')
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(512056794662200884)
,p_plug_name=>'Erro'
,p_parent_plug_id=>wwv_flow_imp.id(616795126052591891)
,p_region_css_classes=>'st-back-transp'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(399348451263126044)
,p_plug_display_sequence=>20
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9994_CONFIRMA_CADASTRO'
,p_plug_display_when_cond2=>'er'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<div class="st-titulo-login">N\00E3o foi p\00F3ssivel realizar a confirma\00E7\00E3o de cadastro de usu\00E1rio</div>'),
'<br>',
unistr('<div class="st-detalhe-login">\2022 A confirma\00E7\00E3o de cadastro para o usu\00E1rio j\00E1 foi realizada;</div>'),
unistr('<div class="st-detalhe-login">\2022 O usu\00E1rio pode ter sido exclu\00EDdo.</div>'),
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(329742295697679812)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(616795126052591891)
,p_button_name=>'EXEC'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--padTop'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Acessar'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999::'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329742757372679813)
,p_name=>'P9994_USERNAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(616795126052591891)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329743096254679813)
,p_name=>'P9994_TOKEN_VERIFICAO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(616795126052591891)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329743563811679813)
,p_name=>'P9994_CONFIRMA_CADASTRO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(616795126052591891)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(329744496612679814)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Confirme cadastro'
,p_process_sql_clob=>':P9994_CONFIRMA_CADASTRO := PKG_USUARIO.confirma_cadastro(:P9994_USERNAME,:P9994_TOKEN_VERIFICAO);'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62055014244122395
);
wwv_flow_imp.component_end;
end;
/
