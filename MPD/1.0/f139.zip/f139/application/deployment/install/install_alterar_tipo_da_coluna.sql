prompt --application/deployment/install/install_alterar_tipo_da_coluna
begin
--   Manifest
--     INSTALL: INSTALL-alterar tipo da coluna
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(95657490139955415)
,p_install_id=>wwv_flow_imp.id(275122924631819510)
,p_name=>'alterar tipo da coluna'
,p_sequence=>151
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'alter table MPD_FUNCIONALIDADE modify',
'("TESTE_2" VARCHAR2(256));'))
);
wwv_flow_imp.component_end;
end;
/
