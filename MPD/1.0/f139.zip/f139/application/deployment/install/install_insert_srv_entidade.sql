prompt --application/deployment/install/install_insert_srv_entidade
begin
--   Manifest
--     INSTALL: INSTALL-insert srv_entidade
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(94144207472099042)
,p_install_id=>wwv_flow_imp.id(275122924631819510)
,p_name=>'insert srv_entidade'
,p_sequence=>53
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --SRV_ENTIDADE: 51/10000 rows exported, APEX$DATA$PKG/SRV_ENTIDADE$408569',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ENTIDADE'', p_delete_after_install => true );',
'    --SRV_ENTIDADE_COLUNA: 536/10000 rows exported, APEX$DATA$PKG/SRV_ENTIDADE_COLUNA$158848',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ENTIDADE_COLUNA'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
