prompt --application/deployment/install/install_insert_srv_dominio
begin
--   Manifest
--     INSTALL: INSTALL-insert srv_dominio
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(93797862348479026)
,p_install_id=>wwv_flow_imp.id(275122924631819510)
,p_name=>'insert srv_dominio'
,p_sequence=>51
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --SRV_DOMINIO: 41/10000 rows exported, APEX$DATA$PKG/SRV_DOMINIO$532600',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_DOMINIO'', p_delete_after_install => false );',
'    --SRV_DOMINIO_VALOR: 130/10000 rows exported, APEX$DATA$PKG/SRV_DOMINIO_VALOR$154337',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_DOMINIO_VALOR'', p_delete_after_install => false );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
