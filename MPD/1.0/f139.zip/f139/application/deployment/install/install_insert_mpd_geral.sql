prompt --application/deployment/install/install_insert_mpd_geral
begin
--   Manifest
--     INSTALL: INSTALL-insert mpd geral
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(94148481480105347)
,p_install_id=>wwv_flow_imp.id(275122924631819510)
,p_name=>'insert mpd geral'
,p_sequence=>55
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --MPD_CADASTRO_COMPARTILHADO: 1/10000 rows exported, APEX$DATA$PKG/MPD_CADASTRO_COMPARTILHA$740375',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_CADASTRO_COMPARTILHADO'', p_delete_after_install => true );',
'    --MPD_CADASTRO_COMPARTILHADO_ENTIDADE: 2/10000 rows exported, APEX$DATA$PKG/MPD_CADASTRO_COMPARTILHA$564580',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_CADASTRO_COMPARTILHADO_ENTIDADE'', p_delete_after_install => true );',
'    --MPD_FUNCIONALIDADE: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_FUNCIONALIDADE'', p_delete_after_install => true );',
'    --MPD_FUNCIONALIDADE_BOTAO_ACAO: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_FUNCIONALIDADE_BOTAO_ACAO'', p_delete_after_install => true );',
'    --MPD_FUNCIONALIDADE_CRUD_DINAMICO: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_FUNCIONALIDADE_CRUD_DINAMICO'', p_delete_after_install => true );',
'    --MPD_FUNCIONALIDADE_DINAMICA: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_FUNCIONALIDADE_DINAMICA'', p_delete_after_install => true );',
'    --MPD_FUNCIONALIDADE_REGRA_EXECUCAO: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_FUNCIONALIDADE_REGRA_EXECUCAO'', p_delete_after_install => true );',
'    --MPD_FUNCIONALIDADE_TITULO: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_FUNCIONALIDADE_TITULO'', p_delete_after_install => true );',
'    --MPD_FUNCIONALIDADE_ZOOM_DINAMICO: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_FUNCIONALIDADE_ZOOM_DINAMICO'', p_delete_after_install => true );',
'    --MPD_GRUPO_FUNCIONALIDADE: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_GRUPO_FUNCIONALIDADE'', p_delete_after_install => true );',
'    --MPD_GRUPO_FUNCIONALIDADE_FUNCIONALIDADE: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_GRUPO_FUNCIONALIDADE_FUNCIONALIDADE'', p_delete_after_install => true );',
'    --MPD_MENU: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_MENU'', p_delete_after_install => true );',
'    --MPD_MENU_ACAO: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_MENU_ACAO'', p_delete_after_install => true );',
'    --MPD_PAPEL: 1/10000 rows exported, APEX$DATA$PKG/MPD_PAPEL$452231',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_PAPEL'', p_delete_after_install => true );',
'    --MPD_PAPEL_FUNCIONALIDADE: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_PAPEL_FUNCIONALIDADE'', p_delete_after_install => true );',
'    --MPD_PARAMETROS: 2/10000 rows exported, APEX$DATA$PKG/MPD_PARAMETROS$779731',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_PARAMETROS'', p_delete_after_install => true );',
'    --MPD_TENANT: 4/10000 rows exported, APEX$DATA$PKG/MPD_TENANT$405590',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_TENANT'', p_delete_after_install => true );',
'    --MPD_TENANT_CADASTRO_COMPARTILHADO: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_TENANT_CADASTRO_COMPARTILHADO'', p_delete_after_install => true );',
'    --MPD_USUARIO: 4/10000 rows exported, APEX$DATA$PKG/MPD_USUARIO$8058',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_USUARIO'', p_delete_after_install => true );',
'    --MPD_USUARIO_FUNCIONALIDADE: 6/10000 rows exported, APEX$DATA$PKG/MPD_USUARIO_FUNCIONALIDA$960551',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_USUARIO_FUNCIONALIDADE'', p_delete_after_install => true );',
'    --MPD_USUARIO_PAPEL: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_USUARIO_PAPEL'', p_delete_after_install => true );',
'    --MPD_USUARIO_TENANT: 9/10000 rows exported, APEX$DATA$PKG/MPD_USUARIO_TENANT$965656',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_USUARIO_TENANT'', p_delete_after_install => true );',
'    --MPD_USUARIO_TOKEN: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''MPD_USUARIO_TOKEN'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
