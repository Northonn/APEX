prompt --application/deployment/install/install_insert_srv_artefato
begin
--   Manifest
--     INSTALL: INSTALL-insert srv_artefato
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(93786014075043472)
,p_install_id=>wwv_flow_imp.id(275122924631819510)
,p_name=>'insert srv_artefato'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --SRV_ARTEFATO: 211/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO$450838',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ARTEFATO'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
