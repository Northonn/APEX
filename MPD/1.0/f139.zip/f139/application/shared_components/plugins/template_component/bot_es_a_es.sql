prompt --application/shared_components/plugins/template_component/bot_es_a_es
begin
--   Manifest
--     PLUGIN: BOT_ES_A__ES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(94313898041076475)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '')
,p_name=>'BOT_ES_A__ES'
,p_display_name=>unistr('Bot\00F5es a\00E7\00F5es')
,p_supported_component_types=>'REPORT'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','BOT_ES_A__ES'),'')
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if APEX$IS_LAZY_LOADING/}',
'  <div></div>',
'  {if MY_SECOND_PLACEHOLDER%assigned/}<div></div>{endif/}',
'{else/}',
'    <a href="#LINK#">',
'        <button class="t-Button t-Button--noLabel t-Button--icon js-ignoreChange border-radius-100  lto70204071365924982_0" style="height: 48px;" type="button" id="B70204071365924982" title="#LABEL#" aria-label="#LABEL#">',
'            <span class="t-Icon fa #ICON#" aria-hidden="true"></span>',
'        </button> ',
'    </a>',
'{endif/}'))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>2
,p_report_body_template=>'<ul style="display: flex; justify-content: center;">#APEX$ROWS#</ul>'
,p_report_row_template=>'<div style="margin-right:4px;" #APEX$ROW_IDENTIFICATION#>#APEX$PARTIAL#</div>'
,p_report_placeholder_count=>3
,p_substitute_attributes=>true
,p_reference_id=>78631891910999177
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(94314244669076486)
,p_plugin_id=>wwv_flow_imp.id(94313898041076475)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_static_id=>'ICON'
,p_prompt=>'Icon'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(94314679065076488)
,p_plugin_id=>wwv_flow_imp.id(94313898041076475)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_static_id=>'LABEL'
,p_prompt=>'Label'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(94315088938076489)
,p_plugin_id=>wwv_flow_imp.id(94313898041076475)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_static_id=>'LINK'
,p_prompt=>'Link'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(94315476950076491)
,p_plugin_id=>wwv_flow_imp.id(94313898041076475)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_static_id=>'MY_SECOND_PLACEHOLDER'
,p_prompt=>'My Second Placeholder'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp.component_end;
end;
/
