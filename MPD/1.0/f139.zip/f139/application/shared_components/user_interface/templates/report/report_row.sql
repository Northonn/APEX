prompt --application/shared_components/user_interface/templates/report/report_row
begin
--   Manifest
--     ROW TEMPLATE: REPORT_ROW
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_row_template(
 p_id=>wwv_flow_imp.id(272907418971898129)
,p_row_template_name=>unistr('Perfil de usu\00E1rio')
,p_internal_name=>'REPORT_ROW'
,p_css_file_urls=>'#WORKSPACE_FILES#Template Perfil de usuario#MIN#.css'
,p_row_template1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="accountMenu_menu" class="a-Header-accountDialog" tabindex="-1">',
'	<div class="a-MediaBlock a-Menu-content">',
'		<div class="a-MediaBlock-graphic">',
'			<span class="a-Header-userPhoto a-Header-userPhoto--large">',
'            <a href="#URL_EDITAR#" class="a-Header-accountDialog-editProfile a-Menu-item a-Menu-label t-Button--hot" style="cursor: pointer;" id="EDIT_PROFILE_LINK">    ',
'			<img href="#URL_EDITAR#" src="#URL_IMAGE#" style="cursor: pointer;" height="64" width="64" class="a-Header-photo" alt="Profile image for user #NOME#">',
'			<a></a>',
'		</div>',
'		<div class="a-MediaBlock-content">',
'			<div class="a-Menu-label a-Menu-item" tabindex="-1">',
'				<span class="a-Header-dialogText a-Header-dialogName">#APELIDO#</span>',
'				<span class="a-Header-dialogText a-Header-dialogUsername">#NOME#</span>',
'			</div>',
'			<div class="a-Menu-label a-Menu-item" tabindex="-1">',
'				<span class="a-Header-dialogLabel">Telefone</span>',
'				<span class="a-Header-dialogValue">#TELEFONE#</span>',
'			</div>',
'			<div class="a-Menu-label a-Menu-item" tabindex="-1">',
'				<span class="a-Header-dialogLabel">E-mail</span>',
'				<span class="a-Header-dialogValue">#EMAIL#</span>',
'			</div>',
'		</div>',
'	</div>',
'</div>'))
,p_row_template_before_rows=>' '
,p_row_template_after_rows=>' '
,p_row_template_type=>'NAMED_COLUMNS'
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_theme_id=>42
,p_theme_class_id=>4
,p_translate_this_template=>'N'
);
wwv_flow_imp.component_end;
end;
/
