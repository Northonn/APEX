prompt --application/shared_components/logic/application_items/g_fos_tooltip_attr_2
begin
--   Manifest
--     APPLICATION ITEM: G_FOS_TOOLTIP_ATTR_2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(94139028938866177)
,p_name=>'G_FOS_TOOLTIP_ATTR_2'
,p_protection_level=>'I'
,p_item_comment=>'This item is used for the FOS - Tooltip Plug-in'
,p_version_scn=>41336358342106
);
wwv_flow_imp.component_end;
end;
/
