prompt --application/shared_components/logic/application_items/programa
begin
--   Manifest
--     APPLICATION ITEM: PROGRAMA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(372773178513338005)
,p_name=>'PROGRAMA'
,p_protection_level=>'I'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
