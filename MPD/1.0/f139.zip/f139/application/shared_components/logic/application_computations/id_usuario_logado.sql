prompt --application/shared_components/logic/application_computations/id_usuario_logado
begin
--   Manifest
--     APPLICATION COMPUTATION: ID_USUARIO_LOGADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(274598374143264907)
,p_computation_sequence=>10
,p_computation_item=>'ID_USUARIO_LOGADO'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'Select ID FROM MPD_USUARIO WHERE UPPER(LOGIN) = UPPER(:APP_USER);'
,p_computation_error_message=>unistr('Cadastre seu usu\00E1rio')
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
