prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(399316930599126008)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(168360198486787340)
,p_short_name=>'Cadastro compartilhado'
,p_link=>'f?p=&APP_ID.:158:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>158
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(170665737614400071)
,p_short_name=>'Tenant'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(170727182306475577)
,p_short_name=>unistr('Usu\00E1rios')
,p_link=>'f?p=&APP_ID.:105:&SESSION.::&DEBUG.:::'
,p_page_id=>105
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(172012657660569777)
,p_short_name=>'Menu'
,p_link=>'f?p=&APP_ID.:258:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>258
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(172193259558827966)
,p_parent_id=>wwv_flow_imp.id(172012657660569777)
,p_short_name=>'Detalhes do menu'
,p_link=>'f?p=&APP_ID.:264:&SESSION.::&DEBUG.:::'
,p_page_id=>264
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(172739149866882481)
,p_short_name=>unistr('Papel de usu\00E1rio')
,p_link=>'f?p=&APP_ID.:266:&SESSION.::&DEBUG.:::'
,p_page_id=>266
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(284421372726356375)
,p_short_name=>unistr('Administra\00E7\00E3o')
,p_page_id=>0
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(284421583002358438)
,p_parent_id=>wwv_flow_imp.id(284421372726356375)
,p_short_name=>'Templates'
,p_page_id=>0
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(286536559616714114)
,p_parent_id=>wwv_flow_imp.id(284421372726356375)
,p_short_name=>'Controle de acesso'
,p_page_id=>0
);
wwv_flow_imp.component_end;
end;
/
