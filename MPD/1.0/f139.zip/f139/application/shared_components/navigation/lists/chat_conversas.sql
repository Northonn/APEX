prompt --application/shared_components/navigation/lists/chat_conversas
begin
--   Manifest
--     LIST: chat conversas
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(385889366451302326)
,p_name=>'chat conversas'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID,',
'    ID_CHAMADO,',
'    DATA,',
'    ''Chamado: ''||ID_CHAMADO AS IDCHAMADO,',
'    CASE',
'    WHEN TO_CHAR(DATA, ''DD/MM/YYYY'') = TO_CHAR(CURRENT_DATE, ''DD/MM/YYYY'') THEN',
'    TO_CHAR(DATA, ''HH24:MI'')',
'    WHEN TO_CHAR(DATA, ''DD/MM/YYYY'') = TO_CHAR(TO_DATE(TO_CHAR(CURRENT_DATE, ''DD/MM/YYYY''), ''DD/MM/YYYY'') - 1, ''DD/MM/YYYY'') THEN',
'    ''Ontem''',
'    ELSE TO_CHAR(DATA, ''DD/MM/YYYY'')',
'    END AS DATAMENSAGEM, ',
'    CASE',
'    WHEN ID_USUARIO = (SELECT ID FROM ADM_USUARIO WHERE UPPER(USERNAME) = UPPER(V(''APP_USER''))) THEN',
unistr('    ''Voc\00EA: ''||CASE WHEN LENGTH(MENSAGEM) > 41 THEN SUBSTR(MENSAGEM,0,35)||''...'' ELSE MENSAGEM END'),
'    ELSE (SELECT NOME FROM ADM_USUARIO WHERE ID = ID_USUARIO)||'': ''||CASE WHEN LENGTH(MENSAGEM) > 41 THEN SUBSTR(MENSAGEM,0,38)||''...'' ELSE MENSAGEM END',
'    END AS MENSAGEM,',
'    CASE',
'    WHEN NOTIFICACAO = ''S'' AND ID_USUARIO <> (SELECT ID FROM ADM_USUARIO WHERE UPPER(USERNAME) = UPPER(V(''APP_USER''))) THEN',
'    ''fa fa-comment-o fam-warning fam-is-warning fa-lg''',
'    ELSE ''visibility: hidden;''',
'    END AS CONTAGEM ',
'FROM ADM_CHAMADO_CHAT CHAT',
'WHERE (ID_CHAMADO, ID) IN ',
'(SELECT ID_CHAMADO, MAX(ID) FROM ADM_CHAMADO_CHAT',
'GROUP BY ID_CHAMADO)',
'AND ID_CHAMADO IN (SELECT C.ID FROM ADM_CHAMADO C ',
'             JOIN ADM_CHAMADO_ENVOLVIDOS E ON E.ID_CHAMADO = C.ID',
'             JOIN ADM_USUARIO U ON E.ID_USUARIO = U.ID',
'             WHERE (E.ID_USUARIO IN ',
'            (SELECT ID FROM ADM_USUARIO WHERE UPPER(USERNAME) = UPPER(V(''APP_USER''))))',
'             OR UPPER(V(''APP_USER'')) IN ',
'            (SELECT UPPER(USERNAME) FROM ADM_USUARIO WHERE TIPO = ''ADMIN:CREATE:DATA_LOADER:EDIT:HELP:MONITOR:SQL'' AND UPPER(USERNAME) = UPPER(V(''APP_USER'')) AND C.STATUS <> ''G'')',
'            ) ',
'AND ID_CHAMADO NOT IN (SELECT ID FROM ADM_CHAMADO WHERE STATUS IN (''D'',''F'',''G''))',
'ORDER BY DATA DESC, NOTIFICACAO DESC, ID_CHAMADO',
''))
,p_list_status=>'PUBLIC'
);
wwv_flow_imp.component_end;
end;
/
