prompt --application/shared_components/navigation/lists/menu_opções
begin
--   Manifest
--     LIST: Menu Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(172085512886810114)
,p_name=>unistr('Menu Op\00E7\00F5es')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(172086133327810117)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('A\00E7\00F5es')
,p_list_item_link_target=>'f?p=&APP_ID.:261:&SESSION.::&DEBUG.:261:P261_ID:&P260_ID.:'
,p_list_item_icon=>'fa-bolt'
,p_list_text_01=>unistr('Permite realizar a cria\00E7\00E3o e altera\00E7\00E3o das a\00E7\00F5es do menu.')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
