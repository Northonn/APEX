prompt --application/shared_components/navigation/lists/menu_dinamico
begin
--   Manifest
--     LIST: Menu dinamico
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(167786716114133725)
,p_name=>'Menu dinamico'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select level ,',
'       a.titulo label,',
'       DECODE (CONNECT_BY_ISLEAF,0, '''',''f?p=''||d.codigo_aplicacao||'':'' || TO_CHAR (c.codigo_artefato)||'':&SESSION.:::::'') TARGET,',
'       ''YES'' is_current,',
'       nvl(a.icone, ''fa-apex_square'') image,',
'       a.id_menu_pai',
'from srv_menu a',
'left join srv_menu_acao b on b.id_menu = a.id',
'left join srv_artefato c on c.id = b.id_artefato_versao',
'left join srv_aplicacao d on d.id = c.id_aplicacao',
'start with a.id_menu_pai is null',
'connect by prior a.id = a.id_menu_pai'))
,p_list_status=>'PUBLIC'
);
wwv_flow_imp.component_end;
end;
/
