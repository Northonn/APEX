prompt --application/shared_components/navigation/lists/usuários_ações
begin
--   Manifest
--     LIST: Usuários Ações
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(270885901120814611)
,p_name=>unistr('Usu\00E1rios A\00E7\00F5es')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(170868883894789377)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Copiar'
,p_list_item_link_target=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.:107:P107_ID:&P112_ID.:'
,p_list_item_icon=>'fa-copy'
,p_list_text_06=>'u-success'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(170869532084796435)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Excluir'
,p_list_item_link_target=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:108:P108_ID:&P112_ID.:'
,p_list_item_icon=>'fa-trash'
,p_list_text_06=>'u-danger'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
