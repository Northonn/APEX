prompt --application/shared_components/navigation/lists/usuários_papel_opções
begin
--   Manifest
--     LIST: Usuários Papel Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(173266679314342672)
,p_name=>unistr('Usu\00E1rios Papel Op\00E7\00F5es')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(173266930593342678)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Funcionalidades'
,p_list_item_link_target=>'f?p=&APP_ID.:273:&SESSION.::&DEBUG.:273:P273_ID:&P271_ID.:'
,p_list_item_icon=>'fa-tasks-alt'
,p_list_text_01=>'Permite atribuir, alterar ou excluir funcionalidades ao papel'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
