prompt --application/shared_components/navigation/lists/tenant_navegação
begin
--   Manifest
--     LIST: Tenant navegação
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(168232349174370196)
,p_name=>unistr('Tenant navega\00E7\00E3o')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(168232524468370202)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Cadastros compartilhados'
,p_list_item_link_target=>'f?p=&APP_ID.:216:&SESSION.::&DEBUG.:216:P216_ID_TENANT:&P101_ID.:'
,p_list_item_icon=>'fa-share2'
,p_list_text_01=>unistr('Compartilhamento de cadastro permite a reutiliza\00E7\00E3o de cadastros entre os tenants.')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(168232915443370204)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Conceder acesso a usu\00E1rios')
,p_list_item_link_target=>'f?p=&APP_ID.:155:&SESSION.::&DEBUG.::P155_ID_TENANT:&P101_ID.:'
,p_list_item_icon=>'fa-user-lock'
,p_list_text_01=>unistr('Usu\00E1rios que possuem acesso ao tenant')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
