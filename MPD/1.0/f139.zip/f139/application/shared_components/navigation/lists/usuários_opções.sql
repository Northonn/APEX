prompt --application/shared_components/navigation/lists/usuários_opções
begin
--   Manifest
--     LIST: Usuários Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(170869853165803913)
,p_name=>unistr('Usu\00E1rios Op\00E7\00F5es')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(170869964874803914)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Alterar dados pessoais'
,p_list_item_link_target=>'f?p=&APP_ID.:109:&SESSION.::&DEBUG.:109:P109_ID:&P112_ID.:'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>unistr('Permite realizar a altera\00E7\00E3o de dados pessoais do usu\00E1rio, como nome, apelido, foto e etc.')
,p_list_text_06=>'u-hot'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(170870365186803916)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Alterar dados de acesso'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:110:P110_ID:&P112_ID.:'
,p_list_item_icon=>'fa-lock'
,p_list_text_01=>unistr('Permite realizar a altera\00E7\00E3o de dados de acesso do usu\00E1rio as sistema, como login e senha.')
,p_list_text_06=>'u-warning'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(170870849160803917)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Alterar prefer\00EAncias')
,p_list_item_link_target=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:111:P111_ID:&P112_ID.:'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>unistr('Permite a altera\00E7\00E3o das prefer\00EAncias do usu\00E1rio como fuso hor\00E1rio e idioma.')
,p_list_text_06=>'u-success'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(173216873164893573)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Papel do usu\00E1rio')
,p_list_item_link_target=>'f?p=&APP_ID.:269:&SESSION.::&DEBUG.:269:P269_ID:&P112_ID.:'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>unistr('Permite atribuir, alterar ou excluir o pap\00E9l do usu\00E1rio')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(173359659656055105)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Funcionalidades'
,p_list_item_link_target=>'f?p=&APP_ID.:276:&SESSION.::&DEBUG.:276:P276_ID:&P112_ID.:'
,p_list_item_icon=>'fa-tasks-alt'
,p_list_text_01=>unistr('Permite atribuir, alterar ou excluir funcionalidades do usu\00E1rio')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
