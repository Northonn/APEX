prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(270702570923607501)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(167779360816933005)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(170664790862400066)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Tenant'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'100'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(170668327028407228)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Usu\00E1rios')
,p_list_item_link_target=>'f?p=&APP_ID.:105:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-user'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'105'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(172738170668882475)
,p_list_item_display_sequence=>31
,p_list_item_link_text=>unistr('Papel de usu\00E1rio')
,p_list_item_link_target=>'f?p=&APP_ID.:266:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-book-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'266'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(171419245501100323)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Cadastro compartilhado'
,p_list_item_link_target=>'f?p=&APP_ID.:158:&SESSION.::&DEBUG.:158:::'
,p_list_item_icon=>'fa-share-alt'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(172007075765569730)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Menu'
,p_list_item_link_target=>'f?p=&APP_ID.:258:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-bars'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'258'
);
wwv_flow_imp.component_end;
end;
/
