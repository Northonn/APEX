prompt --application/shared_components/email/templates/faturamento_de_chamado
begin
--   Manifest
--     REPORT LAYOUT: Faturamento de chamado
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(374383715163727881)
,p_name=>'Faturamento de chamado'
,p_static_id=>'FATURAMENTO_DE_CHAMADO'
,p_version_number=>2
,p_subject=>'Faturamento de chamado NG'
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>Ol\00E1, informamos que seu chamado foi faturado com sucesso de '),
unistr('    acordo com nossos termos de servi\00E7o, j\00E1 encaminhamos o boleto ao setor'),
'    financeiro de sua empresa!</p><br>',
'<br>',
'<strong>Solicitante:</strong> #USUARIO_NOME#<br>',
unistr('<strong>N\00FAmero do chamado:</strong> #ID_CHAMADO#<br>'),
'<br>',
'<a href="https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com/ords/r/srvdev/ng-srv/sup-consulta-chamado?session=704047012200768&P140_SEARCH=#ID_CHAMADO#" style="font-size: 14px;">Visite o SRV para acompanhar o progresso do seu chamado</a'
||'>.'))
,p_html_header=>'<b style="font-size: 24px;">Faturamento de chamado NG</b>'
,p_html_footer=>unistr('N\00E3o responder esse e-mail')
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
