prompt --application/deployment/install/install_add_campo
begin
--   Manifest
--     INSTALL: INSTALL-add campo
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(95657223553923360)
,p_install_id=>wwv_flow_imp.id(275122924631819510)
,p_name=>'add campo'
,p_sequence=>141
,p_script_type=>'INSTALL'
,p_script_clob=>'alter table MPD_FUNCIONALIDADE add ("TESTE_2" varchar2(20));'
);
wwv_flow_imp.component_end;
end;
/
