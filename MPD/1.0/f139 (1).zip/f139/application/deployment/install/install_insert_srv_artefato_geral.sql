prompt --application/deployment/install/install_insert_srv_artefato_geral
begin
--   Manifest
--     INSTALL: INSTALL-insert srv_artefato geral
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(94151465125114325)
,p_install_id=>wwv_flow_imp.id(275122924631819510)
,p_name=>'insert srv_artefato geral'
,p_sequence=>57
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --SRV_ARTEFATO_ACAO_DINAMICA: 9/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_ACAO_DINAMI$318418',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ARTEFATO_ACAO_DINAMICA'', p_delete_after_install => true );',
'    --SRV_ARTEFATO_BOTAO_ACAO: 40/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_BOTAO_ACAO$326683',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ARTEFATO_BOTAO_ACAO'', p_delete_after_install => true );',
'    --SRV_ARTEFATO_CRUD_DINAMICO: 23/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_CRUD_DINAMI$32303',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ARTEFATO_CRUD_DINAMICO'', p_delete_after_install => true );',
'    --SRV_ARTEFATO_REGRA_EXECUCAO: 5/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_REGRA_EXECU$629550',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ARTEFATO_REGRA_EXECUCAO'', p_delete_after_install => true );',
'    --SRV_ARTEFATO_RELEASE: 32/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_RELEASE$55297',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ARTEFATO_RELEASE'', p_delete_after_install => true );',
'    --SRV_ARTEFATO_SEQUENCIA: 9999/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_SEQUENCIA$795800',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ARTEFATO_SEQUENCIA'', p_delete_after_install => true );',
'    --SRV_ARTEFATO_TITULO: 1/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_TITULO$548160',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ARTEFATO_TITULO'', p_delete_after_install => true );',
'    --SRV_ARTEFATO_ZOOM_DINAMICO: 5/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_ZOOM_DINAMI$879276',
'    apex_data_install.load_supporting_object_data(p_table_name => ''SRV_ARTEFATO_ZOOM_DINAMICO'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
