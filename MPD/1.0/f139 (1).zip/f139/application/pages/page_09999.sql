prompt --application/pages/page_09999
begin
--   Manifest
--     PAGE: 09999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>139
,p_default_id_offset=>93721358644667970
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9999
,p_name=>'Login'
,p_alias=>'LOGIN'
,p_step_title=>'Login'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(280719082211191960)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* body {',
'    background-image: url(#APP_FILES#AdobeStock_351610333.jpg);',
'    background-repeat:  no-repeat;',
'    background-attachment: fixed;',
'    background-size:  cover;',
'}',
' */',
'',
'',
'.background-div {',
'    width: 70%; /* Defina a largura desejada */',
'    height: 100%; /* Defina a altura desejada */',
'    background-image: url(''#APP_FILES#fundo.png''); /* Substitua pelo caminho da sua imagem */',
'    background-size: cover; /* Ajusta a imagem para cobrir toda a div */',
'    background-position: center; /* Centraliza a imagem */',
unistr('    /* Outras propriedades CSS conforme necess\00E1rio */'),
'        border-radius: 20px;',
'    box-shadow: var(--ut-shadow-md);',
'    margin-inline-start: 15%;',
'    /* border-right-width: 0px; */',
'    border: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(399342888283126040)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'12'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240504085812'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(499422006152683777)
,p_plug_name=>'&APP_NAME.'
,p_region_css_classes=>'background-div'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>30
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93988514659643431)
,p_plug_name=>'coluna1'
,p_parent_plug_id=>wwv_flow_imp.id(499422006152683777)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_region_attributes=>'style="color:white; margin-left:22%;"'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1 style="text-align:center;">Seja bem-vindo</h1>',
'<div class="u-pullcenter" style="margin-top:20%;">',
'    <img src="#APP_FILES#icons/app-icon-144-rounded.png" alt="&APP_NAME."></img>',
'</div>',
'<h1 style="text-align:center;">&APP_NAME.</h1>'))
,p_plug_footer=>unistr('<div style="text-align:center;margin-top:35%;">Sistema para gerenciamento de clientes da Staff, possuiu gest\00E3o de Tenant, Usu\00E1rios, Papeis de usu\00E1rio, Cadastro de tenants compartilhados e Gerencimento de menus do sistema</div>')
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93988660025643432)
,p_plug_name=>'coluna3'
,p_parent_plug_id=>wwv_flow_imp.id(499422006152683777)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:t-Form--xlarge'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_header=>'<h1>Acesse o &APP_NAME.</h1>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93986026330643406)
,p_plug_name=>'panel'
,p_parent_plug_id=>wwv_flow_imp.id(93988660025643432)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>80
,p_plug_header=>unistr('<p class="rc63p1">Esqueceu seu usu\00E1rio ou senha? <a data-lbl="3 - Account Details " data-trackas="opcSignIn" href="https://myaccount.cloud.oracle.com/mycloud/faces/getinfo.jspx" target="_blank">Obtenha ajuda</a><br></p>')
,p_plug_footer=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="linha-de-separacao"></div>',
unistr('<div >Ainda n\00E3o \00E9 cliente da STAFF?</div>'),
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93988723604643433)
,p_plug_name=>'coluna2'
,p_parent_plug_id=>wwv_flow_imp.id(499422006152683777)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(399389252626126067)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(329702192845669289)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(93988660025643432)
,p_button_name=>'singIn'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Acessar'
,p_button_css_classes=>'is-disable'
,p_button_cattributes=>'style="min-width: 50%;"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93986151573643407)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(93988660025643432)
,p_button_name=>'singUp'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--simple:t-Button--padTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(399486973754126130)
,p_button_image_alt=>'Inscreva-se'
,p_button_cattributes=>'style="display: block; min-width: 50%;"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(329711992888669295)
,p_branch_name=>'Go to 9997'
,p_branch_action=>'f?p=&APP_ID.:9997:&SESSION.::&DEBUG.:9997:P9997_USERNAME:&P9999_USERNAME.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(329712463450669295)
,p_branch_name=>'Go to 9995'
,p_branch_action=>'f?p=&APP_ID.:9995:&SESSION.::&DEBUG.:9995:P9995_USERNAME,P9995_EMAIL:&P9999_USERNAME.,&P9999_EMAIL.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329703061649669290)
,p_name=>'P9999_USERNAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(93988660025643432)
,p_prompt=>unistr('Nome de usu\00E1rio')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(399484407056126127)
,p_item_css_classes=>'u-bold'
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-top-lg'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329703453170669290)
,p_name=>'P9999_PASSWORD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(93988660025643432)
,p_prompt=>'Senha'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'PLUGIN_COM.FOS.ADVANCED_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(399484407056126127)
,p_item_css_classes=>'u-bold'
,p_item_icon_css_classes=>'fa-lock-password'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'disabled'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329703784568669290)
,p_name=>'P9999_REMEMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(93988660025643432)
,p_prompt=>unistr('Lembrar nome de usu\00E1rio')
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(399484158225126126)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329704187296669290)
,p_name=>'P9999_EMAIL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(499422006152683777)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(329704726472669291)
,p_validation_name=>'P9999_PASSWORD-Valid Username Password'
,p_validation_sequence=>10
,p_validation=>'return PKG_API_SEGURANCA.valid_username_and_password(:P9999_USERNAME,:P9999_PASSWORD);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_validation_condition=>'LOGIN-NORMAL,LOGIN-MFA'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(329703453170669290)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(329705504261669291)
,p_validation_name=>'P9999_USERNAME-Valid Username'
,p_validation_sequence=>30
,p_validation=>'return PKG_API_SEGURANCA.valid_username(:P9999_USERNAME);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_associated_item=>wwv_flow_imp.id(329703061649669290)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(329705115263669291)
,p_validation_name=>'P9999_USERNAME-Valid Not Null'
,p_validation_sequence=>40
,p_validation=>'P9999_USERNAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Nome de usu\00E1rio deve ser informado')
,p_associated_item=>wwv_flow_imp.id(329703061649669290)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(329708208351669293)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'SEND_LOGIN_USERNAME_COOKIE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>62018725983111874
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(329708768145669293)
,p_page_process_id=>wwv_flow_imp.id(329708208351669293)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'lower( :P9999_USERNAME )'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(329709274609669293)
,p_page_process_id=>wwv_flow_imp.id(329708208351669293)
,p_page_id=>9999
,p_name=>'p_consent'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_REMEMBER'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(329705787240669292)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'PROCESS_LOGIN'
,p_process_error_message=>unistr('Nome de usu\00E1rio ou senha inv\00E1lido')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(329702192845669289)
,p_internal_uid=>62016304872111873
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(245502520936546485)
,p_page_process_id=>wwv_flow_imp.id(329705787240669292)
,p_page_id=>9999
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'ITEM'
,p_value=>'P9999_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(245502601597546486)
,p_page_process_id=>wwv_flow_imp.id(329705787240669292)
,p_page_id=>9999
,p_name=>'p_app_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>32
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(245502992864546490)
,p_page_process_id=>wwv_flow_imp.id(329705787240669292)
,p_page_id=>9999
,p_name=>'p_auth_type'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>22
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(329707840161669293)
,p_page_process_id=>wwv_flow_imp.id(329705787240669292)
,p_page_id=>9999
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_PASSWORD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(329710002954669294)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Recupera senha'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'RESTORE_PASSWORD'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('Senha tempor\00E1ria enviada para o e-mail &P9999_EMAIL.')
,p_internal_uid=>62020520586111875
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(329710569487669294)
,p_page_process_id=>wwv_flow_imp.id(329710002954669294)
,p_page_id=>9999
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9999_EMAIL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(329711062677669294)
,p_page_process_id=>wwv_flow_imp.id(329710002954669294)
,p_page_id=>9999
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9999_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(329711485745669295)
,p_page_process_id=>wwv_flow_imp.id(329710002954669294)
,p_page_id=>9999
,p_name=>'p_app_alias'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_ALIAS'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(329709674791669294)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9999_USERNAME := apex_authentication.get_login_username_cookie;',
':P9999_REMEMBER := case when :P9999_USERNAME is not null then ''Y'' end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62020192423111875
);
wwv_flow_imp.component_end;
end;
/
