prompt --application/shared_components/files/theme_staff_min_css
begin
--   Manifest
--     APP STATIC FILES: 137
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>137
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E6261636B67726F756E642D636F6C6F722D7472616E73706172656E747B6261636B67726F756E642D636F6C6F723A7472616E73706172656E747D2E626F726465722D6E6F6E657B626F726465723A307D2E736861646F772D6E6F6E657B626F782D7368';
wwv_flow_imp.g_varchar2_table(2) := '61646F773A6E6F6E657D2E73742D746974756C6F2D6170707B666F6E742D7765696768743A3730303B6D617267696E2D626F74746F6D3A313070783B636F6C6F723A677261793B666F6E742D73697A653A323470787D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(92966048906232326)
,p_file_name=>'theme_staff.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
