prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>137
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Time line'
,p_alias=>'TIME-LINE'
,p_step_title=>'Time line'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'27'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240430100540'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93298672374718607)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(92487229910916496)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(92371545706916274)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(92549608982916634)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93299317490718617)
,p_plug_name=>'Time line'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(92409692816916348)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select 1 as "ID",',
'       ''User'' as "USER_NAME",',
'       ''1 hour ago'' as "DATE",',
'       ''Lorem ipsum dolor sit amet'' as "TITLE",',
'       ''Nunc sit amet nunc quis magna ornare suscipit. Etiam aliquet maximus sapien, at sagittis sem gravida nec.'' as "DESCRIPTION",',
'       ''Closed'' as "BADGE_VALUE",',
'       ''is-removed'' as "BADGE_STATE"',
'  from sys.dual',
'union all',
'select 2 as "ID",',
'       ''User'' as "USER_NAME",',
'       ''1 hour ago'' as "DATE",',
'       ''Lorem ipsum dolor sit amet'' as "TITLE",',
'       ''Nunc sit amet nunc quis magna ornare suscipit. Etiam aliquet maximus sapien, at sagittis sem gravida nec.'' as "DESCRIPTION",',
'       ''Closed'' as "BADGE_VALUE",',
'       ''is-removed'' as "BADGE_STATE"',
'  from sys.dual',
'union all',
'select 3 as "ID",',
'       ''User'' as "USER_NAME",',
'       ''1 hour ago'' as "DATE",',
'       ''Lorem ipsum dolor sit amet'' as "TITLE",',
'       ''Nunc sit amet nunc quis magna ornare suscipit. Etiam aliquet maximus sapien, at sagittis sem gravida nec.'' as "DESCRIPTION",',
'       ''Closed'' as "BADGE_VALUE",',
'       ''is-removed'' as "BADGE_STATE"',
'  from sys.dual'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P6_ORDER_BY", "orderBys": [{"key":"USER_NAME","expr":"\"USER_NAME\" asc"},{"key":"DATE","expr":"\"DATE\" asc"}]}'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$TIMELINE'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"AVATAR_ICON": "fa-user",',
  '"AVATAR_SHAPE": "t-Avatar--circle",',
  '"BADGE_LABEL_DISPLAY": "N",',
  '"USER_NAME": "USER_NAME",',
  '"DATE": "DATE",',
  '"TITLE": "TITLE",',
  '"DESCRIPTION": "DESCRIPTION",',
  '"DISPLAY_AVATAR": "Y",',
  '"DISPLAY_BADGE": "Y",',
  '"AVATAR_TYPE": "icon",',
  '"BADGE_VALUE": "BADGE_VALUE",',
  '"BADGE_STATE": "BADGE_STATE",',
  '"BADGE_ICON": "fa-check-circle-o",',
  '"APPLY_THEME_COLORS": "Y"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(93299759722718623)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(93300280449718626)
,p_name=>'USER_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(93300729097718627)
,p_name=>'DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(93301235902718629)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(93301779009718630)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(93302235568718631)
,p_name=>'BADGE_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_VALUE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(93302794813718632)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93303232352718639)
,p_name=>'P6_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(93299317490718617)
,p_item_default=>'USER_NAME'
,p_prompt=>'Ordenar Por'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:User Name;USER_NAME,Date;DATE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(92545545548916621)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
