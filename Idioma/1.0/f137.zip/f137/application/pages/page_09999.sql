prompt --application/pages/page_09999
begin
--   Manifest
--     PAGE: 09999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>137
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9999
,p_name=>'Login'
,p_alias=>'LOGIN'
,p_step_title=>'Login'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(92382997541916296)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'12'
,p_last_updated_by=>'NTO'
,p_last_upd_yyyymmddhh24miss=>'20240430112823'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(499347486640631154)
,p_plug_name=>'MBP'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(92469643373916462)
,p_plug_display_sequence=>10
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<img src="#APP_FILES#logo.png" style="height: 30px;" alt="Staff Inform\00E1tica Ltda"></img>'),
'<div class="st-titulo-app">&APP_NAME.</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452368627959137505)
,p_plug_name=>'Login'
,p_parent_plug_id=>wwv_flow_imp.id(499347486640631154)
,p_region_css_classes=>'background-color-transparent border-none shadow-none'
,p_icon_css_classes=>'fa-lock-user'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(92403066963916334)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(92947492054149701)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(452368627959137505)
,p_button_name=>'ESQUECEU'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(92548051656916630)
,p_button_image_alt=>'Esqueceu a senha?'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(92946682492149698)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(452368627959137505)
,p_button_name=>'LOGIN-NORMAL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(92548051656916630)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Acessar'
,p_button_position=>'PREVIOUS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(92947012350149700)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(452368627959137505)
,p_button_name=>'LOGIN-MFA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(92548051656916630)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Acessar'
,p_button_position=>'PREVIOUS'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(92956142176149735)
,p_branch_name=>'Go to 9997'
,p_branch_action=>'f?p=&APP_ID.:9997:&SESSION.::&DEBUG.:9997:P9997_USERNAME:&P9999_USERNAME.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(92947012350149700)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(92956590479149736)
,p_branch_name=>'Go to 9995'
,p_branch_action=>'f?p=&APP_ID.:9995:&SESSION.::&DEBUG.:9995:P9995_USERNAME,P9995_EMAIL:&P9999_USERNAME.,&P9999_EMAIL.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(92947492054149701)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329630782963616691)
,p_name=>'P9999_USERNAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(452368627959137505)
,p_prompt=>unistr('Nome de usu\00E1rio')
,p_placeholder=>unistr('Informe seu nome de usu\00E1rio')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(92545251457916621)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329631174484616691)
,p_name=>'P9999_PASSWORD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(452368627959137505)
,p_prompt=>'Senha'
,p_placeholder=>'Informe sua senha'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(92545251457916621)
,p_item_icon_css_classes=>'fa-lock-password'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329631908610616691)
,p_name=>'P9999_EMAIL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(452368627959137505)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(92949319416149714)
,p_validation_name=>'P9999_PASSWORD-Valid Username Password'
,p_validation_sequence=>10
,p_validation=>'return PKG_API_SEGURANCA.valid_username_and_password(:P9999_USERNAME,:P9999_PASSWORD);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(329631174484616691)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(92950193899149716)
,p_validation_name=>'P9999_USERNAME-Valid Username'
,p_validation_sequence=>30
,p_validation=>'return PKG_API_SEGURANCA.valid_username(:P9999_USERNAME);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_associated_item=>wwv_flow_imp.id(329630782963616691)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(92949777831149716)
,p_validation_name=>'P9999_USERNAME-Valid Not Null'
,p_validation_sequence=>40
,p_validation=>'P9999_USERNAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Nome de usu\00E1rio deve ser informado')
,p_associated_item=>wwv_flow_imp.id(329630782963616691)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(92950439173149717)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'PROCESS_LOGIN'
,p_process_error_message=>unistr('Nome de usu\00E1rio ou senha inv\00E1lido')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>92950439173149717
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(92950986220149719)
,p_page_process_id=>wwv_flow_imp.id(92950439173149717)
,p_page_id=>9999
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'ITEM'
,p_value=>'P9999_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(92951483523149721)
,p_page_process_id=>wwv_flow_imp.id(92950439173149717)
,p_page_id=>9999
,p_name=>'p_app_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>32
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(92951973153149722)
,p_page_process_id=>wwv_flow_imp.id(92950439173149717)
,p_page_id=>9999
,p_name=>'p_auth_type'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>22
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(92952496288149723)
,p_page_process_id=>wwv_flow_imp.id(92950439173149717)
,p_page_id=>9999
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_PASSWORD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(92954207525149729)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9999_USERNAME := apex_authentication.get_login_username_cookie;',
':P9999_REMEMBER := case when :P9999_USERNAME is not null then ''Y'' end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>92954207525149729
);
wwv_flow_imp.component_end;
end;
/
