prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 137
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>137
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(92930459041945351)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table SRV_IDIOMA_1;',
'drop package PKG_API_SEGURANCA;'))
);
wwv_flow_imp.component_end;
end;
/
