prompt --application/shared_components/security/authentications/autenticação_staff
begin
--   Manifest
--     AUTHENTICATION: Autenticação STAFF
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>137
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(92933369923980947)
,p_name=>unistr('Autentica\00E7\00E3o STAFF')
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'PKG_API_SEGURANCA.PROCESS_LOGIN'
,p_attribute_05=>'N'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
