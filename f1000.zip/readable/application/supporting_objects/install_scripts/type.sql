create or replace type "TEXTARRAY" as
table of varchar2(8000)
/
 