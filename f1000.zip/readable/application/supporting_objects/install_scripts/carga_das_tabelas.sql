begin
    --MPD_CADASTRO_COMPARTILHADO: 1/10000 rows exported, APEX$DATA$PKG/MPD_CADASTRO_COMPARTILHA$740375
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_CADASTRO_COMPARTILHADO', p_delete_after_install => true );
    --MPD_CADASTRO_COMPARTILHADO_ENTIDADE: 2/10000 rows exported, APEX$DATA$PKG/MPD_CADASTRO_COMPARTILHA$564580
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_CADASTRO_COMPARTILHADO_ENTIDADE', p_delete_after_install => true );
    --MPD_FUNCIONALIDADE: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_FUNCIONALIDADE', p_delete_after_install => true );
    --MPD_FUNCIONALIDADE_BOTAO_ACAO: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_FUNCIONALIDADE_BOTAO_ACAO', p_delete_after_install => true );
    --MPD_FUNCIONALIDADE_CRUD_DINAMICO: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_FUNCIONALIDADE_CRUD_DINAMICO', p_delete_after_install => true );
    --MPD_FUNCIONALIDADE_DINAMICA: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_FUNCIONALIDADE_DINAMICA', p_delete_after_install => true );
    --MPD_FUNCIONALIDADE_REGRA_EXECUCAO: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_FUNCIONALIDADE_REGRA_EXECUCAO', p_delete_after_install => true );
    --MPD_FUNCIONALIDADE_TITULO: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_FUNCIONALIDADE_TITULO', p_delete_after_install => true );
    --MPD_GRUPO_FUNCIONALIDADE: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_GRUPO_FUNCIONALIDADE', p_delete_after_install => true );
    --MPD_GRUPO_FUNCIONALIDADE_FUNCIONALIDADE: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_GRUPO_FUNCIONALIDADE_FUNCIONALIDADE', p_delete_after_install => true );
    --MPD_MENU: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_MENU', p_delete_after_install => true );
    --MPD_MENU_ACAO: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_MENU_ACAO', p_delete_after_install => true );
    --MPD_PAPEL: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_PAPEL', p_delete_after_install => true );
    --MPD_PAPEL_FUNCIONALIDADE: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_PAPEL_FUNCIONALIDADE', p_delete_after_install => true );
    --MPD_PARAMETROS: 2/10000 rows exported, APEX$DATA$PKG/MPD_PARAMETROS$779731
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_PARAMETROS', p_delete_after_install => true );
    --MPD_TENANT: 4/10000 rows exported, APEX$DATA$PKG/MPD_TENANT$405590
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_TENANT', p_delete_after_install => true );
    --MPD_TENANT_CADASTRO_COMPARTILHADO: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_TENANT_CADASTRO_COMPARTILHADO', p_delete_after_install => true );
    --MPD_USUARIO: 5/10000 rows exported, APEX$DATA$PKG/MPD_USUARIO$8058
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_USUARIO', p_delete_after_install => true );
    --MPD_USUARIO_FUNCIONALIDADE: 6/10000 rows exported, APEX$DATA$PKG/MPD_USUARIO_FUNCIONALIDA$960551
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_USUARIO_FUNCIONALIDADE', p_delete_after_install => true );
    --MPD_USUARIO_PAPEL: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_USUARIO_PAPEL', p_delete_after_install => true );
    --MPD_USUARIO_TENANT: 9/10000 rows exported, APEX$DATA$PKG/MPD_USUARIO_TENANT$965656
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_USUARIO_TENANT', p_delete_after_install => true );
    --MPD_USUARIO_TOKEN: 0/10000 rows exported, no file generated
    apex_data_install.load_supporting_object_data(p_table_name => 'MPD_USUARIO_TOKEN', p_delete_after_install => true );
    --SRV_APLICACAO: 2/10000 rows exported, APEX$DATA$PKG/SRV_APLICACAO$283119
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_APLICACAO', p_delete_after_install => true );
    --SRV_APLICACAO_MENSAGEM: 27/10000 rows exported, APEX$DATA$PKG/SRV_APLICACAO_MENSAGEM$943055
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_APLICACAO_MENSAGEM', p_delete_after_install => true );
    --SRV_APLICACAO_MENSAGEM_TRADUZIDA: 2/10000 rows exported, APEX$DATA$PKG/SRV_APLICACAO_MENSAGEM_T$707099
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_APLICACAO_MENSAGEM_TRADUZIDA', p_delete_after_install => true );
    --SRV_APLICACAO_TEXTO: 18/10000 rows exported, APEX$DATA$PKG/SRV_APLICACAO_TEXTO$146321
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_APLICACAO_TEXTO', p_delete_after_install => true );
    --SRV_APLICACAO_TEXTO_TRADUZIDO: 1/10000 rows exported, APEX$DATA$PKG/SRV_APLICACAO_TEXTO_TRAD$923629
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_APLICACAO_TEXTO_TRADUZIDO', p_delete_after_install => true );
    --SRV_APLICACAO_VERSIONADA: 2/10000 rows exported, APEX$DATA$PKG/SRV_APLICACAO_VERSIONADA$79678
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_APLICACAO_VERSIONADA', p_delete_after_install => true );
    --SRV_ARTEFATO: 198/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO$450838
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ARTEFATO', p_delete_after_install => true );
    --SRV_ARTEFATO_ACAO_DINAMICA: 8/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_ACAO_DINAMI$318418
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ARTEFATO_ACAO_DINAMICA', p_delete_after_install => true );
    --SRV_ARTEFATO_BOTAO_ACAO: 32/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_BOTAO_ACAO$326683
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ARTEFATO_BOTAO_ACAO', p_delete_after_install => true );
    --SRV_ARTEFATO_CRUD_DINAMICO: 20/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_CRUD_DINAMI$32303
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ARTEFATO_CRUD_DINAMICO', p_delete_after_install => true );
    --SRV_ARTEFATO_REGRA_EXECUCAO: 5/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_REGRA_EXECU$629550
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ARTEFATO_REGRA_EXECUCAO', p_delete_after_install => true );
    --SRV_ARTEFATO_RELEASE: 14/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_RELEASE$55297
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ARTEFATO_RELEASE', p_delete_after_install => true );
    --SRV_ARTEFATO_SEQUENCIA: 9999/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_SEQUENCIA$795800
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ARTEFATO_SEQUENCIA', p_delete_after_install => true );
    --SRV_ARTEFATO_TITULO: 1/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_TITULO$548160
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ARTEFATO_TITULO', p_delete_after_install => true );
    --SRV_ARTEFATO_VERSIONADO: 205/10000 rows exported, APEX$DATA$PKG/SRV_ARTEFATO_VERSIONADO$433503
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ARTEFATO_VERSIONADO', p_delete_after_install => true );
    --SRV_ATIVIDADE_TAREFAS: 29/10000 rows exported, APEX$DATA$PKG/SRV_ATIVIDADE_TAREFAS$269661
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ATIVIDADE_TAREFAS', p_delete_after_install => true );
    --SRV_DOMINIO: 29/10000 rows exported, APEX$DATA$PKG/SRV_DOMINIO$532600
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_DOMINIO', p_delete_after_install => true );
    --SRV_DOMINIO_VALOR: 89/10000 rows exported, APEX$DATA$PKG/SRV_DOMINIO_VALOR$154337
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_DOMINIO_VALOR', p_delete_after_install => true );
    --SRV_ENTIDADE: 47/10000 rows exported, APEX$DATA$PKG/SRV_ENTIDADE$408569
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ENTIDADE', p_delete_after_install => true );
    --SRV_ENTIDADE_COLUNA: 453/10000 rows exported, APEX$DATA$PKG/SRV_ENTIDADE_COLUNA$158848
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_ENTIDADE_COLUNA', p_delete_after_install => true );
    --SRV_GRUPO_FUNCIONALIDADE: 1/10000 rows exported, APEX$DATA$PKG/SRV_GRUPO_FUNCIONALIDADE$474837
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_GRUPO_FUNCIONALIDADE', p_delete_after_install => true );
    --SRV_GRUPO_FUNCIONALIDADE_ARTEFATO: 1/10000 rows exported, APEX$DATA$PKG/SRV_GRUPO_FUNCIONALIDADE$793511
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_GRUPO_FUNCIONALIDADE_ARTEFATO', p_delete_after_install => true );
    --SRV_IDIOMA: 4/10000 rows exported, APEX$DATA$PKG/SRV_IDIOMA$396614
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_IDIOMA', p_delete_after_install => true );
    --SRV_MENU: 18/10000 rows exported, APEX$DATA$PKG/SRV_MENU$138537
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_MENU', p_delete_after_install => true );
    --SRV_MENU_ACAO: 16/10000 rows exported, APEX$DATA$PKG/SRV_MENU_ACAO$214665
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_MENU_ACAO', p_delete_after_install => true );
    --SRV_PROJETOS: 2/10000 rows exported, APEX$DATA$PKG/SRV_PROJETOS$619599
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_PROJETOS', p_delete_after_install => true );
    --SRV_PROJETOS_DOCUMENTOS: 1/10000 rows exported, APEX$DATA$PKG/SRV_PROJETOS_DOCUMENTOS$902534
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_PROJETOS_DOCUMENTOS', p_delete_after_install => true );
    --SRV_PROJETOS_TAREFAS: 2/10000 rows exported, APEX$DATA$PKG/SRV_PROJETOS_TAREFAS$324364
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_PROJETOS_TAREFAS', p_delete_after_install => true );
    --SRV_PROJETOS_TAREFAS_DOCUMENTOS: 1/10000 rows exported, APEX$DATA$PKG/SRV_PROJETOS_TAREFAS_DOC$104252
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_PROJETOS_TAREFAS_DOCUMENTOS', p_delete_after_install => true );
    --SRV_PROJETOS_TAREFAS_USUARIOS: 2/10000 rows exported, APEX$DATA$PKG/SRV_PROJETOS_TAREFAS_USU$351472
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_PROJETOS_TAREFAS_USUARIOS', p_delete_after_install => true );
    --SRV_SISTEMA: 2/10000 rows exported, APEX$DATA$PKG/SRV_SISTEMA$697145
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_SISTEMA', p_delete_after_install => true );
    --SRV_SISTEMA_VERSIONADO: 3/10000 rows exported, APEX$DATA$PKG/SRV_SISTEMA_VERSIONADO$618131
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_SISTEMA_VERSIONADO', p_delete_after_install => true );
    --SRV_TIPO_TAREFAS: 2/10000 rows exported, APEX$DATA$PKG/SRV_TIPO_TAREFAS$912085
    apex_data_install.load_supporting_object_data(p_table_name => 'SRV_TIPO_TAREFAS', p_delete_after_install => true );
end;