function treeViewOptions(pId) {   
    $(document).ready(function() {
        // Chama o processo Ajax para adicionar o atributo data-id nos itens da árvore! 
        apex.server.process(
        "GET_DATA_ID",
        {
            x01: $v(pId) 
        },
        {
            dataType: 'json', 
            success: function(data) {            
                if (data && data.length > 0) {                
                    data.forEach(function(item) {
                        var id = item.ID;
                        var nome = item.NOME;
                        var pastaPai = item.PASTA_PAI;                                     
                        
                    // Encontra o elemento HTML correspondente com base no nome do item!
                        var elementos = document.querySelectorAll('.a-TreeView-label');
                        elementos.forEach(function(elemento) {
                            if (elemento.textContent.trim() === nome) {
                                elemento.setAttribute('data-id', id);
                            }
                        });             
                    });
                }
            },
            error: function(xhr, status, error) {            
                //console.error("Erro ao obter dados: " + error);
                alert(error);               
                console.log(error);
            }
        }
    );

        // Adiciona a classe "PASTA_COM" aos itens e pastas, utilizada para a manipulação dos eventos!
        $("#myTree_tree li:has(.icon-tree-folder)").addClass("PASTA_COM");
        $(".a-TreeView-node--leaf").addClass("PASTA_COM");               

        // Loop utilizado para adicionar um item vazio indicando que a pasta está vazia!
        $(".PASTA_COM").each(function() {
            var $folder = $(this);
            var $folderContent = $folder.find(".a-TreeView-content");
            if ($folderContent.length > 0 && $folderContent.find(".icon-tree-folder").length > 0) {
                if ($folder.children("ul").length === 0) {
                    $(this).children(".a-TreeView-row").after("<span class='a-TreeView-toggle'></span>");   
                    $(this).append("<ul role='group' class='ui-sortable'><li id='itemVazio' role='none' class='noDrag a-TreeView-node a-TreeView-node--leaf  ui-sortable-handle' style='font-style: italic; color: lightgray; display: flex; align-items: center; font-size: var(--a-treeview-node-font-size,12px);'><div role='none' class='noDrag'><span tabindex='-1' role='treeitem' class='noDrag a-TreeView-label' aria-level='3' aria-selected='false'>Pasta vazia</span></div></li></ul>");
                    $(this).removeClass("a-TreeView-node--leaf");       
                    $(this).addClass("is-collapsible"); 
                }
            }
        });

        // Método .sortable() utilizado para tornar os itens e pastas arrastáveis e controlar opções de comportamento ao arrastá-los!
        $(".PASTA_COM > ul").sortable({
            cursor: "move",
            opacity: "0.5",
            scroll: "scrollSensitivity",
            delay: "150",
            cancel: ".noDrag",
            connectWith: ".PASTA_COM ul",
            receive: function(event, ui) {            
                var draggableItem = ui.item;
                draggableItem.removeClass("ITEM_COM ui-draggable ui-draggable-dragging");               
            },
            start: function(event, ui) {
                
                // Verifica se o item arrastado é o último filho!
                var temIrmaos = ui.item.siblings().length > 1;
                    if (!temIrmaos) {                    
                        // Adiciona o item "Pasta Vazia" se não houver outros irmãos!
                        $(this).append("<li id='itemVazio' role='none' class='noDrag a-TreeView-node a-TreeView-node--leaf ui-sortable-handle' style='font-style: italic; color: lightgray; display: flex; align-items: center; font-size: var(--a-treeview-node-font-size,12px);' draggable='false'><div role='none' class='noDrag' draggable='false'><span tabindex='-1' role='treeitem' class='noDrag a-TreeView-label' aria-level='3' aria-selected='false' draggable='false'>Pasta vazia</span></div></li>");
                        $(this).removeClass("a-TreeView-node--leaf");
                        $(this).addClass("is-collapsible");
                    }
            },
            stop: function(event, ui) {    
                
                // Verifica se o item foi solto em uma pasta vazia e remove marcação de pasta vazia!
                var irmaos = ui.item.siblings('#itemVazio');
                    if (irmaos) {              
                        irmaos.remove();
                    }                 

                // Obtém o ID do item arrastado!
                var itemID = ui.item.find(".a-TreeView-content .a-TreeView-label").attr("data-id");

                // Verifica se o item movido é uma pasta!
                var isPasta = ui.item.find(".a-TreeView-content .a-Icon.icon-tree-folder").length > 0;                

                // Obtém o id do novo pai!
                var novoPaiID;
                    if (isPasta) {
                        pastaMoved = ui.item.parent();
                        paiPastaMoved = pastaMoved.parent();
                        novoPaiID = paiPastaMoved.closest("li .a-TreeView-node:has(.icon-tree-folder)").find(".a-TreeView-label").attr("data-id");                   
                            if (!novoPaiID) {
                                novoPaiID = $("#myTree_tree_0 .a-TreeView-content:has(.icon-tree-folder)").find(".a-TreeView-label").attr("data-id");
                            }
                    } else {
                        novoPaiID = ui.item.closest("li .a-TreeView-node:has(.icon-tree-folder)").find(".a-TreeView-label").attr("data-id");                    
                            if (!novoPaiID) {
                                novoPaiID = $("#myTree_tree_0 .a-TreeView-content:has(.icon-tree-folder)").find(".a-TreeView-label").attr("data-id");
                            }
                    }
                
                // Chama o processo Ajax para atualizar a coluna PASTA_PAI!
                apex.server.process(
                    "ATUALIZAR_PASTA_PAI", 
                    {
                        x01: itemID,
                        x02: novoPaiID
                    },
                    {
                        dataType: 'json', 
                        success: function(data) {                            
                            //console.log("Relação 'PASTA_PAI' atualizada com sucesso.");
                        },
                        error: function(xhr, status, error) {                            
                            //console.error("Erro ao atualizar a relação 'PASTA_PAI': " + error);
                            alert("Erro ao atualizar hirarquia, tente novamente!");
                        }
                    }
                );            
            }        
        });
    });    
}
