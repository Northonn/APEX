function ajustaAlturaOnChangeInput() {
  //Ajusta a barra de rolagem da região de digitação das mensagens, conforme o campo vai aumentando com a digitação da mensagem
  $(document).ready(function() {
  var input = $(".font-size-mensagem");
  var maxHeight = 50;

  input.on('input', function() {    
    this.style.height = "auto";
    this.style.height = (this.scrollHeight) + "px";
    if (this.scrollHeight >= maxHeight) {
      this.style.overflowY = "hidden";
    } else {
      this.style.overflowY = "hidden";
    }
  });
});

//Ajusta a dimensão das regiões proporcionalmente, conforme o campo vai aumentando com a digitação da mensagem
$(document).ready(function() {
    $("#regiao-editar-mensagem").on("change input", function() {
    var chatMessageHeight = $("#regiao-editar-mensagem").outerHeight();
    $(".t-Dialog-bodyWrapperIn").css("height", "calc(95% - " + chatMessageHeight + "px)");
    $(".btn-bottom").css("bottom", "calc(5% + " + chatMessageHeight + "px)");
    });    
});

//Ajusta a rolagem da região que exibe as mensagens, conforme novas mensagens são enviadas
var conversation = $('.t-Dialog-bodyWrapperIn');
function scrollToBottom() {
conversation.scrollTop(conversation.prop("scrollHeight"));
}
conversation.on('DOMNodeInserted', scrollToBottom);

}