prompt --application/deployment/install/install_insert_table_filmes
begin
--   Manifest
--     INSTALL: INSTALL-insert table filmes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>140
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(96906946996654641)
,p_install_id=>wwv_flow_imp.id(96905526631647587)
,p_name=>'insert table filmes'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --FILMES: 30/10000 rows exported, APEX$DATA$PKG/FILMES$391191',
'    apex_data_install.load_supporting_object_data(p_table_name => ''FILMES'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
